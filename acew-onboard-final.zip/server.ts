import express from 'express';
import path from 'path';
import dotenv from 'dotenv';
import { GoogleGenAI, ThinkingLevel, Type } from '@google/genai';
import {
  getAllApplications,
  getApplicationById,
  createApplication,
  updateApplication,
  deleteApplication,
  getDatabaseStats,
} from './server/db';

dotenv.config();

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '25mb' }));

// Lazy Gemini client helper
function getGeminiClient() {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === 'MY_GEMINI_API_KEY') {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// System instruction for AVA
const AVA_SYSTEM_INSTRUCTION = `
You are AVA (Academic & Verification Assistant), the official and trustworthy AI companion for ACEW Onboard (Admission, Compliance, Engagement and Workflow) for Indian Universities & Colleges.
Your mission is to guide students smoothly through admission verification, document corrections, identity check (liveness & face cross-match), fee payments, and campus readiness.

Key Rules:
1. Ground your answers strictly in the student's current application data and the official admission FAQs provided in the conversation context or tool results.
2. Tone: Professional, reassuring, clear, and student-friendly.
3. Name: Always refer to yourself as AVA.
4. Language: Respond in the language requested by the student (English or Tamil - தமிழ்). If the user asks in Tamil, reply in clean, grammatically accurate Tamil.
5. Privacy & Boundaries:
   - NEVER approve or reject documents yourself. You are an assistive guide.
   - NEVER disclose OTPs, passwords, payment card numbers, or other students' private data.
   - For Document Trust Check, liveness, and face cross-match, remind students that these are assistive screening signals, not final rejections. An appeal and human officer review path is always available.
6. If you do not have verified information, politely direct them to the campus admission office helpdesk.
`;

// Approved FAQs
const ADMISSION_FAQS = [
  {
    topic: 'documents',
    q: 'What documents are required for admission?',
    a: 'Mandatory documents include: Class 10 Marksheet, Class 12 Marksheet, Government Photo ID (Aadhaar/Passport), and Transfer Certificate. Passport photo is required for the digital ID. Community certificate is required only if claiming quota.',
  },
  {
    topic: 'correction',
    q: 'Why does my Class 12 marksheet need correction?',
    a: 'The name on your Class 12 marksheet is "Ananya Krishnan S", whereas your application is registered as "Ananya Krishnan". Please upload supporting initial expansion proof or confirm your preferred registered name.',
  },
  {
    topic: 'identity',
    q: 'Why do I need to complete an Identity Check?',
    a: 'The consent-based Identity Check verifies live presence (liveness check) and performs an assistive comparison with your uploaded Government ID photo to prevent impersonation. It is assistive only and uncertain cases are routed to human officer review.',
  },
  {
    topic: 'fees',
    q: 'When do fee payment and hostel booking unlock?',
    a: 'Fee payment unlocks once your application is formally confirmed. Campus hostel selection and orientation registration unlock after all mandatory documents and verification are approved by the admission office.',
  },
  {
    topic: 'tamilexplanation',
    q: 'Explain marksheet issue in Tamil',
    a: 'உங்கள் 12ஆம் வகுப்பு மதிப்பெண் சான்றிதழில் உள்ள பெயர், விண்ணப்பத்தில் உள்ள பெயருடன் ("Ananya Krishnan S" vs "Ananya Krishnan") வேறுபடுகிறது. சரியான பெயரை உறுதிப்படுத்தவும் அல்லது தேவையான ஆதார ஆவணத்தைப் பதிவேற்றவும்.',
  },
];

// In-memory support tickets store
const supportTickets: Array<{
  id: string;
  studentId: string;
  studentName: string;
  category: string;
  message: string;
  createdAt: string;
  status: 'Open' | 'Resolved';
}> = [];

// API: Health check
app.get('/api/health', (req, res) => {
  res.json({
    status: 'ok',
    appName: 'ACEW Onboard',
    hasGeminiKey: Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY !== 'MY_GEMINI_API_KEY'),
  });
});

// API: CampusBuddy Chat with Gemini AI (supporting gemini-3.1-flash-lite, gemini-3.5-flash, gemini-3.1-pro-preview with thinkingLevel HIGH)
app.post('/api/gemini/chat', async (req, res) => {
  try {
    const {
      message,
      history = [],
      studentData,
      mode = 'fast', // 'fast' | 'general' | 'thinking'
      language = 'en',
    } = req.body;

    const ai = getGeminiClient();

    // Select model according to prompt specifications:
    // gemini-3.1-flash-lite for low-latency / fast
    // gemini-3.1-pro-preview with thinkingLevel.HIGH for thinking / complex
    // gemini-3.5-flash for general tasks
    let modelName = 'gemini-3.1-flash-lite';
    let thinkingConfig: any = undefined;

    if (mode === 'thinking') {
      modelName = 'gemini-3.1-pro-preview';
      thinkingConfig = { thinkingLevel: ThinkingLevel.HIGH };
    } else if (mode === 'general') {
      modelName = 'gemini-3.5-flash';
    } else {
      modelName = 'gemini-3.1-flash-lite';
    }

    // Context summary prepared from student data
    const studentSummary = studentData ? `
Current Student Context:
- Application ID: ${studentData.applicationId || 'CP-2026-1048'}
- Name: ${studentData.fullName || 'Ananya Krishnan'}
- Programme: ${studentData.programme || 'B.Tech Computer Science and Engineering'}
- Readiness Score: ${studentData.readinessScore || 72}% (${studentData.completedTasksCount || 18} of ${studentData.totalTasksCount || 25} tasks complete)
- Stage: ${studentData.currentStage || 'Verification'}
- Remaining Mandatory Tasks: ${studentData.remainingMandatoryCount || 4}
- Next Required Action: "Correct your Class 12 marksheet because the name differs from your application (Ananya Krishnan S vs Ananya Krishnan)."
- Document Health: Class 10 (Verified), Class 12 (Needs correction - Name mismatch), Govt ID (Verified), Transfer Certificate (Pending), Photograph (Verified)
- Identity Check: Liveness (Passed), Face Cross-Match (Review required - 68% confidence due to low-res ID image)
- Locked Tasks: Orientation registration is locked until all mandatory documents are verified.
` : '';

    if (!ai) {
      // High-quality deterministic fallback simulating CampusBuddy when API key is not configured
      let fallbackText = '';
      const lower = (message || '').toLowerCase();

      if (language === 'ta' || lower.includes('tamil') || lower.includes('தமிழ்')) {
        if (lower.includes('mark') || lower.includes('மதிப்பெண்') || lower.includes('issue') || lower.includes('12')) {
          fallbackText = 'வணக்கம்! உங்கள் 12ஆம் வகுப்பு மதிப்பெண் சான்றிதழில் உள்ள பெயர் "Ananya Krishnan S", விண்ணப்பத்தில் உள்ள பெயர் "Ananya Krishnan". எனவே சரிபார்ப்பு நிலுவையில் உள்ளது. தயவுசெய்து சரியான ஆவணத்தை பதிவேற்றவும் அல்லது சேர்க்கை அலுவலகத்தை அணுகவும்.';
        } else if (lower.includes('identity') || lower.includes('முகம்') || lower.includes('face')) {
          fallbackText = 'அடையாள சரிபார்ப்பு (Identity Check) ஒரு உதவி அம்சம் மட்டுமே. உங்கள் அடையாள அட்டையின் புகைப்படம் குறைந்த தெளிவுத்திறனுடன் உள்ளதால் அது அதிகாரி மதிப்பாய்வுக்கு அனுப்பப்பட்டுள்ளது. நீங்கள் மீண்டும் முயற்சிக்கலாம் அல்லது நேரடி சரிபார்ப்பை கோரலாம்.';
        } else {
          fallbackText = `வணக்கம் Ananya! உங்கள் சேர்க்கை முன்னேற்றம் ${studentData?.readinessScore || 72}%. அடுத்த கட்டாய பணி: 12ஆம் வகுப்பு மதிப்பெண் சான்றிதழ் பெயர் முரண்பாட்டை சரிசெய்வது.`;
        }
      } else {
        if (lower.includes('missing') || lower.includes('document')) {
          fallbackText = 'Your pending documents are the **Transfer Certificate** (Pending upload) and the **Class 12 Marksheet** (Needs correction due to name mismatch). Your Government ID proof and Class 10 Marksheet are already verified.';
        } else if (lower.includes('next') || lower.includes('what should i do') || lower.includes('action')) {
          fallbackText = `You are currently at **${studentData?.readinessScore || 72}% ACEW Readiness** with 18 of 25 tasks complete.\n\nYour next required action is to **correct your Class 12 marksheet** (the name on the marksheet reads *"Ananya Krishnan S"* while your application is registered as *"Ananya Krishnan"*). Uploading the corrected document or supporting proof will update your status for officer review.`;
        } else if (lower.includes('orientation') || lower.includes('locked')) {
          fallbackText = 'Orientation registration is locked because campus policy requires all mandatory documents and verification to be approved first. Once your Class 12 marksheet and Transfer Certificate are verified, orientation will automatically unlock.';
        } else if (lower.includes('identity') || lower.includes('liveness') || lower.includes('face') || lower.includes('review')) {
          fallbackText = 'The Identity Check is an assistive screening tool to ensure presence and match your live selfie with your government ID photo. Your current status is **Review Required** (68% confidence) because the uploaded ID photo has low resolution. You can retry with clearer lighting or request manual officer review. Automated signals never automatically reject you.';
        } else if (lower.includes('fee') || lower.includes('hostel')) {
          fallbackText = 'Fee payment will unlock as soon as your admission offer is confirmed. Hostel allotment is optional and can be submitted under Campus Setup.';
        } else {
          fallbackText = `Hello Ananya! I am AVA, your AI Admission & Verification Assistant. Your admission readiness is at **${studentData?.readinessScore || 72}%**. You have 4 mandatory tasks remaining, led by resolving the Class 12 marksheet name mismatch. How can I guide you with your verification or campus onboarding today?`;
        }
      }

      return res.json({
        reply: fallbackText,
        modelUsed: `${modelName} (Demo Simulation)`,
        latencyMs: 120,
        isSimulated: true,
      });
    }

    // Call real Gemini API
    const startTime = Date.now();
    const config: any = {
      systemInstruction: `${AVA_SYSTEM_INSTRUCTION}\n\n${studentSummary}\n\nLanguage requested: ${language === 'ta' ? 'Tamil' : 'English'}.`,
    };

    if (thinkingConfig) {
      config.thinkingConfig = thinkingConfig;
    }

    // Build chat contents including past turns
    const contents: any[] = [];
    if (Array.isArray(history)) {
      for (const turn of history.slice(-8)) {
        contents.push({
          role: turn.sender === 'user' ? 'user' : 'model',
          parts: [{ text: turn.text }],
        });
      }
    }
    contents.push({
      role: 'user',
      parts: [{ text: message }],
    });

    const response = await ai.models.generateContent({
      model: modelName,
      contents,
      config,
    });

    const latencyMs = Date.now() - startTime;
    return res.json({
      reply: response.text || 'I am ready to help you with your admission journey.',
      modelUsed: modelName,
      latencyMs,
      isSimulated: false,
    });
  } catch (err: any) {
    console.error('Error in /api/gemini/chat:', err);
    return res.json({
      reply: 'CampusBuddy is currently operating in offline demo mode. You are 72% complete. Your next required task is to correct your Class 12 marksheet name mismatch.',
      modelUsed: 'gemini-3.1-flash-lite (Offline Fallback)',
      latencyMs: 50,
      isSimulated: true,
    });
  }
});

// API: Document Image Analysis & OCR Trust Check (using gemini-3.1-pro-preview for image understanding)
app.post('/api/gemini/analyze-document', async (req, res) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg', documentType = 'class_12', studentName = 'Ananya Krishnan' } = req.body;

    const ai = getGeminiClient();

    if (!ai || !imageBase64) {
      // Seeded realistic OCR & Trust Check response
      const isClass12 = documentType === 'class_12';
      return res.json({
        ocr: {
          studentName: isClass12 ? 'Ananya Krishnan S' : studentName,
          dateOfBirth: '2008-04-14',
          registerNumber: isClass12 ? 'TN-HSC-2026-889412' : 'TN-SSLC-2024-441092',
          institutionName: 'St. Marys Higher Secondary School, Madurai',
          totalMarks: isClass12 ? '572 / 600' : '482 / 500',
          percentage: isClass12 ? '95.33%' : '96.40%',
          passingYear: isClass12 ? '2026' : '2024',
          stream: isClass12 ? 'Science (Maths, Physics, Chemistry, CS)' : 'General Secondary',
          confidence: 0.94,
        },
        trustCheck: {
          riskLevel: isClass12 ? 'Medium' : 'Low',
          status: isClass12 ? 'Review required' : 'Verified',
          qualityIssues: isClass12 ? ['Slight blur on bottom margin', 'Low resolution certificate number'] : [],
          mismatches: isClass12
            ? [
                {
                  field: 'Student Name',
                  applicationValue: 'Ananya Krishnan',
                  documentValue: 'Ananya Krishnan S',
                  message: 'The name on this document differs from your application. Confirm the correct name or upload supporting proof.',
                },
              ]
            : [],
          reasons: isClass12
            ? [
                'Name differs from the application (initial suffix "S" present).',
                'Image quality is low in corner seal area.',
                'Certificate number could not be read with high confidence.',
              ]
            : ['High extraction confidence', 'All security marks aligned', 'No digital modifications detected'],
          recommendedAction: isClass12
            ? 'Confirm whether "Ananya Krishnan S" is your official legal name or upload Class 10 / Aadhaar matching document.'
            : 'Document ready for standard officer sign-off.',
        },
        isSimulated: true,
      });
    }

    // Call gemini-3.1-pro-preview for deep multimodal analysis
    const prompt = `
You are an expert Document Trust Check and OCR inspector for Indian college admissions.
Analyze this uploaded ${documentType} document image for student "${studentName}".
Extract key fields (Student Name, DOB, Register No, Institution, Marks, Passing Year).
Evaluate visual quality: blur, glare, dark lighting, cropped borders, or signs of digital tampering.
Check for any name or data discrepancy against student name "${studentName}".

Return STRICT JSON with keys:
{
  "ocr": {
    "studentName": string,
    "dateOfBirth": string,
    "registerNumber": string,
    "institutionName": string,
    "totalMarks": string,
    "percentage": string,
    "passingYear": string,
    "stream": string,
    "confidence": number
  },
  "trustCheck": {
    "riskLevel": "Low" | "Medium" | "High",
    "status": "Verified" | "Review required" | "Needs correction",
    "qualityIssues": string[],
    "mismatches": [{"field": string, "applicationValue": string, "documentValue": string, "message": string}],
    "reasons": string[],
    "recommendedAction": string
  }
}
`;

    const cleanBase64 = imageBase64.replace(/^data:[^;]+;base64,/, '');
    const response = await ai.models.generateContent({
      model: 'gemini-3.1-pro-preview',
      contents: {
        parts: [
          {
            inlineData: {
              mimeType,
              data: cleanBase64,
            },
          },
          { text: prompt },
        ],
      },
      config: {
        responseMimeType: 'application/json',
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json({
      ...parsed,
      isSimulated: false,
    });
  } catch (err: any) {
    console.error('Error analyzing document:', err);
    return res.json({
      ocr: {
        studentName: 'Ananya Krishnan S',
        dateOfBirth: '2008-04-14',
        registerNumber: 'TN-HSC-2026-889412',
        institutionName: 'St. Marys Higher Secondary School, Madurai',
        totalMarks: '572 / 600',
        percentage: '95.33%',
        passingYear: '2026',
        stream: 'Computer Science & Maths',
        confidence: 0.92,
      },
      trustCheck: {
        riskLevel: 'Medium',
        status: 'Review required',
        qualityIssues: ['Slight blur on certificate number', 'Compressed image format'],
        mismatches: [
          {
            field: 'Student Name',
            applicationValue: 'Ananya Krishnan',
            documentValue: 'Ananya Krishnan S',
            message: 'The name on this document differs from your application. Confirm the correct name or upload supporting proof.',
          },
        ],
        reasons: ['Name differs from application (suffix initial)', 'Low resolution stamp area'],
        recommendedAction: 'Upload a clearer document and ask an admission officer to review it.',
      },
      isSimulated: true,
    });
  }
});

// API: Image Generation with Aspect Ratio control (aspect ratios: 1:1, 2:3, 3:2, 3:4, 4:3, 9:16, 16:9, 21:9)
app.post('/api/gemini/generate-campus-asset', async (req, res) => {
  try {
    const { prompt, aspectRatio = '1:1', studentName = 'Ananya Krishnan' } = req.body;
    const ai = getGeminiClient();

    // Mapping aspect ratio to allowed nano banana values: "1:1", "3:4", "4:3", "9:16", "16:9"
    const allowedAspectRatios = ['1:1', '3:4', '4:3', '9:16', '16:9'];
    const safeAspectRatio = allowedAspectRatios.includes(aspectRatio) ? aspectRatio : '1:1';

    if (!ai) {
      // Generate clean visual SVG data URL if no paid key / offline
      const colors: Record<string, string> = {
        '1:1': 'width="400" height="400"',
        '3:4': 'width="300" height="400"',
        '4:3': 'width="400" height="300"',
        '16:9': 'width="480" height="270"',
        '9:16': 'width="270" height="480"',
        '21:9': 'width="560" height="240"',
      };
      const dim = colors[aspectRatio] || 'width="400" height="400"';
      const svg = `
<svg xmlns="http://www.w3.org/2000/svg" ${dim} viewBox="0 0 400 400">
  <defs>
    <linearGradient id="g" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#0B1F3A" />
      <stop offset="100%" stop-color="#2563EB" />
    </linearGradient>
  </defs>
  <rect width="100%" height="100%" fill="url(#g)" rx="16" />
  <circle cx="200" cy="140" r="48" fill="#FFFFFF" opacity="0.2"/>
  <circle cx="200" cy="130" r="32" fill="#FFFFFF" opacity="0.9"/>
  <path d="M140 220 C 140 180, 260 180, 260 220 Z" fill="#FFFFFF" opacity="0.9"/>
  <text x="200" y="270" fill="#FFFFFF" font-size="18" font-weight="700" text-anchor="middle" font-family="Inter, sans-serif">ACEW ONBOARD</text>
  <text x="200" y="295" fill="#93C5FD" font-size="14" text-anchor="middle" font-family="Inter, sans-serif">${studentName}</text>
  <text x="200" y="320" fill="#E2E8F0" font-size="12" text-anchor="middle" font-family="Inter, sans-serif">Student ID Card (Preview • Ratio ${aspectRatio})</text>
  <rect x="60" y="340" width="280" height="24" rx="12" fill="#0F766E" opacity="0.9"/>
  <text x="200" y="356" fill="#FFFFFF" font-size="11" font-weight="600" text-anchor="middle" font-family="Inter, sans-serif">VERIFIED CAMPUS IDENTITY</text>
</svg>`;
      const base64 = Buffer.from(svg).toString('base64');
      return res.json({
        imageUrl: `data:image/svg+xml;base64,${base64}`,
        aspectRatio,
        isSimulated: true,
      });
    }

    const response = await ai.models.generateContent({
      model: 'gemini-3.1-flash-image',
      contents: {
        parts: [{ text: `${prompt || 'A clean university student identity card for student ' + studentName} with official campus emblem, high contrast professional styling.` }],
      },
      config: {
        imageConfig: {
          aspectRatio: safeAspectRatio as any,
          imageSize: '1K',
        },
      },
    });

    let imageUrl = '';
    const parts = response.candidates?.[0]?.content?.parts || [];
    for (const part of parts) {
      if (part.inlineData?.data) {
        imageUrl = `data:image/png;base64,${part.inlineData.data}`;
        break;
      }
    }

    if (!imageUrl) {
      throw new Error('No image returned from Gemini');
    }

    return res.json({
      imageUrl,
      aspectRatio,
      isSimulated: false,
    });
  } catch (err: any) {
    console.error('Error generating image:', err);
    // Return fallback SVG
    return res.json({
      imageUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=600&q=80',
      aspectRatio: req.body.aspectRatio || '1:1',
      isSimulated: true,
    });
  }
});

// API: Support Tickets creation
app.post('/api/support-tickets', (req, res) => {
  const { studentId, studentName, category, message } = req.body;
  const ticket = {
    id: `TCK-${Date.now().toString().slice(-6)}`,
    studentId: studentId || 'CP-2026-1048',
    studentName: studentName || 'Ananya Krishnan',
    category: category || 'Document Verification',
    message: message || 'Student requested support regarding document name verification.',
    createdAt: new Date().toISOString(),
    status: 'Open' as const,
  };
  supportTickets.unshift(ticket);
  res.json({ success: true, ticket });
});

app.get('/api/support-tickets', (req, res) => {
  res.json({ tickets: supportTickets });
});

// ==========================================
// DATABASE CRUD API (SQLite 3 WebAssembly Engine)
// ==========================================

// GET /api/database/stats - Inspect database technology and row counts
app.get('/api/database/stats', async (req, res) => {
  try {
    const stats = await getDatabaseStats();
    res.json(stats);
  } catch (err: any) {
    console.error('Error fetching database stats:', err);
    res.status(500).json({ error: 'Failed to fetch database stats', details: err.message });
  }
});

// GET /api/database/applications - READ all records (supports ?search=&status=)
app.get('/api/database/applications', async (req, res) => {
  try {
    const search = typeof req.query.search === 'string' ? req.query.search : undefined;
    const status = typeof req.query.status === 'string' ? req.query.status : undefined;
    const records = await getAllApplications(search, status);
    res.json({ success: true, count: records.length, applications: records });
  } catch (err: any) {
    console.error('Error fetching applications from database:', err);
    res.status(500).json({ error: 'Database read failed', details: err.message });
  }
});

// GET /api/database/applications/:id - READ single record
app.get('/api/database/applications/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const record = await getApplicationById(id);
    if (!record) {
      return res.status(404).json({ error: 'Application record not found' });
    }
    res.json({ success: true, application: record });
  } catch (err: any) {
    console.error('Error fetching application by id:', err);
    res.status(500).json({ error: 'Database read failed', details: err.message });
  }
});

// POST /api/database/applications - CREATE new record
app.post('/api/database/applications', async (req, res) => {
  try {
    const {
      application_id,
      full_name,
      email,
      phone,
      programme,
      category = 'State Quota (General)',
      status = 'Pending',
      readiness_score = 50,
      documents_verified = 0,
      identity_status = 'Not started',
      notes = '',
    } = req.body;

    if (!application_id || !full_name || !email || !phone || !programme) {
      return res.status(400).json({
        error: 'Missing required fields: application_id, full_name, email, phone, programme',
      });
    }

    const created = await createApplication({
      application_id,
      full_name,
      email,
      phone,
      programme,
      category,
      status,
      readiness_score: Number(readiness_score) || 0,
      documents_verified: Number(documents_verified) || 0,
      identity_status,
      notes,
    });

    res.status(201).json({
      success: true,
      message: 'Application record created successfully in SQLite database',
      application: created,
    });
  } catch (err: any) {
    console.error('Error creating application in database:', err);
    res.status(500).json({ error: 'Database create failed', details: err.message });
  }
});

// PUT /api/database/applications/:id - UPDATE existing record
app.put('/api/database/applications/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const updates = req.body;

    const updated = await updateApplication(id, updates);
    if (!updated) {
      return res.status(404).json({ error: 'Application record not found to update' });
    }

    res.json({
      success: true,
      message: 'Application record updated successfully in SQLite database',
      application: updated,
    });
  } catch (err: any) {
    console.error('Error updating application in database:', err);
    res.status(500).json({ error: 'Database update failed', details: err.message });
  }
});

// DELETE /api/database/applications/:id - DELETE record
app.delete('/api/database/applications/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const deleted = await deleteApplication(id);
    if (!deleted) {
      return res.status(404).json({ error: 'Application record not found to delete' });
    }

    res.json({
      success: true,
      message: `Application record ${id} deleted successfully from SQLite database`,
    });
  } catch (err: any) {
    console.error('Error deleting application from database:', err);
    res.status(500).json({ error: 'Database delete failed', details: err.message });
  }
});

// Vite Middleware for development vs Static files in production
async function setupViteOrStatic() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`ACEW Onboard server running at http://0.0.0.0:${PORT}`);
  });
}

setupViteOrStatic();
