import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

export interface StudentApplicationRecord {
  id: string;
  application_id: string;
  full_name: string;
  email: string;
  phone: string;
  programme: string;
  category: string;
  status: 'Needs correction' | 'Under Review' | 'Verified' | 'Enrolled' | 'Pending';
  readiness_score: number;
  documents_verified: number;
  identity_status: string;
  notes: string;
  created_at: string;
  updated_at: string;
}

let dbInstance: Database | null = null;
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_FILE = path.join(DATA_DIR, 'acew_onboard.sqlite');

export async function getDatabase(): Promise<Database> {
  if (dbInstance) {
    return dbInstance;
  }

  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  const SQL = await initSqlJs();

  if (fs.existsSync(DB_FILE)) {
    try {
      const fileBuffer = fs.readFileSync(DB_FILE);
      dbInstance = new SQL.Database(fileBuffer);
      console.log('Loaded existing SQLite database from', DB_FILE);
    } catch (err) {
      console.warn('Failed to load existing SQLite file, creating fresh database:', err);
      dbInstance = new SQL.Database();
    }
  } else {
    dbInstance = new SQL.Database();
    console.log('Initialized fresh SQLite database');
  }

  // Ensure table exists
  dbInstance.run(`
    CREATE TABLE IF NOT EXISTS student_applications (
      id TEXT PRIMARY KEY,
      application_id TEXT UNIQUE NOT NULL,
      full_name TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      programme TEXT NOT NULL,
      category TEXT NOT NULL,
      status TEXT NOT NULL,
      readiness_score INTEGER NOT NULL,
      documents_verified INTEGER NOT NULL,
      identity_status TEXT NOT NULL,
      notes TEXT,
      created_at TEXT NOT NULL,
      updated_at TEXT NOT NULL
    );
  `);

  // Check if initial records exist
  const res = dbInstance.exec('SELECT COUNT(*) as count FROM student_applications');
  const count = (res[0]?.values[0]?.[0] as number) || 0;

  if (count === 0) {
    console.log('Seeding initial student application records into SQLite database...');
    const seedRecords: StudentApplicationRecord[] = [
      {
        id: 'app-1',
        application_id: 'CP-2026-1048',
        full_name: 'Ananya Krishnan',
        email: 'ananya.k@example.com',
        phone: '+91 98401 23456',
        programme: 'B.Tech Computer Science and Engineering',
        category: 'State Quota (General)',
        status: 'Needs correction',
        readiness_score: 72,
        documents_verified: 4,
        identity_status: 'Review required (68%)',
        notes: 'Class 12 initial S discrepancy pending resolution.',
        created_at: '2026-09-13 16:30:00',
        updated_at: '2026-09-14 10:15:00',
      },
      {
        id: 'app-2',
        application_id: 'CP-2026-1049',
        full_name: 'R. Vignesh Kumar',
        email: 'vignesh.r@example.com',
        phone: '+91 98402 34567',
        programme: 'B.Tech Mechanical Engineering',
        category: 'Open Competition (OC)',
        status: 'Verified',
        readiness_score: 95,
        documents_verified: 5,
        identity_status: 'Passed (94%)',
        notes: 'All mandatory certificates verified by Officer Sundaram.',
        created_at: '2026-09-14 11:20:00',
        updated_at: '2026-09-14 14:00:00',
      },
      {
        id: 'app-3',
        application_id: 'CP-2026-1050',
        full_name: 'S. Meenakshi',
        email: 'meenakshi.s@example.com',
        phone: '+91 98403 45678',
        programme: 'B.Tech Electronics & Communication',
        category: 'First Graduate Concession',
        status: 'Pending',
        readiness_score: 48,
        documents_verified: 2,
        identity_status: 'Not started',
        notes: 'Challan fee verification awaiting confirmation.',
        created_at: '2026-09-15 08:15:00',
        updated_at: '2026-09-15 08:45:00',
      },
      {
        id: 'app-4',
        application_id: 'CP-2026-1051',
        full_name: 'G. Karthik',
        email: 'karthik.g@example.com',
        phone: '+91 98404 56789',
        programme: 'B.Tech Artificial Intelligence & Data Science',
        category: 'State Quota (BC)',
        status: 'Enrolled',
        readiness_score: 100,
        documents_verified: 5,
        identity_status: 'Passed (98%)',
        notes: 'Enrolled. Hostel room Block A-108 allocated.',
        created_at: '2026-09-13 14:00:00',
        updated_at: '2026-09-15 09:30:00',
      },
    ];

    for (const r of seedRecords) {
      dbInstance.run(
        `INSERT INTO student_applications (
          id, application_id, full_name, email, phone, programme, category,
          status, readiness_score, documents_verified, identity_status, notes,
          created_at, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`,
        [
          r.id,
          r.application_id,
          r.full_name,
          r.email,
          r.phone,
          r.programme,
          r.category,
          r.status,
          r.readiness_score,
          r.documents_verified,
          r.identity_status,
          r.notes,
          r.created_at,
          r.updated_at,
        ]
      );
    }
    saveDatabaseFile();
  }

  return dbInstance;
}

export function saveDatabaseFile(): void {
  if (!dbInstance) return;
  try {
    const data = dbInstance.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_FILE, buffer);
  } catch (err) {
    console.error('Failed to save SQLite file to disk:', err);
  }
}

// CRUD Operations

export async function getAllApplications(
  search?: string,
  status?: string
): Promise<StudentApplicationRecord[]> {
  const db = await getDatabase();
  let sql = 'SELECT * FROM student_applications';
  const conditions: string[] = [];
  const params: any[] = [];

  if (status && status !== 'All') {
    conditions.push('status = ?');
    params.push(status);
  }

  if (search && search.trim()) {
    conditions.push('(full_name LIKE ? OR application_id LIKE ? OR programme LIKE ?)');
    const term = `%${search.trim()}%`;
    params.push(term, term, term);
  }

  if (conditions.length > 0) {
    sql += ' WHERE ' + conditions.join(' AND ');
  }

  sql += ' ORDER BY created_at DESC';

  const stmt = db.prepare(sql);
  if (params.length > 0) {
    stmt.bind(params);
  }

  const results: StudentApplicationRecord[] = [];
  while (stmt.step()) {
    const row = stmt.getAsObject() as any;
    results.push({
      id: row.id,
      application_id: row.application_id,
      full_name: row.full_name,
      email: row.email,
      phone: row.phone,
      programme: row.programme,
      category: row.category,
      status: row.status,
      readiness_score: Number(row.readiness_score),
      documents_verified: Number(row.documents_verified),
      identity_status: row.identity_status,
      notes: row.notes || '',
      created_at: row.created_at,
      updated_at: row.updated_at,
    });
  }
  stmt.free();
  return results;
}

export async function getApplicationById(id: string): Promise<StudentApplicationRecord | null> {
  const db = await getDatabase();
  const stmt = db.prepare(
    'SELECT * FROM student_applications WHERE id = ? OR application_id = ? LIMIT 1'
  );
  stmt.bind([id, id]);

  if (stmt.step()) {
    const row = stmt.getAsObject() as any;
    stmt.free();
    return {
      id: row.id,
      application_id: row.application_id,
      full_name: row.full_name,
      email: row.email,
      phone: row.phone,
      programme: row.programme,
      category: row.category,
      status: row.status,
      readiness_score: Number(row.readiness_score),
      documents_verified: Number(row.documents_verified),
      identity_status: row.identity_status,
      notes: row.notes || '',
      created_at: row.created_at,
      updated_at: row.updated_at,
    };
  }
  stmt.free();
  return null;
}

export async function createApplication(
  data: Omit<StudentApplicationRecord, 'id' | 'created_at' | 'updated_at'> & {
    id?: string;
  }
): Promise<StudentApplicationRecord> {
  const db = await getDatabase();
  const id = data.id || `app-${Date.now()}`;
  const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

  db.run(
    `INSERT INTO student_applications (
      id, application_id, full_name, email, phone, programme, category,
      status, readiness_score, documents_verified, identity_status, notes,
      created_at, updated_at
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`,
    [
      id,
      data.application_id,
      data.full_name,
      data.email,
      data.phone,
      data.programme,
      data.category,
      data.status,
      data.readiness_score,
      data.documents_verified,
      data.identity_status,
      data.notes || '',
      now,
      now,
    ]
  );

  saveDatabaseFile();

  const created = await getApplicationById(id);
  if (!created) throw new Error('Failed to retrieve newly created application record');
  return created;
}

export async function updateApplication(
  id: string,
  data: Partial<StudentApplicationRecord>
): Promise<StudentApplicationRecord | null> {
  const db = await getDatabase();
  const existing = await getApplicationById(id);
  if (!existing) return null;

  const now = new Date().toISOString().replace('T', ' ').substring(0, 19);

  const updated: StudentApplicationRecord = {
    ...existing,
    ...data,
    updated_at: now,
  };

  db.run(
    `UPDATE student_applications SET
      application_id = ?,
      full_name = ?,
      email = ?,
      phone = ?,
      programme = ?,
      category = ?,
      status = ?,
      readiness_score = ?,
      documents_verified = ?,
      identity_status = ?,
      notes = ?,
      updated_at = ?
    WHERE id = ?;`,
    [
      updated.application_id,
      updated.full_name,
      updated.email,
      updated.phone,
      updated.programme,
      updated.category,
      updated.status,
      updated.readiness_score,
      updated.documents_verified,
      updated.identity_status,
      updated.notes,
      updated.updated_at,
      existing.id,
    ]
  );

  saveDatabaseFile();
  return updated;
}

export async function deleteApplication(id: string): Promise<boolean> {
  const db = await getDatabase();
  const existing = await getApplicationById(id);
  if (!existing) return false;

  db.run('DELETE FROM student_applications WHERE id = ?;', [existing.id]);
  saveDatabaseFile();
  return true;
}

export async function getDatabaseStats() {
  const db = await getDatabase();
  const countRes = db.exec('SELECT COUNT(*) as count FROM student_applications');
  const count = (countRes[0]?.values[0]?.[0] as number) || 0;

  let fileSize = 0;
  if (fs.existsSync(DB_FILE)) {
    const stats = fs.statSync(DB_FILE);
    fileSize = stats.size;
  }

  return {
    technology: 'SQLite 3 (via sql.js WebAssembly Engine)',
    databaseFile: 'data/acew_onboard.sqlite',
    primaryEntity: 'student_applications',
    totalRecords: count,
    fileSizeBytes: fileSize,
    fileSizeKb: (fileSize / 1024).toFixed(2),
    isPersistent: true,
    supportedOperations: ['CREATE', 'READ', 'UPDATE', 'DELETE'],
  };
}
