import React from 'react';
import { ArrowLeft, ArrowRight, CheckCircle2 } from 'lucide-react';
import { useApp } from '../context/AppContext';
import { APPLICATION_STEPS } from './ApplicationProgressStepper';

interface WorkflowNavigationFooterProps {
  currentStepNumber: number; // 1 to 6
  onNextBeforeNavigate?: () => boolean | Promise<boolean>;
  customNextLabel?: string;
  isNextDisabled?: boolean;
}

export const WorkflowNavigationFooter: React.FC<WorkflowNavigationFooterProps> = ({
  currentStepNumber,
  onNextBeforeNavigate,
  customNextLabel,
  isNextDisabled = false,
}) => {
  const { navigateTo } = useApp();

  const prevStep = APPLICATION_STEPS.find((s) => s.id === currentStepNumber - 1);
  const nextStep = APPLICATION_STEPS.find((s) => s.id === currentStepNumber + 1);

  const handleNext = async () => {
    if (onNextBeforeNavigate) {
      const allowed = await onNextBeforeNavigate();
      if (!allowed) return;
    }
    if (nextStep) {
      navigateTo(nextStep.route);
    }
  };

  const handlePrev = () => {
    if (prevStep) {
      navigateTo(prevStep.route);
    }
  };

  return (
    <div className="mt-8 pt-5 border-t border-[#DED4C3] flex flex-col sm:flex-row items-center justify-between gap-4">
      {prevStep ? (
        <button
          type="button"
          onClick={handlePrev}
          className="w-full sm:w-auto px-4 py-2.5 rounded-xl border border-[#CEC4B3] hover:bg-[#FAF6ED] text-[#465047] font-bold text-xs flex items-center justify-center gap-2 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to {prevStep.shortName} (Step {prevStep.id})</span>
        </button>
      ) : (
        <div />
      )}

      {nextStep ? (
        <button
          type="button"
          onClick={handleNext}
          disabled={isNextDisabled}
          className={`w-full sm:w-auto px-6 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 shadow-sm transition-all ${
            isNextDisabled
              ? 'bg-[#DED4C3] text-[#858B84] cursor-not-allowed'
              : 'bg-[#2F7454] hover:bg-[#245C43] text-white shadow-[#2F7454]/25 hover:shadow-md'
          }`}
        >
          <span>{customNextLabel || `Proceed to Step ${nextStep.id}: ${nextStep.shortName}`}</span>
          <ArrowRight className="w-4 h-4" />
        </button>
      ) : (
        <button
          type="button"
          onClick={() => window.print()}
          className="w-full sm:w-auto px-6 py-2.5 rounded-xl font-bold text-xs flex items-center justify-center gap-2 bg-emerald-600 hover:bg-emerald-700 text-white shadow-sm transition-all"
        >
          <CheckCircle2 className="w-4 h-4" />
          <span>Application 100% Complete (Print Dossier)</span>
        </button>
      )}
    </div>
  );
};
