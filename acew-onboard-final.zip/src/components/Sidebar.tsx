import React from 'react';
import {
  LayoutDashboard,
  User,
  FileCheck2,
  ScanFace,
  ClipboardCheck,
  Compass,
  FileBadge2,
  HelpCircle,
  ShieldAlert,
  SlidersHorizontal,
  Users,
  CheckCircle2,
  AlertCircle,
  Clock,
  GraduationCap,
  BookOpen,
  LogIn,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Sidebar: React.FC = () => {
  const {
    role,
    currentRoute,
    navigateTo,
    language,
    tasks,
    documents,
    identityCheck,
    readinessScore,
    setInstructionGuideOpen,
  } = useApp();

  const needsDocCorrection = documents.some((d) => d.status === 'Needs correction');
  const needsIdentityReview = identityCheck.status === 'review_required';

  const studentNavItems = [
    {
      label: language === 'ta' ? 'முகப்பு பலகை' : 'Dashboard',
      route: '/student/dashboard',
      icon: LayoutDashboard,
      badge: `${readinessScore}%`,
      badgeColor: 'bg-[#DDEFE4] text-[#1C4937]',
    },
    {
      label: language === 'ta' ? 'சுயவிவரம்' : 'My Profile',
      route: '/student/profile',
      icon: User,
    },
    {
      label: language === 'ta' ? 'ஆவணங்கள்' : 'Documents',
      route: '/student/documents',
      icon: FileCheck2,
      badge: needsDocCorrection ? 'Fix' : undefined,
      badgeColor: 'bg-amber-100 text-amber-800',
    },
    {
      label: language === 'ta' ? 'அடையாள சோதனை' : 'Identity Check',
      route: '/student/identity-check',
      icon: ScanFace,
      badge: needsIdentityReview ? 'Review' : undefined,
      badgeColor: 'bg-amber-100 text-amber-800',
    },
    {
      label: language === 'ta' ? 'சரிபார்ப்பு நிலை' : 'Verification',
      route: '/student/verification',
      icon: ClipboardCheck,
      badge: needsDocCorrection ? 'Action' : undefined,
      badgeColor: 'bg-red-100 text-red-800',
    },
    {
      label: language === 'ta' ? 'சேர்க்கை படிகள்' : 'Onboarding',
      route: '/student/onboarding',
      icon: Compass,
    },
    {
      label: language === 'ta' ? 'சரிபார்ப்பு ரசீது' : 'Receipt (QR)',
      route: '/student/receipt',
      icon: FileBadge2,
    },
    {
      label: language === 'ta' ? 'உதவி மையம்' : 'Help & FAQs',
      route: '/help',
      icon: HelpCircle,
    },
  ];

  const adminNavItems = [
    {
      label: 'Admin Overview',
      route: '/admin/dashboard',
      icon: LayoutDashboard,
    },
    {
      label: 'Applications Queue',
      route: '/admin/applications',
      icon: Users,
      badge: '3 Active',
      badgeColor: 'bg-[#DDEFE4] text-[#1C4937]',
    },
    {
      label: 'Review Ananya (Demo)',
      route: '/admin/applications/CP-2026-1048',
      icon: ShieldAlert,
      badge: 'Med Risk',
      badgeColor: 'bg-amber-100 text-amber-800',
    },
    {
      label: 'Admission Rules',
      route: '/admin/rules',
      icon: SlidersHorizontal,
    },
    {
      label: 'Staff Policy & Help',
      route: '/help',
      icon: HelpCircle,
    },
  ];

  const navItems = role === 'admin' ? adminNavItems : studentNavItems;

  return (
    <>
      {/* Desktop Sidebar (Fixed Left) */}
      <aside className="hidden md:flex flex-col w-64 bg-white border-r border-[#DED4C3] shrink-0 min-h-[calc(100vh-4rem)] p-4 justify-between">
        <div className="space-y-6">
          {/* Quick User Banner */}
          <div className="p-3 bg-[#FAF6ED] rounded-xl border border-[#DED4C3]/80">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-[#DDEFE4] text-[#245C43] flex items-center justify-center shrink-0">
                <GraduationCap className="w-4 h-4" />
              </div>
              <div className="overflow-hidden">
                <div className="text-xs font-bold text-[#2E342F] truncate">
                  {role === 'admin' ? 'Admission Office' : 'B.Tech CSE 2026'}
                </div>
                <div className="text-[11px] text-[#6B716A] truncate">
                  {role === 'admin' ? 'Review Desk' : 'App: CP-2026-1048'}
                </div>
              </div>
            </div>

            {role === 'student' && (
              <div className="mt-2.5 pt-2 border-t border-[#DED4C3]/60 flex items-center justify-between text-[11px]">
                <span className="text-[#6B716A] font-medium">Readiness</span>
                <span className="font-bold text-[#245C43]">{readinessScore}% Complete</span>
              </div>
            )}
          </div>

          {/* Navigation Links */}
          <nav className="space-y-1">
            <div className="px-2 text-[10px] font-bold uppercase tracking-wider text-[#858B84] mb-2">
              {role === 'admin' ? 'Officer Workstation' : 'Student Journey'}
            </div>
            {navItems.map((item) => {
              const Icon = item.icon;
              const isActive =
                currentRoute === item.route ||
                (item.route !== '/' && currentRoute.startsWith(item.route) && item.route !== '/student/documents');

              return (
                <button
                  key={item.route}
                  onClick={() => navigateTo(item.route)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-semibold transition-all ${
                    isActive
                      ? 'bg-[#EEF7F1] text-[#245C43] shadow-xs border border-[#C4E1CF]/60'
                      : 'text-[#596159] hover:bg-[#FAF6ED] hover:text-[#2E342F]'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <Icon
                      className={`w-4 h-4 ${
                        isActive ? 'text-[#245C43]' : 'text-[#858B84] group-hover:text-[#596159]'
                      }`}
                    />
                    <span>{item.label}</span>
                  </div>
                  {item.badge && (
                    <span
                      className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${item.badgeColor}`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}

            {/* Quick Visual Guide Trigger */}
            <div className="pt-2 space-y-1.5">
              <button
                onClick={() => setInstructionGuideOpen(true)}
                className="w-full flex items-center justify-between px-3 py-2 bg-[#EEF7F1]/80 hover:bg-[#DDEFE4] text-[#153B2E] rounded-xl text-xs font-semibold border border-[#C4E1CF] transition-all shadow-2xs"
              >
                <div className="flex items-center gap-2.5">
                  <BookOpen className="w-4 h-4 text-[#2F7454]" />
                  <span>{language === 'ta' ? 'வழிகாட்டி வரைபடம்' : 'Visual Guide'}</span>
                </div>
                <span className="text-[10px] bg-[#2F7454] text-white font-bold px-1.5 py-0.5 rounded">
                  Pictograms
                </span>
              </button>

              <button
                onClick={() => navigateTo('/login')}
                className="w-full flex items-center justify-between px-3 py-2 bg-[#F1E8D8]/90 hover:bg-[#DED4C3] text-[#465047] rounded-xl text-xs font-semibold border border-[#DED4C3] transition-all shadow-2xs"
              >
                <div className="flex items-center gap-2.5">
                  <LogIn className="w-4 h-4 text-[#596159]" />
                  <span>{language === 'ta' ? 'உள்நுழைவு / மாற்று' : 'Login / Switch Role'}</span>
                </div>
                <span className="text-[10px] bg-[#DED4C3] text-[#465047] font-bold px-1.5 py-0.5 rounded">
                  Autofill
                </span>
              </button>
            </div>
          </nav>
        </div>

        {/* Bottom Trust & Compliance Card */}
        <div className="p-3 bg-gradient-to-br from-slate-50 to-slate-100 rounded-xl border border-[#DED4C3] text-[#465047] text-[11px] space-y-1">
          <div className="flex items-center gap-1.5 font-bold text-[#374039] text-xs">
            <ShieldAlert className="w-3.5 h-3.5 text-[#2F7454]" />
            <span>Human-In-The-Loop</span>
          </div>
          <p className="text-[#6B716A] leading-relaxed">
            Screening tools assist verification. Decisions require authorized human officer review.
          </p>
        </div>
      </aside>

      {/* Mobile Bottom Navigation Bar */}
      <div className="md:hidden fixed bottom-0 left-0 right-0 z-30 bg-white border-t border-[#DED4C3] shadow-lg px-2 py-1.5 flex items-center justify-around">
        {navItems.slice(0, 5).map((item) => {
          const Icon = item.icon;
          const isActive = currentRoute === item.route;
          return (
            <button
              key={item.route}
              onClick={() => navigateTo(item.route)}
              className={`flex flex-col items-center gap-0.5 py-1 px-2 rounded-lg text-[10px] font-medium transition-colors ${
                isActive ? 'text-[#245C43] font-bold' : 'text-[#6B716A] hover:text-[#374039]'
              }`}
            >
              <div className="relative">
                <Icon className="w-5 h-5" />
                {item.badge && (
                  <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-amber-500 ring-2 ring-white"></span>
                )}
              </div>
              <span className="truncate max-w-[56px]">{item.label}</span>
            </button>
          );
        })}
      </div>
    </>
  );
};
