import React from 'react';
import { Upload, LogIn, CheckCircle2, X } from 'lucide-react';
import { useApp } from '../context/AppContext';

interface InstructionGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InstructionGuideModal: React.FC<InstructionGuideModalProps> = ({ isOpen, onClose }) => {
  const { language } = useApp();

  if (!isOpen) return null;

  const steps = language === 'ta'
    ? [
        { title: 'உள்நுழைக', text: 'உங்கள் கணக்கில் உள்நுழையுங்கள்.', icon: LogIn },
        { title: 'ஆவணங்களை பதிவேற்றுங்கள்', text: 'தேவையான ஆவணங்களைத் தேர்ந்தெடுத்து பதிவேற்றுங்கள்.', icon: Upload },
        { title: 'நிலையை சரிபார்க்கவும்', text: 'உங்கள் விண்ணப்ப நிலையை சரிபார்க்கவும்.', icon: CheckCircle2 },
      ]
    : [
        { title: 'Login', text: 'Sign in to start your application.', icon: LogIn },
        { title: 'Upload Documents', text: 'Choose and upload your required documents.', icon: Upload },
        { title: 'Check Status', text: 'Check your application status here.', icon: CheckCircle2 },
      ];

  return (
    <div className="fixed inset-0 z-[100] bg-[#2E342F]/45 backdrop-blur-sm flex items-center justify-center p-4">
      <div className="w-full max-w-2xl rounded-2xl bg-[#FFFDF7] border border-[#DED4C3] shadow-2xl overflow-hidden">
        <div className="flex items-center justify-between px-5 py-4 bg-[#174A38] text-white">
          <div>
            <h2 className="text-base font-bold">{language === 'ta' ? 'வழிகாட்டி' : 'Quick Guide'}</h2>
            <p className="text-xs text-[#DDEFE4] mt-0.5">{language === 'ta' ? 'தேவையான படிகள் மட்டும்.' : 'Only the steps you need.'}</p>
          </div>
          <button onClick={onClose} className="p-2 rounded-lg hover:bg-white/10" aria-label="Close guide">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="grid gap-3 p-5 sm:grid-cols-3">
          {steps.map((step, index) => {
            const Icon = step.icon;
            return (
              <div key={step.title} className="rounded-xl border border-[#DED4C3] bg-[#FAF6ED] p-4">
                <div className="w-9 h-9 rounded-lg bg-[#DDEFE4] text-[#245C43] flex items-center justify-center mb-3">
                  <Icon className="w-4 h-4" />
                </div>
                <div className="text-[10px] font-bold uppercase tracking-wider text-[#7A8279] mb-1">Step {index + 1}</div>
                <h3 className="text-sm font-bold text-[#2E342F]">{step.title}</h3>
                <p className="text-xs text-[#596159] mt-1 leading-relaxed">{step.text}</p>
              </div>
            );
          })}
        </div>

        <div className="px-5 pb-5 flex justify-end">
          <button onClick={onClose} className="px-4 py-2 rounded-lg bg-[#2F7454] hover:bg-[#1C4937] text-white text-xs font-bold">
            {language === 'ta' ? 'முடிந்தது' : 'Done'}
          </button>
        </div>
      </div>
    </div>
  );
};
