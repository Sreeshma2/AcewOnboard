import React from 'react';
import {
  User,
  FileCheck2,
  ScanFace,
  ClipboardCheck,
  CreditCard,
  QrCode,
  CheckCircle2,
  ChevronRight,
  Sparkles,
  PlusCircle,
  RotateCcw,
  BookOpen,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export interface StepDef {
  id: number;
  key: string;
  name: string;
  shortName: string;
  route: string;
  icon: React.ComponentType<{ className?: string }>;
  isComplete: (app: any) => boolean;
}

export const APPLICATION_STEPS: StepDef[] = [
  {
    id: 1,
    key: 'profile',
    name: '1. Profile & Cutoff Details',
    shortName: 'Profile',
    route: '/student/profile',
    icon: User,
    isComplete: (app) => {
      // Profile complete if name, email, phone, and HSC marks/cutoff entered
      return Boolean(
        app.studentProfile.fullName &&
        app.studentProfile.email &&
        app.studentProfile.phone &&
        (app.studentProfile.cutoffScore || app.studentProfile.registerNumber)
      );
    },
  },
  {
    id: 2,
    key: 'documents',
    name: '2. Document Uploads & OCR',
    shortName: 'Documents',
    route: '/student/documents',
    icon: FileCheck2,
    isComplete: (app) => {
      // At least mandatory documents uploaded
      const mandatoryDocs = app.documents.filter((d: any) => d.isMandatory);
      return mandatoryDocs.length > 0 && mandatoryDocs.every((d: any) => d.status === 'Verified' || d.status === 'Uploaded');
    },
  },
  {
    id: 3,
    key: 'identity',
    name: '3. Identity & Presence Check',
    shortName: 'Identity',
    route: '/student/identity-check',
    icon: ScanFace,
    isComplete: (app) => {
      return (
        app.identityCheck.status === 'passed' ||
        app.identityCheck.livenessResult === 'Passed' ||
        app.identityCheck.manuallyVerifiedBy !== undefined
      );
    },
  },
  {
    id: 4,
    key: 'verification',
    name: '4. Academic Scrutiny & Clearance',
    shortName: 'Scrutiny',
    route: '/student/verification',
    icon: ClipboardCheck,
    isComplete: (app) => {
      // 12th marksheet verified or no remaining correction
      const mark12 = app.documents.find((d: any) => d.id === 'doc-12th');
      return !mark12 || mark12.status === 'Verified';
    },
  },
  {
    id: 5,
    key: 'fees',
    name: '5. Campus Fees & Hostel Allotment',
    shortName: 'Fees & Hostel',
    route: '/student/onboarding',
    icon: CreditCard,
    isComplete: (app) => {
      return Boolean(app.studentProfile.feePaid);
    },
  },
  {
    id: 6,
    key: 'receipt',
    name: '6. Digital Verification Pass & QR',
    shortName: 'Admission Pass',
    route: '/student/receipt',
    icon: QrCode,
    isComplete: (app) => {
      return app.readinessScore >= 95 || app.isAcewReady;
    },
  },
];

interface ApplicationProgressStepperProps {
  currentStepIndex?: number;
}

export const ApplicationProgressStepper: React.FC<ApplicationProgressStepperProps> = ({
  currentStepIndex,
}) => {
  const appContext = useApp();
  const {
    currentRoute,
    navigateTo,
    readinessScore,
    studentProfile,
    isDemoMode,
    setIsDemoMode,
    resetToDemo,
    startFreshApplication,
    addToast,
  } = appContext;

  // Determine active step from route if not provided
  let activeIndex = currentStepIndex;
  if (activeIndex === undefined) {
    if (currentRoute.includes('/student/profile')) activeIndex = 1;
    else if (currentRoute.includes('/student/documents')) activeIndex = 2;
    else if (currentRoute.includes('/student/identity')) activeIndex = 3;
    else if (currentRoute.includes('/student/verification')) activeIndex = 4;
    else if (currentRoute.includes('/student/onboarding')) activeIndex = 5;
    else if (currentRoute.includes('/student/receipt')) activeIndex = 6;
    else activeIndex = 1;
  }

  const handleStartNew = () => {
    if (startFreshApplication) {
      startFreshApplication();
    } else {
      addToast('Started fresh applicant registration.', 'info');
    }
    navigateTo('/student/profile');
  };

  const handleLoadDemo = () => {
    resetToDemo();
    setIsDemoMode(true);
    navigateTo('/student/dashboard');
  };

  return (
    <div className="bg-white rounded-2xl border border-[#DED4C3] shadow-sm p-4 sm:p-5 mb-6">
      {/* Top Bar with Mode Controls & Live Progress */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 pb-4 border-b border-[#EEE7DA]">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-[#2F7454] to-[#1C4937] text-white flex items-center justify-center font-black text-sm shadow-xs">
            {studentProfile.fullName ? studentProfile.fullName[0] : 'S'}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-sm font-bold text-[#2E342F]">
                {studentProfile.fullName || 'New Applicant'}
              </span>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-[#F1E8D8] text-[#465047] font-semibold border border-[#DED4C3]">
                {studentProfile.applicationId}
              </span>
              {isDemoMode ? (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-50 text-amber-800 border border-amber-200">
                  Sample Case (Ananya)
                </span>
              ) : (
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-[#EEF7F1] text-[#1C4937] border border-[#C4E1CF]">
                  Live Custom Mode
                </span>
              )}
            </div>
            <p className="text-[11px] text-[#6B716A] mt-0.5">
              Target: <span className="font-semibold text-[#465047]">{studentProfile.programme}</span>
              {studentProfile.cutoffScore ? (
                <span> • Cutoff: <strong className="text-[#245C43] font-mono">{studentProfile.cutoffScore.toFixed(2)}/200</strong></span>
              ) : null}
            </p>
          </div>
        </div>

        {/* Action Switchers */}
        <div className="flex flex-wrap items-center gap-2">
          <button
            onClick={handleStartNew}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-bold rounded-xl bg-[#2F7454] hover:bg-[#245C43] text-white shadow-xs transition-colors"
            title="Start a new application from 0% with your own custom details"
          >
            <PlusCircle className="w-3.5 h-3.5" />
            <span>New Application (0%)</span>
          </button>

          <button
            onClick={handleLoadDemo}
            className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold rounded-xl bg-[#F1E8D8] hover:bg-[#DED4C3] text-[#465047] transition-colors"
            title="Load sample review case with 12th marksheet initial mismatch"
          >
            <RotateCcw className="w-3.5 h-3.5 text-[#6B716A]" />
            <span>Load Demo (72%)</span>
          </button>
        </div>
      </div>

      {/* Progress Bar & Readiness Metric */}
      <div className="mt-4">
        <div className="flex items-center justify-between text-xs mb-1.5">
          <span className="font-bold text-[#465047] flex items-center gap-1.5">
            <Sparkles className="w-3.5 h-3.5 text-[#2F7454]" />
            <span>Overall Admission Readiness</span>
          </span>
          <span className="font-mono font-extrabold text-[#245C43] text-sm">
            {readinessScore}% Complete
          </span>
        </div>
        <div className="w-full h-2.5 bg-[#F1E8D8] rounded-full overflow-hidden p-0.5 border border-[#DED4C3]">
          <div
            className="h-full rounded-full transition-all duration-700 bg-gradient-to-r from-[#2F7454] via-[#245C43] to-[#7DB392]"
            style={{ width: `${Math.max(readinessScore, 5)}%` }}
          />
        </div>
      </div>

      {/* 6 Interactive Stage Nodes */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2 mt-5">
        {APPLICATION_STEPS.map((step) => {
          const StepIcon = step.icon;
          const isDone = step.isComplete(appContext);
          const isActive = step.id === activeIndex;

          return (
            <button
              key={step.id}
              onClick={() => navigateTo(step.route)}
              className={`p-2.5 rounded-xl border text-left transition-all flex flex-col justify-between group ${
                isActive
                  ? 'bg-[#EEF7F1]/70 border-[#7DB392] ring-2 ring-[#7DB392]/20 shadow-xs'
                  : isDone
                  ? 'bg-emerald-50/50 border-emerald-200 hover:border-emerald-300'
                  : 'bg-[#FAF6ED]/60 border-[#DED4C3] hover:border-[#CEC4B3] hover:bg-white'
              }`}
            >
              <div className="flex items-center justify-between gap-1 w-full mb-1.5">
                <div
                  className={`w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold ${
                    isActive
                      ? 'bg-[#2F7454] text-white'
                      : isDone
                      ? 'bg-emerald-600 text-white'
                      : 'bg-[#DED4C3] text-[#596159] group-hover:bg-[#C9BEAC]'
                  }`}
                >
                  {isDone ? <CheckCircle2 className="w-4 h-4" /> : step.id}
                </div>
                {isDone && (
                  <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/70 px-1.5 py-0.2 rounded">
                    Done
                  </span>
                )}
                {isActive && !isDone && (
                  <span className="text-[10px] font-bold text-[#245C43] bg-[#DDEFE4] px-1.5 py-0.2 rounded animate-pulse">
                    Active
                  </span>
                )}
              </div>

              <div>
                <p
                  className={`text-xs font-bold leading-tight ${
                    isActive
                      ? 'text-[#153B2E]'
                      : isDone
                      ? 'text-[#374039]'
                      : 'text-[#596159]'
                  }`}
                >
                  {step.shortName}
                </p>
                <p className="text-[10px] text-[#6B716A] truncate mt-0.5">
                  Step {step.id} of 6
                </p>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
};
