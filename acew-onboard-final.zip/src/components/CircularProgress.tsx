import React from 'react';

interface CircularProgressProps {
  score: number;
  completedTasks: number;
  totalTasks: number;
  size?: number;
  strokeWidth?: number;
}

export const CircularProgress: React.FC<CircularProgressProps> = ({
  score,
  completedTasks,
  totalTasks,
  size = 180,
  strokeWidth = 14,
}) => {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const clampedScore = Math.min(Math.max(score, 0), 100);
  const strokeDashoffset = circumference - (clampedScore / 100) * circumference;

  // Color selection based on progress thresholds
  let strokeColor = '#2F7454'; // Royal blue
  if (clampedScore >= 100) {
    strokeColor = '#16A34A'; // Success green
  } else if (clampedScore < 50) {
    strokeColor = '#D97706'; // Warning amber
  }

  const ariaLabel = `ACEW Readiness Score: ${clampedScore} percent, ${completedTasks} of ${totalTasks} tasks complete.`;

  return (
    <div
      className="relative flex flex-col items-center justify-center"
      role="progressbar"
      aria-valuenow={clampedScore}
      aria-valuemin={0}
      aria-valuemax={100}
      aria-label={ariaLabel}
    >
      <svg
        width={size}
        height={size}
        className="transform -rotate-90 origin-center"
        aria-hidden="true"
      >
        {/* Background track circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke="#E2E8F0"
          strokeWidth={strokeWidth}
          fill="transparent"
          strokeLinecap="round"
        />
        {/* Animated progress circle */}
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          stroke={strokeColor}
          strokeWidth={strokeWidth}
          fill="transparent"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          className="transition-all duration-700 ease-out"
        />
      </svg>

      {/* Center Label */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center p-2">
        <span className="text-3xl font-extrabold tracking-tight text-[#2E342F]">
          {clampedScore}%
        </span>
        <span className="text-xs font-semibold text-[#6B716A] uppercase tracking-wider mt-0.5">
          Readiness
        </span>
        <span className="text-[11px] text-[#596159] font-medium mt-1">
          {completedTasks}/{totalTasks} tasks
        </span>
      </div>

      {/* Screen reader only live update */}
      <span className="sr-only">{ariaLabel}</span>
    </div>
  );
};
