import React, { useState } from 'react';
import {
  ShieldCheck,
  Bell,
  Search,
  Languages,
  User,
  HelpCircle,
  CheckCircle2,
  AlertTriangle,
  FileText,
  LogOut,
  ChevronDown,
  RotateCcw,
  Sparkles,
  Shield,
  Layers,
  BookOpen,
  LogIn,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const Header: React.FC = () => {
  const {
    role,
    setRole,
    language,
    setLanguage,
    studentProfile,
    isDemoMode,
    navigateTo,
    resetToDemo,
    toasts,
    setInstructionGuideOpen,
  } = useApp();

  const [isNotifOpen, setIsNotifOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const notifications = [
    {
      id: 'n1',
      title: 'Class 12 Marksheet Correction Required',
      desc: 'Name differs from registered application (Ananya Krishnan S vs Ananya Krishnan).',
      time: '14 Sep, 10:15 AM',
      type: 'warning',
      route: '/student/verification',
    },
    {
      id: 'n2',
      title: 'Identity Check: Review Required',
      desc: 'Liveness passed. Face match inconclusive (68%) due to ID photo resolution.',
      time: '15 Sep, 08:34 PM',
      type: 'warning',
      route: '/student/identity-check',
    },
    {
      id: 'n3',
      title: 'Medical Declaration Pending',
      desc: 'Form required by Campus Health Centre before final enrollment.',
      time: '15 Sep, 09:00 AM',
      type: 'info',
      route: '/student/onboarding',
    },
    {
      id: 'n4',
      title: 'Tuition Fee Payment Ready',
      desc: 'Semester 1 fee portal is open for confirmed applicants.',
      time: '15 Sep, 09:30 AM',
      type: 'info',
      route: '/student/onboarding',
    },
  ];

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;
    const q = searchQuery.toLowerCase();
    if (q.includes('doc') || q.includes('mark') || q.includes('tc')) {
      navigateTo(role === 'admin' ? '/admin/applications' : '/student/documents');
    } else if (q.includes('ident') || q.includes('live') || q.includes('face')) {
      navigateTo(role === 'admin' ? '/admin/applications' : '/student/identity-check');
    } else if (q.includes('verif') || q.includes('correct')) {
      navigateTo(role === 'admin' ? '/admin/applications' : '/student/verification');
    } else if (q.includes('fee') || q.includes('hostel') || q.includes('orient')) {
      navigateTo('/student/onboarding');
    } else if (q.includes('help') || q.includes('faq')) {
      navigateTo('/help');
    } else {
      navigateTo('/help');
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-[#174A38] text-white shadow-md border-b border-[#25392F]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          {/* Brand Identity */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => navigateTo(role === 'admin' ? '/admin/dashboard' : '/student/dashboard')}
              className="flex items-center gap-2.5 text-left group focus:outline-none focus:ring-2 focus:ring-[#7DB392] rounded-lg p-1"
              title="Return to Dashboard"
            >
              <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-[#2F7454] to-[#7DB392] flex items-center justify-center text-white shadow-sm ring-1 ring-white/20">
                <ShieldCheck className="w-6 h-6" />
              </div>
              <div className="hidden sm:block">
                <div className="flex items-center gap-2">
                  <span className="font-display text-lg font-extrabold tracking-tight text-white leading-tight">
                    ACEW Onboard
                  </span>
                  <span className="text-[10px] uppercase font-bold tracking-widest bg-[#EEF7F1]/30 text-[#C4E1CF] px-2 py-0.5 rounded-full border border-[#7DB392]/30">
                    Smart Campus
                  </span>
                </div>
                <p className="text-[11px] text-[#B4B9B2] font-medium line-clamp-1">
                  Admission, Compliance, Engagement &amp; Workflow
                </p>
              </div>
            </button>
          </div>

          {/* Quick Search */}
          <form
            onSubmit={handleSearchSubmit}
            className="hidden md:flex flex-1 max-w-xs lg:max-w-md relative"
          >
            <Search className="w-4 h-4 text-[#858B84] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder={
                language === 'ta'
                  ? 'ஆவணங்கள், நிலையைத் தேடவும்...'
                  : 'Search documents, tasks, rules...'
              }
              className="w-full pl-9 pr-4 py-1.5 bg-[#26382F]/80 hover:bg-[#26382F] focus:bg-[#1D2D26] text-sm text-slate-100 placeholder-slate-400 rounded-lg border border-[#33473D] focus:outline-none focus:border-[#7DB392] focus:ring-1 focus:ring-[#7DB392] transition-colors"
            />
          </form>

          {/* Right Controls */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Demo Mode Badge */}
            {isDemoMode && (
              <span className="hidden xl:inline-flex items-center gap-1.5 text-xs font-semibold px-2.5 py-1 rounded-full bg-amber-500/20 text-amber-200 border border-amber-400/30">
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 animate-pulse"></span>
                Demo mode
              </span>
            )}

            {/* Role Switcher */}
            <div className="inline-flex rounded-lg bg-[#26382F]/90 p-0.5 border border-[#33473D] text-xs">
              <button
                type="button"
                onClick={() => setRole('student')}
                className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                  role === 'student'
                    ? 'bg-[#2F7454] text-white shadow-xs'
                    : 'text-[#B4B9B2] hover:text-white'
                }`}
              >
                Student
              </button>
              <button
                type="button"
                onClick={() => setRole('admin')}
                className={`px-2.5 py-1 rounded-md font-semibold transition-all ${
                  role === 'admin'
                    ? 'bg-[#2F7454] text-white shadow-xs'
                    : 'text-[#B4B9B2] hover:text-white'
                }`}
              >
                Officer
              </button>
            </div>

            {/* Pictographic Process Instructions Trigger */}
            <button
              onClick={() => setInstructionGuideOpen(true)}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-[#2F7454]/90 hover:bg-[#2F7454] text-white shadow-xs border border-[#7DB392]/40 transition-colors"
              title="Step-by-step pictographic instructions for buttons & document uploading"
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Instructions</span>
            </button>

            {/* Language Toggle */}
            <button
              onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
              className="flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg bg-[#26382F]/80 hover:bg-[#3E4740] text-[#D5D9D3] border border-[#33473D] transition-colors"
              title="Toggle English / தமிழ்"
            >
              <Languages className="w-3.5 h-3.5 text-[#7DB392]" />
              <span>{language === 'en' ? 'தமிழ்' : 'English'}</span>
            </button>

            {/* Notifications Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsNotifOpen(!isNotifOpen)}
                className="relative p-2 text-[#B4B9B2] hover:text-white hover:bg-[#26382F] rounded-lg transition-colors focus:outline-none focus:ring-2 focus:ring-[#7DB392]"
                aria-label="View notifications"
              >
                <Bell className="w-5 h-5" />
                <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-amber-500 rounded-full ring-2 ring-[#174A38]"></span>
              </button>

              {isNotifOpen && (
                <div className="absolute right-0 mt-2 w-80 sm:w-96 bg-white text-[#2E342F] rounded-xl shadow-xl border border-[#DED4C3] z-50 overflow-hidden">
                  <div className="p-3.5 bg-[#FAF6ED] border-b border-[#DED4C3] flex items-center justify-between">
                    <span className="text-xs font-bold uppercase tracking-wider text-[#596159]">
                      Admission Alerts &amp; Updates
                    </span>
                    <span className="text-[11px] font-semibold text-[#245C43] bg-[#EEF7F1] px-2 py-0.5 rounded-full">
                      4 unread
                    </span>
                  </div>
                  <div className="max-h-80 overflow-y-auto divide-y divide-slate-100">
                    {notifications.map((n) => (
                      <button
                        key={n.id}
                        onClick={() => {
                          setIsNotifOpen(false);
                          navigateTo(n.route);
                        }}
                        className="w-full text-left p-3 hover:bg-[#FAF6ED] transition-colors flex items-start gap-3"
                      >
                        <div className="mt-0.5">
                          {n.type === 'warning' ? (
                            <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
                          ) : (
                            <FileText className="w-4 h-4 text-[#2F7454] shrink-0" />
                          )}
                        </div>
                        <div className="flex-1">
                          <p className="text-xs font-bold text-[#2E342F]">{n.title}</p>
                          <p className="text-[11px] text-[#596159] mt-0.5 line-clamp-2">{n.desc}</p>
                          <span className="text-[10px] text-[#858B84] mt-1 block">{n.time}</span>
                        </div>
                      </button>
                    ))}
                  </div>
                  <div className="p-2.5 bg-[#FAF6ED] border-t border-[#DED4C3] text-center">
                    <button
                      onClick={() => {
                        setIsNotifOpen(false);
                        navigateTo(role === 'admin' ? '/admin/applications' : '/student/verification');
                      }}
                      className="text-xs font-semibold text-[#2F7454] hover:text-[#1C4937]"
                    >
                      View All Required Actions &rarr;
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Help Shortcut */}
            <button
              onClick={() => navigateTo('/help')}
              className="p-2 text-[#B4B9B2] hover:text-white hover:bg-[#26382F] rounded-lg transition-colors focus:outline-none"
              title="Help Centre & FAQs"
            >
              <HelpCircle className="w-5 h-5" />
            </button>

            {/* Login / Switch Account Shortcut */}
            <button
              onClick={() => navigateTo('/login')}
              className="p-2 text-[#B4B9B2] hover:text-white hover:bg-[#26382F] rounded-lg transition-colors focus:outline-none"
              title="Login Portal & Password Autofill"
            >
              <LogIn className="w-5 h-5" />
            </button>

            {/* Profile Dropdown */}
            <div className="relative">
              <button
                onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                className="flex items-center gap-2 pl-2 pr-2.5 py-1 rounded-lg hover:bg-[#26382F] text-left transition-colors focus:outline-none"
              >
                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-[#4F936E] to-[#1C4937] flex items-center justify-center text-white text-xs font-bold border border-white/20">
                  {role === 'admin' ? 'MS' : 'AK'}
                </div>
                <div className="hidden lg:block">
                  <div className="text-xs font-semibold text-white">
                    {role === 'admin' ? 'Dr. M. Sundaram' : studentProfile.fullName}
                  </div>
                  <div className="text-[10px] text-[#B4B9B2]">
                    {role === 'admin' ? 'Sr. Admission Officer' : studentProfile.applicationId}
                  </div>
                </div>
                <ChevronDown className="w-3.5 h-3.5 text-[#858B84]" />
              </button>

              {isProfileMenuOpen && (
                <div className="absolute right-0 mt-2 w-64 bg-white text-[#2E342F] rounded-xl shadow-xl border border-[#DED4C3] z-50 p-2">
                  <div className="p-2 border-b border-[#EEE7DA]">
                    <p className="text-xs font-bold text-[#2E342F]">
                      {role === 'admin' ? 'Dr. M. Sundaram' : studentProfile.fullName}
                    </p>
                    <p className="text-[11px] text-[#6B716A]">
                      {role === 'admin' ? 'Dean of Admissions' : studentProfile.email}
                    </p>
                    <p className="text-[10px] font-semibold text-[#245C43] mt-1">
                      {role === 'admin' ? 'Role: Staff Reviewer' : `App ID: ${studentProfile.applicationId}`}
                    </p>
                  </div>
                  <div className="py-1">
                    <button
                      onClick={() => {
                        setIsProfileMenuOpen(false);
                        navigateTo('/student/profile');
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-[#465047] hover:bg-[#F1E8D8] rounded-lg"
                    >
                      <User className="w-4 h-4 text-[#858B84]" />
                      My Profile
                    </button>
                    <button
                      onClick={() => {
                        setIsProfileMenuOpen(false);
                        navigateTo(role === 'admin' ? '/admin/rules' : '/student/receipt');
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-[#465047] hover:bg-[#F1E8D8] rounded-lg"
                    >
                      <Layers className="w-4 h-4 text-[#858B84]" />
                      {role === 'admin' ? 'Admission Rules Config' : 'Verification Receipt'}
                    </button>
                    <button
                      onClick={() => {
                        setIsProfileMenuOpen(false);
                        resetToDemo();
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-amber-700 hover:bg-amber-50 rounded-lg"
                    >
                      <RotateCcw className="w-4 h-4 text-amber-500" />
                      Reset Demo State (72%)
                    </button>
                  </div>
                  <div className="border-t border-[#EEE7DA] pt-1">
                    <button
                      onClick={() => {
                        setIsProfileMenuOpen(false);
                        navigateTo('/login');
                      }}
                      className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-red-600 hover:bg-red-50 rounded-lg"
                    >
                      <LogOut className="w-4 h-4 text-red-500" />
                      Switch Account / Logout
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </header>
  );
};
