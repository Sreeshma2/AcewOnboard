import React, { useState, useRef, useEffect } from 'react';
import {
  Camera,
  X,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  ShieldAlert,
  UserCheck,
  Eye,
  Smile,
  ArrowLeft,
  ArrowRight,
  Info,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

interface LivenessCameraModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (result: {
    liveness: 'Passed';
    faceMatch: 'Match' | 'Review required';
    confidence: number;
    reason?: string;
  }) => void;
}

type LivenessStep = 'consent' | 'camera_setup' | 'action_sequence' | 'processing' | 'result';

export const LivenessCameraModal: React.FC<LivenessCameraModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
}) => {
  const { identityCheck, setIdentityConsent, requestManualIdentityReview, addToast } = useApp();

  const [step, setStep] = useState<LivenessStep>(identityCheck.hasConsent ? 'camera_setup' : 'consent');
  const [consentAgreed, setConsentAgreed] = useState(identityCheck.hasConsent);
  const [cameraStream, setCameraStream] = useState<MediaStream | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);

  // Randomized liveness instructions
  const actionsList = [
    { text: 'Look directly at the camera', icon: Eye },
    { text: 'Slowly turn your head slightly to the left', icon: ArrowLeft },
    { text: 'Slowly turn your head slightly to the right', icon: ArrowRight },
    { text: 'Blink once naturally', icon: Eye },
    { text: 'Smile briefly', icon: Smile },
  ];

  const [currentActionIndex, setCurrentActionIndex] = useState(0);
  const [progressPercent, setProgressPercent] = useState(0);
  const [chosenDemoOutcome, setChosenDemoOutcome] = useState<'review_required' | 'passed'>('review_required');

  const videoRef = useRef<HTMLVideoElement>(null);

  // Stop camera on unmount
  useEffect(() => {
    return () => {
      if (cameraStream) {
        cameraStream.getTracks().forEach((track) => track.stop());
      }
    };
  }, [cameraStream]);

  if (!isOpen) return null;

  const startCamera = async () => {
    setCameraError(null);
    try {
      if (navigator.mediaDevices && navigator.mediaDevices.getUserMedia) {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: 'user', width: { ideal: 640 }, height: { ideal: 480 } },
        });
        setCameraStream(stream);
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      }
      setStep('action_sequence');
      runLivenessSequence();
    } catch (err: any) {
      console.warn('Camera access denied or unavailable, using simulation:', err);
      setCameraError('Camera access unavailable in this environment. Continuing with simulated presence detection.');
      // Continue with simulated video canvas
      setStep('action_sequence');
      runLivenessSequence();
    }
  };

  const runLivenessSequence = () => {
    setCurrentActionIndex(0);
    setProgressPercent(15);

    const stepInterval = setInterval(() => {
      setCurrentActionIndex((prev) => {
        const next = prev + 1;
        if (next >= actionsList.length) {
          clearInterval(stepInterval);
          // Move to processing
          setStep('processing');
          setTimeout(() => {
            finishVerification();
          }, 2400);
          return prev;
        }
        setProgressPercent(Math.round(((next + 1) / actionsList.length) * 100));
        return next;
      });
    }, 1400);
  };

  const finishVerification = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
    }

    if (chosenDemoOutcome === 'passed') {
      onSuccess({
        liveness: 'Passed',
        faceMatch: 'Match',
        confidence: 96,
        reason: 'Face matches government identity document photograph with high clarity.',
      });
    } else {
      onSuccess({
        liveness: 'Passed',
        faceMatch: 'Review required',
        confidence: 68,
        reason: 'The identity photograph is low resolution, so the face similarity is inconclusive.',
      });
    }
    onClose();
  };

  const handleManualVerificationClick = () => {
    if (cameraStream) {
      cameraStream.getTracks().forEach((track) => track.stop());
    }
    requestManualIdentityReview();
    onClose();
  };

  const CurrentIcon = actionsList[currentActionIndex]?.icon || Eye;

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#1D2D26]/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative w-full max-w-lg bg-white rounded-2xl shadow-2xl border border-[#DED4C3] overflow-hidden text-[#2E342F]">
        {/* Modal Header */}
        <div className="px-5 py-4 bg-[#174A38] text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#EEF7F1]/30 text-[#A6CEB7] flex items-center justify-center border border-[#7DB392]/40">
              <Camera className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-bold tracking-tight">Consent-Based Identity Check</h3>
              <p className="text-[11px] text-[#B4B9B2]">Assistive liveness &amp; face cross-match</p>
            </div>
          </div>

          <button
            onClick={() => {
              if (cameraStream) cameraStream.getTracks().forEach((t) => t.stop());
              onClose();
            }}
            className="text-[#858B84] hover:text-white p-1 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-6">
          {/* STEP 1: Consent */}
          {step === 'consent' && (
            <div className="space-y-4 text-xs text-[#465047]">
              <div className="p-3.5 bg-[#EEF7F1] border border-[#C4E1CF] rounded-xl space-y-2">
                <div className="flex items-center gap-2 font-bold text-[#153B2E] text-sm">
                  <ShieldAlert className="w-4 h-4 text-[#245C43]" />
                  <span>Privacy Notice &amp; Student Rights</span>
                </div>
                <p className="leading-relaxed">
                  This identity check confirms real-time presence (liveness) and compares your live selfie with your uploaded government ID photo to prevent impersonation.
                </p>
                <ul className="list-disc pl-4 space-y-1 text-[#465047] font-medium">
                  <li>Your raw video stream is processed in memory and not stored permanently.</li>
                  <li>This check is an assistive signal only; it will never automatically reject you.</li>
                  <li>You have the right to choose in-person / manual officer verification instead.</li>
                </ul>
              </div>

              <div className="flex items-start gap-3 p-3 bg-[#FAF6ED] border border-[#DED4C3] rounded-xl">
                <input
                  type="checkbox"
                  id="identity-consent-cb"
                  checked={consentAgreed}
                  onChange={(e) => setConsentAgreed(e.target.checked)}
                  className="mt-0.5 h-4 w-4 rounded border-[#CEC4B3] text-[#2F7454] focus:ring-[#2F7454]"
                />
                <label htmlFor="identity-consent-cb" className="text-xs text-[#374039] font-medium cursor-pointer">
                  I give explicit consent to ACEW Onboard to open my camera for assistive liveness screening and ID photo cross-match.
                </label>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={handleManualVerificationClick}
                  className="text-xs font-semibold text-[#596159] hover:text-[#2E342F] underline"
                >
                  Skip &amp; Request Manual Verification
                </button>
                <button
                  type="button"
                  disabled={!consentAgreed}
                  onClick={() => {
                    setIdentityConsent(true);
                    setStep('camera_setup');
                  }}
                  className="px-4 py-2 bg-[#2F7454] hover:bg-[#245C43] disabled:opacity-50 text-white font-semibold rounded-xl text-xs shadow-xs"
                >
                  Continue &rarr;
                </button>
              </div>
            </div>
          )}

          {/* STEP 2: Pre-camera instructions & branch selector for demo */}
          {step === 'camera_setup' && (
            <div className="space-y-4 text-xs">
              <div className="text-center space-y-1">
                <h4 className="text-sm font-bold text-[#2E342F]">Prepare for Liveness Screening</h4>
                <p className="text-[#6B716A]">
                  Please ensure your face is clearly visible, well lit, and no one else is in the camera frame.
                </p>
              </div>

              <div className="grid grid-cols-2 gap-3 text-center">
                <div className="p-3 bg-[#FAF6ED] border border-[#DED4C3] rounded-xl">
                  <span className="font-bold text-[#374039] block">Lighting</span>
                  <span className="text-[#6B716A] text-[11px]">Avoid strong backlights or glare</span>
                </div>
                <div className="p-3 bg-[#FAF6ED] border border-[#DED4C3] rounded-xl">
                  <span className="font-bold text-[#374039] block">Position</span>
                  <span className="text-[#6B716A] text-[11px]">Center your face inside the guide</span>
                </div>
              </div>

              {/* Demo Mode Branch Selector */}
              <div className="p-3 bg-amber-50/80 border border-amber-200 rounded-xl space-y-1.5">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-900 block">
                  Demo Simulation Mode Target Outcome:
                </span>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => setChosenDemoOutcome('review_required')}
                    className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold border transition-all ${
                      chosenDemoOutcome === 'review_required'
                        ? 'bg-amber-600 text-white border-amber-700 shadow-xs'
                        : 'bg-white text-[#465047] border-amber-200'
                    }`}
                  >
                    68% Review Required (Spec)
                  </button>
                  <button
                    type="button"
                    onClick={() => setChosenDemoOutcome('passed')}
                    className={`flex-1 py-1.5 px-2 rounded-lg text-xs font-bold border transition-all ${
                      chosenDemoOutcome === 'passed'
                        ? 'bg-green-600 text-white border-green-700 shadow-xs'
                        : 'bg-white text-[#465047] border-green-200'
                    }`}
                  >
                    96% High Match (Passed)
                  </button>
                </div>
              </div>

              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={handleManualVerificationClick}
                  className="text-xs font-semibold text-[#596159] hover:text-[#2E342F] underline"
                >
                  Choose In-Person Verification
                </button>
                <button
                  type="button"
                  onClick={startCamera}
                  className="px-5 py-2.5 bg-[#2F7454] hover:bg-[#245C43] text-white font-semibold rounded-xl text-xs shadow-xs flex items-center gap-2"
                >
                  <Camera className="w-4 h-4" />
                  Start Camera Screening
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: Liveness Sequence in progress */}
          {step === 'action_sequence' && (
            <div className="space-y-4">
              {/* Camera Preview with Oval Overlay */}
              <div className="relative w-full aspect-4/3 bg-[#1D2D26] rounded-xl overflow-hidden flex items-center justify-center border-2 border-[#33473D]">
                {cameraStream ? (
                  <video
                    ref={videoRef}
                    autoPlay
                    playsInline
                    muted
                    className="w-full h-full object-cover transform -scale-x-100"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center text-[#858B84] p-4 text-center">
                    <UserCheck className="w-16 h-16 text-[#7DB392]/80 mb-2 animate-pulse" />
                    <span className="text-xs font-semibold text-[#D5D9D3]">
                      Camera Stream Simulated (Demo Mode)
                    </span>
                    <span className="text-[11px] text-[#858B84] mt-1">
                      Detecting facial landmarks &amp; movement
                    </span>
                  </div>
                )}

                {/* Oval Guide Overlay */}
                <div className="absolute inset-0 pointer-events-none flex items-center justify-center">
                  <div className="w-48 h-60 rounded-[50%] border-3 border-[#7DB392]/80 border-dashed animate-pulse"></div>
                </div>

                {/* Step Banner */}
                <div className="absolute bottom-3 inset-x-3 bg-[#1D2D26]/85 backdrop-blur-xs text-white p-2.5 rounded-xl border border-white/10 flex items-center gap-3">
                  <div className="w-8 h-8 rounded-full bg-[#4F936E] flex items-center justify-center text-white shrink-0">
                    <CurrentIcon className="w-4 h-4 animate-bounce" />
                  </div>
                  <div>
                    <span className="text-[10px] uppercase font-bold text-[#A6CEB7] block">
                      Instruction {currentActionIndex + 1} of {actionsList.length}
                    </span>
                    <span className="text-xs font-bold">
                      {actionsList[currentActionIndex]?.text}
                    </span>
                  </div>
                </div>
              </div>

              {/* Progress bar */}
              <div className="space-y-1">
                <div className="flex justify-between text-[11px] text-[#596159] font-semibold">
                  <span>Liveness Detection</span>
                  <span>{progressPercent}%</span>
                </div>
                <div className="w-full h-2 bg-[#DED4C3] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#2F7454] transition-all duration-300 rounded-full"
                    style={{ width: `${progressPercent}%` }}
                  ></div>
                </div>
              </div>

              {cameraError && (
                <p className="text-[11px] text-amber-700 bg-amber-50 p-2 rounded-lg border border-amber-200">
                  {cameraError}
                </p>
              )}

              <div className="text-center">
                <button
                  type="button"
                  onClick={handleManualVerificationClick}
                  className="text-xs text-[#6B716A] hover:text-[#374039] underline"
                >
                  Difficulty with camera? Request manual verification
                </button>
              </div>
            </div>
          )}

          {/* STEP 4: Processing face cross-match */}
          {step === 'processing' && (
            <div className="py-8 flex flex-col items-center justify-center text-center space-y-4">
              <div className="w-14 h-14 rounded-full bg-[#DDEFE4] text-[#2F7454] flex items-center justify-center animate-spin">
                <RefreshCw className="w-7 h-7" />
              </div>
              <div>
                <h4 className="text-base font-bold text-[#2E342F]">Comparing with Government ID</h4>
                <p className="text-xs text-[#6B716A] mt-1 max-w-xs mx-auto">
                  Performing assistive comparison between live selfie and Aadhaar photo. Please wait...
                </p>
              </div>
              <div className="p-2.5 bg-[#FAF6ED] text-[11px] text-[#596159] rounded-lg border border-[#DED4C3] font-mono">
                Running localized similarity match &amp; liveness validation
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
