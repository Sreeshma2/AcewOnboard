import React from 'react';
import {
  ShieldCheck,
  AlertTriangle,
  CheckCircle2,
  RefreshCw,
  UserCheck,
  Info,
  Clock,
  ExternalLink,
} from 'lucide-react';
import { IdentityCheckState } from '../types';

interface IdentityResultCardProps {
  identityCheck: IdentityCheckState;
  onRetry: () => void;
  onRequestManualReview: () => void;
  onViewPrivacy: () => void;
}

export const IdentityResultCard: React.FC<IdentityResultCardProps> = ({
  identityCheck,
  onRetry,
  onRequestManualReview,
  onViewPrivacy,
}) => {
  const isPassed = identityCheck.status === 'passed';
  const isReviewRequired = identityCheck.status === 'review_required';
  const isFailed = identityCheck.status === 'failed';

  let borderClasses = 'border-[#DED4C3] bg-white';
  let badgeClasses = 'bg-[#F1E8D8] text-[#374039]';
  let badgeText = 'Not Started';

  if (isPassed) {
    borderClasses = 'border-green-200 bg-green-50/30';
    badgeClasses = 'bg-green-100 text-green-800 border border-green-300';
    badgeText = 'Passed (Awaiting Officer Sign-off)';
  } else if (isReviewRequired) {
    borderClasses = 'border-amber-200 bg-amber-50/40';
    badgeClasses = 'bg-amber-100 text-amber-800 border border-amber-300';
    badgeText = 'Review Required';
  } else if (isFailed) {
    borderClasses = 'border-red-200 bg-red-50/40';
    badgeClasses = 'bg-red-100 text-red-800 border border-red-300';
    badgeText = 'Screening Failed';
  }

  return (
    <div className={`p-5 rounded-2xl border shadow-xs transition-all ${borderClasses}`}>
      {/* Top Banner */}
      <div className="flex items-start justify-between gap-4 pb-4 border-b border-[#DED4C3]/80">
        <div className="flex items-center gap-3">
          <div
            className={`w-10 h-10 rounded-xl flex items-center justify-center ${
              isPassed
                ? 'bg-green-600 text-white'
                : isReviewRequired
                ? 'bg-amber-600 text-white'
                : 'bg-[#3E4740] text-white'
            }`}
          >
            {isPassed ? <ShieldCheck className="w-5 h-5" /> : <AlertTriangle className="w-5 h-5" />}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-bold text-[#2E342F]">Identity Check</h4>
              <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${badgeClasses}`}>
                {badgeText}
              </span>
            </div>
            <p className="text-xs text-[#6B716A] mt-0.5">
              Mode: <span className="font-semibold text-[#465047]">{identityCheck.verificationMode}</span>
              {identityCheck.timestamp && ` • ${identityCheck.timestamp}`}
            </p>
          </div>
        </div>

        <button
          onClick={onViewPrivacy}
          className="text-[11px] font-semibold text-[#2F7454] hover:text-[#1C4937] flex items-center gap-1 shrink-0"
        >
          <Info className="w-3.5 h-3.5" />
          <span>Privacy Rights</span>
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 my-4">
        <div className="p-3 bg-white rounded-xl border border-[#DED4C3]/80">
          <span className="text-[11px] font-medium text-[#6B716A] block">Liveness Presence</span>
          <div className="flex items-center gap-1.5 mt-1">
            {identityCheck.livenessResult === 'Passed' ? (
              <CheckCircle2 className="w-4 h-4 text-green-600" />
            ) : (
              <AlertTriangle className="w-4 h-4 text-amber-500" />
            )}
            <span className="text-xs font-bold text-[#374039]">
              {identityCheck.livenessResult || 'Pending'}
            </span>
          </div>
        </div>

        <div className="p-3 bg-white rounded-xl border border-[#DED4C3]/80">
          <span className="text-[11px] font-medium text-[#6B716A] block">Face Cross-Match</span>
          <div className="flex items-center gap-1.5 mt-1">
            <span className="text-xs font-bold text-[#374039]">
              {identityCheck.faceCrossMatchResult || 'Pending'}
            </span>
          </div>
        </div>

        <div className="p-3 bg-white rounded-xl border border-[#DED4C3]/80">
          <span className="text-[11px] font-medium text-[#6B716A] block">Screening Confidence</span>
          <div className="flex items-center gap-1.5 mt-1">
            <span className="text-xs font-extrabold text-[#2E342F]">{identityCheck.confidence}%</span>
            <span className="text-[10px] text-[#858B84] font-medium">
              ({identityCheck.confidence >= 90 ? 'High' : 'Moderate / Low-res'})
            </span>
          </div>
        </div>
      </div>

      {/* Reason and Recommended Action */}
      {identityCheck.reason && (
        <div className="p-3.5 bg-[#FAF6ED] rounded-xl border border-[#DED4C3] text-xs space-y-1 text-[#465047]">
          <p>
            <strong className="text-[#2E342F]">Reason: </strong>
            {identityCheck.reason}
          </p>
          {identityCheck.recommendedAction && (
            <p>
              <strong className="text-[#2E342F]">Recommended action: </strong>
              {identityCheck.recommendedAction}
            </p>
          )}
        </div>
      )}

      {/* Assistive Notice */}
      <p className="text-[11px] text-[#6B716A] mt-3 italic flex items-center gap-1">
        <Info className="w-3.5 h-3.5 text-[#858B84] shrink-0" />
        Document Trust Check and liveness are assistive signals only and never automatically reject admission without human review.
      </p>

      {/* Actions */}
      <div className="flex flex-wrap items-center justify-between gap-3 mt-4 pt-3 border-t border-[#DED4C3]/80">
        <div className="text-[11px] text-[#6B716A]">
          Retries used: <strong className="text-[#465047]">{identityCheck.retryCount}</strong>
          {identityCheck.manualReviewRequested && (
            <span className="ml-2 text-[#245C43] font-bold bg-[#EEF7F1] px-2 py-0.5 rounded-full border border-[#C4E1CF]">
              Manual Review Requested
            </span>
          )}
        </div>

        <div className="flex items-center gap-2">
          {!isPassed && (
            <>
              <button
                type="button"
                onClick={onRetry}
                className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-white hover:bg-[#FAF6ED] text-[#465047] border border-[#CEC4B3] shadow-2xs flex items-center gap-1.5"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                Retry Identity Check
              </button>
              <button
                type="button"
                onClick={onRequestManualReview}
                disabled={identityCheck.manualReviewRequested}
                className="px-3.5 py-1.5 text-xs font-semibold rounded-xl bg-[#2F7454] hover:bg-[#245C43] disabled:opacity-60 text-white shadow-2xs flex items-center gap-1.5"
              >
                <UserCheck className="w-3.5 h-3.5" />
                {identityCheck.manualReviewRequested ? 'Officer Queued' : 'Request Manual Review'}
              </button>
            </>
          )}

          {isPassed && (
            <span className="text-xs font-semibold text-green-700 bg-green-100 px-3 py-1 rounded-lg">
              Verified for Admission Review
            </span>
          )}
        </div>
      </div>
    </div>
  );
};
