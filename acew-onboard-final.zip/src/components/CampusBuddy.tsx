import React, { useState, useRef, useEffect } from 'react';
import {
  MessageSquare,
  X,
  Send,
  Sparkles,
  Bot,
  User,
  Copy,
  Check,
  RotateCcw,
  Languages,
  Zap,
  Brain,
  HelpCircle,
  Clock,
  ShieldCheck,
  LifeBuoy,
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { useApp } from '../context/AppContext';
import { CampusBuddyMessage } from '../types';

export const CampusBuddy: React.FC = () => {
  const {
    studentProfile,
    documents,
    identityCheck,
    tasks,
    readinessScore,
    completedTasksCount,
    totalTasksCount,
    remainingMandatoryCount,
    currentStage,
    language,
    setLanguage,
    addToast,
    navigateTo,
  } = useApp();

  const [isOpen, setIsOpen] = useState(false);
  const [inputText, setInputText] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [modelMode, setModelMode] = useState<'fast' | 'general' | 'thinking'>('fast');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [showSupportConfirm, setShowSupportConfirm] = useState(false);

  const initialGreeting: CampusBuddyMessage = {
    id: 'msg-init',
    sender: 'assistant',
    text:
      language === 'ta'
        ? 'வணக்கம்! நான் AVA (Admission & Verification Assistant). உங்கள் சேர்க்கை முன்னேற்றம், ஆவண திருத்தம், அடையாள சோதனை மற்றும் அடுத்த கட்ட படிகளைப் பற்றி நீங்கள் என்னிடம் கேட்கலாம்.'
        : 'Hi! I’m AVA, your AI Admission & Verification Assistant. I can help you understand your documents, identity check, application status and next onboarding steps.',
    timestamp: 'Just now',
    modelUsed: 'gemini-3.1-flash-lite',
  };

  const [messages, setMessages] = useState<CampusBuddyMessage[]>([initialGreeting]);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isOpen) {
      chatBottomRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen]);

  const quickPrompts = [
    { label: 'Check my progress', query: 'What is my current application status and score?' },
    { label: 'Show missing documents', query: 'What documents are missing or pending?' },
    { label: 'Explain document issue', query: 'Why does my Class 12 marksheet need correction?' },
    { label: 'What should I do next?', query: 'What is my next required action?' },
    { label: 'Why is orientation locked?', query: 'Why is orientation registration locked?' },
    { label: 'Why need identity check?', query: 'Why do I need to complete an identity check?' },
    { label: 'Explain in Tamil', query: 'Explain my Class 12 marksheet issue in Tamil (தமிழில் விளக்கவும்)' },
  ];

  const handleCopy = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    addToast('Response copied to clipboard', 'info');
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleClearChat = () => {
    setMessages([initialGreeting]);
    addToast('Conversation cleared.', 'info');
  };

  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputText).trim();
    if (!query || isLoading) return;

    const userMsg: CampusBuddyMessage = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputText('');
    setIsLoading(true);

    try {
      const response = await fetch('/api/gemini/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: messages,
          mode: modelMode,
          language,
          studentData: {
            applicationId: studentProfile.applicationId,
            fullName: studentProfile.fullName,
            programme: studentProfile.programme,
            readinessScore,
            completedTasksCount,
            totalTasksCount,
            remainingMandatoryCount,
            currentStage,
          },
        }),
      });

      const data = await response.json();

      const assistantMsg: CampusBuddyMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        text: data.reply || 'I am here to guide you with your onboarding.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: data.modelUsed,
        latencyMs: data.latencyMs,
        isSimulated: data.isSimulated,
      };

      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err) {
      console.error('Failed to query CampusBuddy:', err);
      const fallbackMsg: CampusBuddyMessage = {
        id: `msg-${Date.now() + 1}`,
        sender: 'assistant',
        text:
          'You are currently at 72% ACEW Readiness with 18 of 25 tasks complete. Your next required task is to correct the Class 12 marksheet name mismatch.',
        timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
        modelUsed: 'gemini-3.1-flash-lite (Offline Fallback)',
        isSimulated: true,
      };
      setMessages((prev) => [...prev, fallbackMsg]);
    } finally {
      setIsLoading(false);
    }
  };

  const submitSupportTicket = async () => {
    setShowSupportConfirm(false);
    setIsLoading(true);
    try {
      await fetch('/api/support-tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: studentProfile.applicationId,
          studentName: studentProfile.fullName,
          category: 'Document Verification',
          message: 'Student requested admission office ticket regarding Class 12 name verification.',
        }),
      });

      addToast('Support ticket submitted to Admission Helpdesk. Ticket #TCK-2026', 'success');

      setMessages((prev) => [
        ...prev,
        {
          id: `msg-${Date.now()}`,
          sender: 'assistant',
          text: 'I have logged Ticket **#TCK-2026** with the Admission Office regarding your document verification. A university counselor will review your record within 24 hours.',
          timestamp: 'Just now',
        },
      ]);
    } catch (e) {
      addToast('Failed to submit ticket. Please reach out to admission desk.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Trigger Button (Bottom-Right) */}
      {!isOpen && (
        <div className="fixed bottom-5 right-5 z-40">
          <button
            onClick={() => setIsOpen(true)}
            className="flex items-center gap-2.5 px-4 py-3 rounded-full bg-[#DFF3E8] text-[#174A38] border border-[#C4E1CF] font-semibold text-sm shadow-xl hover:shadow-2xl hover:scale-105 active:scale-95 transition-all focus:outline-none focus:ring-4 focus:ring-[#A6CEB7]"
            aria-label="Open CampusBuddy AI Chatbot"
          >
            <div className="relative">
              <Bot className="w-5 h-5" />
              <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-[#7DB392] border-2 border-white"></span>
            </div>
            <span className="tracking-tight font-semibold">AVA</span>
            <span className="hidden sm:inline-block text-[10px] bg-white/20 px-2 py-0.5 rounded-full">
              AI Assistant
            </span>
          </button>
        </div>
      )}

      {/* Slide-out Chat Panel (Desktop) / Fullscreen (Mobile) */}
      {isOpen && (
        <div
          className="fixed inset-y-0 right-0 z-50 w-full sm:w-[440px] bg-[#FBF8F1] shadow-2xl flex flex-col border-l border-[#DED4C3] transition-transform duration-300 ease-in-out"
          role="dialog"
          aria-modal="true"
          aria-label="AVA AI Assistant"
        >
          {/* Chat Header */}
          <div className="p-4 bg-[#174A38] text-white flex items-center justify-between border-b border-[#25392F] shrink-0">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#4F936E] to-[#7DB392] flex items-center justify-center text-white shadow-sm">
                <Bot className="w-5 h-5" />
              </div>
              <div>
                <div className="flex items-center gap-1.5">
                  <h3 className="text-sm font-bold text-white tracking-tight">AVA</h3>
                  <span className="text-[10px] font-semibold bg-[#EEF7F1]/20 text-[#A6CEB7] border border-[#7DB392]/30 px-1.5 py-0.2 rounded">
                    Official AI
                  </span>
                </div>
                <p className="text-[11px] text-[#B4B9B2]">
                  {language === 'ta' ? 'AVA சேர்க்கை வழிகாட்டி' : 'Academic & Verification Assistant'}
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1">
              <button
                onClick={handleClearChat}
                className="p-1.5 text-[#858B84] hover:text-white hover:bg-[#26382F] rounded-lg transition-colors"
                title="Clear Conversation"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
              <button
                onClick={() => setIsOpen(false)}
                className="p-1.5 text-[#858B84] hover:text-white hover:bg-[#26382F] rounded-lg transition-colors"
                aria-label="Close Chat"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>

          {/* Model & Latency Control Bar */}
          <div className="px-3 py-2 bg-[#FAF6ED] border-b border-[#DED4C3] flex items-center justify-between text-xs text-[#596159] shrink-0">
            <div className="flex items-center gap-1 font-medium">
              <span className="text-[11px] text-[#6B716A] font-semibold mr-1">Model:</span>
              <button
                onClick={() => setModelMode('fast')}
                className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold transition-all ${
                  modelMode === 'fast'
                    ? 'bg-[#2F7454] text-white shadow-xs'
                    : 'bg-[#DED4C3]/80 hover:bg-[#C9BEAC] text-[#465047]'
                }`}
                title="gemini-3.1-flash-lite: Ultra low latency responses"
              >
                <Zap className="w-3 h-3" />
                Fast
              </button>
              <button
                onClick={() => setModelMode('thinking')}
                className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-semibold transition-all ${
                  modelMode === 'thinking'
                    ? 'bg-purple-600 text-white shadow-xs'
                    : 'bg-[#DED4C3]/80 hover:bg-[#C9BEAC] text-[#465047]'
                }`}
                title="gemini-3.1-pro-preview: High thinking mode for complex regulations"
              >
                <Brain className="w-3 h-3" />
                Thinking
              </button>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')}
                className="text-[11px] font-semibold text-[#245C43] hover:underline flex items-center gap-1"
              >
                <Languages className="w-3 h-3" />
                {language === 'en' ? 'தமிழ்' : 'English'}
              </button>
            </div>
          </div>

          {/* Messages Scroll Area */}
          <div className="flex-1 p-4 overflow-y-auto space-y-4 bg-[#FAF6ED]/50">
            {messages.map((msg) => {
              const isUser = msg.sender === 'user';
              return (
                <div
                  key={msg.id}
                  className={`flex gap-2.5 ${isUser ? 'justify-end' : 'justify-start'}`}
                >
                  {!isUser && (
                    <div className="w-7 h-7 rounded-lg bg-[#2F7454] text-white flex items-center justify-center shrink-0 mt-0.5">
                      <Bot className="w-4 h-4" />
                    </div>
                  )}

                  <div
                    className={`max-w-[85%] rounded-2xl p-3 text-xs leading-relaxed shadow-xs ${
                      isUser
                        ? 'bg-[#2F7454] text-white rounded-br-xs font-medium'
                        : 'bg-white text-[#374039] border border-[#DED4C3]/80 rounded-bl-xs'
                    }`}
                  >
                    {!isUser ? (
                      <div className="prose prose-xs max-w-none text-[#374039] [&_p]:my-1 [&_strong]:text-[#2E342F] [&_ul]:my-1 [&_ul]:pl-4">
                        <ReactMarkdown>{msg.text}</ReactMarkdown>
                      </div>
                    ) : (
                      <p className="whitespace-pre-wrap">{msg.text}</p>
                    )}

                    {/* Metadata & Actions */}
                    <div
                      className={`flex items-center justify-between gap-2 mt-2 pt-1 border-t ${
                        isUser ? 'border-[#4F936E]/50 text-[#C4E1CF]' : 'border-[#EEE7DA] text-[#858B84]'
                      } text-[10px]`}
                    >
                      <span className="flex items-center gap-1">
                        <Clock className="w-2.5 h-2.5" />
                        {msg.timestamp}
                        {msg.latencyMs && (
                          <span className="ml-1 text-[#6B716A] font-mono">
                            • {msg.latencyMs}ms
                          </span>
                        )}
                      </span>

                      {!isUser && (
                        <button
                          onClick={() => handleCopy(msg.id, msg.text)}
                          className="hover:text-[#596159] p-0.5 rounded transition-colors"
                          title="Copy response"
                        >
                          {copiedId === msg.id ? (
                            <Check className="w-3 h-3 text-green-600" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      )}
                    </div>
                  </div>

                  {isUser && (
                    <div className="w-7 h-7 rounded-lg bg-[#26382F] text-white flex items-center justify-center shrink-0 mt-0.5">
                      <User className="w-4 h-4" />
                    </div>
                  )}
                </div>
              );
            })}

            {isLoading && (
              <div className="flex gap-2.5 items-start">
                <div className="w-7 h-7 rounded-lg bg-[#2F7454] text-white flex items-center justify-center shrink-0">
                  <Bot className="w-4 h-4 animate-spin" />
                </div>
                <div className="bg-white border border-[#DED4C3] rounded-2xl rounded-bl-xs p-3 text-xs text-[#6B716A] shadow-xs flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[#2F7454] animate-bounce"></span>
                  <span className="w-2 h-2 rounded-full bg-[#2F7454] animate-bounce [animation-delay:0.2s]"></span>
                  <span className="w-2 h-2 rounded-full bg-[#2F7454] animate-bounce [animation-delay:0.4s]"></span>
                  <span className="text-[11px] font-medium text-[#596159]">
                    {modelMode === 'thinking' ? 'Reasoning with Thinking Mode...' : 'CampusBuddy is typing...'}
                  </span>
                </div>
              </div>
            )}

            <div ref={chatBottomRef} />
          </div>

          {/* Quick Prompts Carousel */}
          <div className="p-2.5 bg-[#F1E8D8]/70 border-t border-[#DED4C3] overflow-x-auto whitespace-nowrap flex gap-1.5 shrink-0 scrollbar-none">
            {quickPrompts.map((qp, idx) => (
              <button
                key={idx}
                onClick={() => handleSendMessage(qp.query)}
                className="px-2.5 py-1 bg-white hover:bg-[#EEF7F1] hover:text-[#245C43] hover:border-[#A6CEB7] text-[#465047] text-[11px] font-medium rounded-full border border-[#DED4C3] transition-colors shrink-0 shadow-2xs"
              >
                {qp.label}
              </button>
            ))}
          </div>

          {/* Support Ticket Prompt Confirmation */}
          {showSupportConfirm && (
            <div className="p-3 bg-amber-50 border-t border-amber-200 text-xs text-amber-900 flex items-center justify-between shrink-0">
              <div>
                <p className="font-bold">Submit Official Support Ticket?</p>
                <p className="text-[11px] text-amber-700">
                  This will alert the admission verification desk.
                </p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setShowSupportConfirm(false)}
                  className="px-2.5 py-1 text-xs font-semibold bg-white border border-amber-300 rounded-lg text-[#465047] hover:bg-[#FAF6ED]"
                >
                  Cancel
                </button>
                <button
                  onClick={submitSupportTicket}
                  className="px-2.5 py-1 text-xs font-semibold bg-amber-600 text-white rounded-lg hover:bg-amber-700"
                >
                  Confirm
                </button>
              </div>
            </div>
          )}

          {/* Chat Input Bar */}
          <div className="p-3 bg-white border-t border-[#DED4C3] shrink-0">
            <form
              onSubmit={(e) => {
                e.preventDefault();
                handleSendMessage();
              }}
              className="flex items-center gap-2"
            >
              <input
                type="text"
                value={inputText}
                onChange={(e) => setInputText(e.target.value)}
                placeholder={
                  language === 'ta'
                    ? 'கேள்வியைத் தட்டச்சு செய்க...'
                    : 'Ask about documents, identity check, next steps...'
                }
                className="flex-1 px-3.5 py-2 text-xs text-[#2E342F] placeholder-slate-400 bg-[#FAF6ED] border border-[#CEC4B3] rounded-xl focus:outline-none focus:border-[#4F936E] focus:ring-1 focus:ring-[#2F7454]"
                disabled={isLoading}
              />
              <button
                type="button"
                onClick={() => setShowSupportConfirm(true)}
                className="p-2 text-[#6B716A] hover:text-amber-600 hover:bg-amber-50 rounded-xl border border-[#DED4C3] transition-colors"
                title="Create Official Support Request"
              >
                <LifeBuoy className="w-4 h-4" />
              </button>
              <button
                type="submit"
                disabled={!inputText.trim() || isLoading}
                className="p-2 bg-[#2F7454] hover:bg-[#245C43] disabled:opacity-50 text-white rounded-xl shadow-xs transition-colors focus:outline-none"
                aria-label="Send message"
              >
                <Send className="w-4 h-4" />
              </button>
            </form>
            <div className="flex items-center justify-between mt-2 text-[10px] text-[#858B84]">
              <span>Assistive guidance only • Human review for decisions</span>
              <span>English &amp; தமிழ்</span>
            </div>
          </div>
        </div>
      )}
    </>
  );
};
