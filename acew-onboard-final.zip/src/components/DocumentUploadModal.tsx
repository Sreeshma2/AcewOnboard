import React, { useState, useRef } from 'react';
import {
  Upload,
  Camera,
  X,
  FileText,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Eye,
  ShieldCheck,
  Edit2,
  Save,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { ExtractedOcrFields, DocumentTrustCheck } from '../types';

interface DocumentUploadModalProps {
  isOpen: boolean;
  docId: string;
  docName: string;
  onClose: () => void;
}

export const DocumentUploadModal: React.FC<DocumentUploadModalProps> = ({
  isOpen,
  docId,
  docName,
  onClose,
}) => {
  const { studentProfile, uploadDocument, resolveDocumentCorrection, addToast } = useApp();

  const [dragActive, setDragActive] = useState(false);
  const [selectedFile, setSelectedFile] = useState<{ name: string; size: string; previewUrl?: string } | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [consentBeforeUpload, setConsentBeforeUpload] = useState(true);
  const [ocrResult, setOcrResult] = useState<ExtractedOcrFields | null>(null);
  const [trustCheck, setTrustCheck] = useState<DocumentTrustCheck | null>(null);
  const [isEditingOcr, setIsEditingOcr] = useState(false);
  const [editedName, setEditedName] = useState('');
  const [proofNote, setProofNote] = useState('');

  const fileInputRef = useRef<HTMLInputElement>(null);

  if (!isOpen) return null;

  const handleFiles = (files: FileList | null) => {
    if (!files || files.length === 0) return;
    const file = files[0];

    const sizeInMb = (file.size / (1024 * 1024)).toFixed(2);
    const previewUrl = URL.createObjectURL(file);

    setSelectedFile({
      name: file.name,
      size: `${sizeInMb} MB`,
      previewUrl,
    });

    runOcrAndTrustAnalysis(file.name);
  };

  const runOcrAndTrustAnalysis = async (fileName: string) => {
    setIsScanning(true);
    try {
      const response = await fetch('/api/gemini/analyze-document', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          documentType: docId === 'doc-12th' ? 'class_12' : 'general',
          studentName: studentProfile.fullName,
        }),
      });
      const data = await response.json();
      setOcrResult(data.ocr);
      setTrustCheck(data.trustCheck);
      setEditedName(data.ocr?.studentName || studentProfile.fullName);
    } catch (e) {
      console.error('Analysis error:', e);
    } finally {
      setIsScanning(false);
    }
  };

  const handleConfirmAndUpload = () => {
    if (!selectedFile) return;

    if (docId === 'doc-12th') {
      resolveDocumentCorrection(docId, editedName || studentProfile.fullName, proofNote);
    } else {
      uploadDocument(docId, {
        name: selectedFile.name,
        size: selectedFile.size,
      });
    }

    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-[#1D2D26]/80 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="relative w-full max-w-2xl bg-white rounded-2xl shadow-2xl border border-[#DED4C3] overflow-hidden text-[#2E342F]">
        {/* Header */}
        <div className="px-5 py-4 bg-[#174A38] text-white flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-[#2F7454] flex items-center justify-center">
              <Upload className="w-4 h-4 text-white" />
            </div>
            <div>
              <h3 className="text-sm font-bold tracking-tight">Upload {docName}</h3>
              <p className="text-[11px] text-[#B4B9B2]">
                PDF, JPG, PNG up to 5MB • Instant Document Quality Scan
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-[#858B84] hover:text-white p-1 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 space-y-5 max-h-[80vh] overflow-y-auto">
          {/* Dropzone */}
          {!selectedFile && (
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragActive(true);
              }}
              onDragLeave={() => setDragActive(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragActive(false);
                handleFiles(e.dataTransfer.files);
              }}
              onClick={() => fileInputRef.current?.click()}
              className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all ${
                dragActive
                  ? 'border-[#4F936E] bg-[#EEF7F1]/50'
                  : 'border-[#CEC4B3] hover:border-[#7DB392] hover:bg-[#FAF6ED]'
              }`}
            >
              <input
                ref={fileInputRef}
                type="file"
                accept=".pdf,.jpg,.jpeg,.png"
                className="hidden"
                onChange={(e) => handleFiles(e.target.files)}
              />
              <div className="w-12 h-12 rounded-full bg-[#EEF7F1] text-[#2F7454] flex items-center justify-center mx-auto mb-3">
                <Upload className="w-6 h-6" />
              </div>
              <h4 className="text-sm font-bold text-[#374039]">
                Click to upload or drag &amp; drop document
              </h4>
              <p className="text-xs text-[#6B716A] mt-1">
                Ensure all 4 corners are visible, text is sharp, and no shadows obscure the registration details.
              </p>
              <div className="flex justify-center gap-4 mt-4 text-[11px] text-[#596159]">
                <span className="flex items-center gap-1 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5 text-green-600" />
                  Max 5MB
                </span>
                <span className="flex items-center gap-1 font-semibold">
                  <CheckCircle2 className="w-3.5 h-3.5 text-green-600" />
                  PDF, JPG, PNG
                </span>
                <span className="flex items-center gap-1 font-semibold">
                  <Camera className="w-3.5 h-3.5 text-[#2F7454]" />
                  Mobile Camera Supported
                </span>
              </div>
            </div>
          )}

          {/* Selected File & Scan State */}
          {selectedFile && (
            <div className="space-y-4">
              <div className="p-3.5 bg-[#FAF6ED] border border-[#DED4C3] rounded-xl flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-[#DDEFE4] text-[#245C43] flex items-center justify-center">
                    <FileText className="w-5 h-5" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-[#2E342F]">{selectedFile.name}</p>
                    <p className="text-[11px] text-[#6B716A]">{selectedFile.size}</p>
                  </div>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setSelectedFile(null);
                    setOcrResult(null);
                    setTrustCheck(null);
                  }}
                  className="text-xs text-red-600 hover:text-red-800 font-medium"
                >
                  Replace file
                </button>
              </div>

              {/* Scanning status */}
              {isScanning && (
                <div className="p-4 bg-[#EEF7F1] border border-[#C4E1CF] rounded-xl flex items-center gap-3 text-xs text-[#1C4937]">
                  <RefreshCw className="w-5 h-5 text-[#2F7454] animate-spin shrink-0" />
                  <div>
                    <p className="font-bold">Analyzing document quality and extracting OCR fields...</p>
                    <p className="text-[11px] text-[#2F7454] mt-0.5">
                      Checking for blur, glare, edge cropping, and name consistency with application profile.
                    </p>
                  </div>
                </div>
              )}

              {/* OCR Extracted Fields Card */}
              {ocrResult && (
                <div className="p-4 bg-[#FAF6ED] border border-[#DED4C3] rounded-xl space-y-3">
                  <div className="flex items-center justify-between pb-2 border-b border-[#DED4C3]">
                    <div className="flex items-center gap-1.5">
                      <Sparkles className="w-4 h-4 text-[#2F7454]" />
                      <span className="text-xs font-bold text-[#2E342F]">
                        Extracted Fields (Assistive OCR)
                      </span>
                    </div>
                    <span className="text-[11px] font-semibold text-green-700 bg-green-100 px-2 py-0.5 rounded-full">
                      Confidence: {Math.round((ocrResult.confidence || 0.94) * 100)}%
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-3 text-xs">
                    <div>
                      <span className="text-[11px] text-[#6B716A] font-medium block">
                        Candidate Name:
                      </span>
                      {isEditingOcr ? (
                        <input
                          type="text"
                          value={editedName}
                          onChange={(e) => setEditedName(e.target.value)}
                          className="w-full mt-1 px-2 py-1 bg-white border border-[#7DB392] rounded text-xs font-bold text-[#2E342F]"
                        />
                      ) : (
                        <div className="flex items-center justify-between mt-1">
                          <span className="font-bold text-[#2E342F]">{editedName}</span>
                          <button
                            type="button"
                            onClick={() => setIsEditingOcr(true)}
                            className="text-[#2F7454] hover:text-[#1C4937] p-0.5"
                            title="Correct extracted name"
                          >
                            <Edit2 className="w-3 h-3" />
                          </button>
                        </div>
                      )}
                    </div>

                    <div>
                      <span className="text-[11px] text-[#6B716A] font-medium block">Register Number:</span>
                      <span className="font-bold text-[#2E342F] mt-1 block">
                        {ocrResult.registerNumber}
                      </span>
                    </div>

                    <div>
                      <span className="text-[11px] text-[#6B716A] font-medium block">Date of Birth:</span>
                      <span className="font-bold text-[#2E342F] mt-1 block">
                        {ocrResult.dateOfBirth}
                      </span>
                    </div>

                    <div>
                      <span className="text-[11px] text-[#6B716A] font-medium block">Total Marks &amp; %:</span>
                      <span className="font-bold text-[#2E342F] mt-1 block">
                        {ocrResult.totalMarks} ({ocrResult.percentage})
                      </span>
                    </div>

                    <div className="col-span-2">
                      <span className="text-[11px] text-[#6B716A] font-medium block">School / Institution:</span>
                      <span className="font-bold text-[#2E342F] mt-1 block">
                        {ocrResult.institutionName}
                      </span>
                    </div>
                  </div>

                  {isEditingOcr && (
                    <div className="flex justify-end pt-1">
                      <button
                        type="button"
                        onClick={() => setIsEditingOcr(false)}
                        className="px-2.5 py-1 bg-[#2F7454] text-white rounded text-[11px] font-semibold flex items-center gap-1"
                      >
                        <Save className="w-3 h-3" />
                        Save Name
                      </button>
                    </div>
                  )}

                  {docId === 'doc-12th' && (
                    <div className="pt-2 border-t border-[#DED4C3]">
                      <label className="text-[11px] font-bold text-[#374039] block">
                        Explanation / Supporting Proof Note:
                      </label>
                      <input
                        type="text"
                        value={proofNote}
                        onChange={(e) => setProofNote(e.target.value)}
                        placeholder="e.g. Initial S represents my father's name Subramanian as per Aadhaar."
                        className="w-full mt-1 px-3 py-1.5 text-xs bg-white border border-[#CEC4B3] rounded-lg focus:outline-none focus:border-[#4F936E]"
                      />
                    </div>
                  )}
                </div>
              )}

              {/* Trust Check Result */}
              {trustCheck && (
                <div
                  className={`p-3.5 rounded-xl border text-xs space-y-1.5 ${
                    trustCheck.riskLevel === 'Low'
                      ? 'bg-green-50/60 border-green-200 text-green-900'
                      : 'bg-amber-50/60 border-amber-200 text-amber-900'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold">
                      Document Trust Check: {trustCheck.status}
                    </span>
                    <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-full bg-white border border-current">
                      {trustCheck.riskLevel} Risk
                    </span>
                  </div>
                  <ul className="list-disc pl-4 text-[11px] space-y-0.5">
                    {trustCheck.reasons.map((r, i) => (
                      <li key={i}>{r}</li>
                    ))}
                  </ul>
                  <p className="text-[11px] pt-1 font-medium border-t border-current/20">
                    Recommended: {trustCheck.recommendedAction}
                  </p>
                </div>
              )}
            </div>
          )}

          {/* Consent Checkbox */}
          <div className="flex items-start gap-2.5 p-3 bg-[#FAF6ED] border border-[#DED4C3] rounded-xl text-xs text-[#465047]">
            <input
              type="checkbox"
              id="upload-consent"
              checked={consentBeforeUpload}
              onChange={(e) => setConsentBeforeUpload(e.target.checked)}
              className="mt-0.5 h-4 w-4 rounded border-[#CEC4B3] text-[#2F7454] focus:ring-[#2F7454]"
            />
            <label htmlFor="upload-consent" className="cursor-pointer text-[11px] leading-relaxed">
              I certify that this document is genuine and unaltered. I consent to assistive OCR extraction and human admission officer verification.
            </label>
          </div>
        </div>

        {/* Footer */}
        <div className="px-6 py-3.5 bg-[#FAF6ED] border-t border-[#DED4C3] flex items-center justify-between">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-[#596159] hover:text-[#2E342F]"
          >
            Cancel
          </button>
          <button
            type="button"
            disabled={!selectedFile || isScanning || !consentBeforeUpload}
            onClick={handleConfirmAndUpload}
            className="px-5 py-2 bg-[#2F7454] hover:bg-[#245C43] disabled:opacity-50 text-white font-semibold rounded-xl text-xs shadow-xs"
          >
            Confirm &amp; Submit Document
          </button>
        </div>
      </div>
    </div>
  );
};
