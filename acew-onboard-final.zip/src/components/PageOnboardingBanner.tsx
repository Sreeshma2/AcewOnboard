import React, { useState, useEffect } from 'react';
import {
  Compass,
  ChevronRight,
  ChevronLeft,
  CheckCircle2,
  X,
  Sparkles,
  Info,
  HelpCircle,
  Eye,
  Layers,
  LucideIcon,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export interface OnboardingStep {
  title: string;
  desc: string;
  tip?: string;
  icon: LucideIcon;
}

interface PageOnboardingBannerProps {
  pageKey: string;
  pageTitle: string;
  steps: OnboardingStep[];
}

export const PageOnboardingBanner: React.FC<PageOnboardingBannerProps> = ({
  pageKey,
  pageTitle,
  steps,
}) => {
  const { language } = useApp();
  const storageKey = `acew_onboarding_dismissed_${pageKey}`;

  const [isDismissed, setIsDismissed] = useState<boolean>(() => {
    try {
      return localStorage.getItem(storageKey) === 'true';
    } catch {
      return false;
    }
  });

  const [activeStepIndex, setActiveStepIndex] = useState(0);

  const handleDismiss = () => {
    setIsDismissed(true);
    try {
      localStorage.setItem(storageKey, 'true');
    } catch {}
  };

  const handleReopen = () => {
    setIsDismissed(false);
    try {
      localStorage.removeItem(storageKey);
    } catch {}
  };

  const currentStep = steps[activeStepIndex] || steps[0];
  const StepIcon = currentStep?.icon || Compass;

  if (isDismissed) {
    return (
      <div className="flex justify-end mb-3">
        <button
          onClick={handleReopen}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#EEF7F1] hover:bg-[#DDEFE4] text-[#245C43] rounded-lg text-xs font-semibold border border-[#C4E1CF] transition-colors shadow-2xs"
          title="Open page guide and onboarding steps"
        >
          <Compass className="w-3.5 h-3.5 text-[#2F7454]" />
          <span>{language === 'ta' ? 'பக்க வழிகாட்டி' : `${pageTitle} Guide & Tour`}</span>
        </button>
      </div>
    );
  }

  return (
    <div className="mb-6 rounded-2xl bg-gradient-to-br from-slate-900 via-[#174A38] to-[#12362A] text-white p-5 sm:p-6 shadow-md border border-[#153B2E]/40 relative overflow-hidden animate-in fade-in slide-in-from-top-3">
      {/* Decorative background accent */}
      <div
        className="absolute -right-10 -bottom-10 w-48 h-48 rounded-full bg-[#EEF7F1]/10 pointer-events-none blur-2xl"
        aria-hidden="true"
      />

      {/* Header bar of banner */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 pb-3 border-b border-white/10">
        <div className="flex items-center gap-2.5">
          <div className="w-8 h-8 rounded-lg bg-[#2F7454]/80 text-white flex items-center justify-center shrink-0">
            <Compass className="w-4 h-4" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-sm sm:text-base font-bold text-white tracking-tight">
                {pageTitle} • {language === 'ta' ? 'பக்க வழிகாட்டி' : 'Page Tour'}
              </h2>
            </div>
          </div>
        </div>

        <div className="flex items-center gap-2 self-end sm:self-auto">
          <span className="text-[11px] text-[#C4E1CF]/80 font-medium hidden sm:inline">
            Step {activeStepIndex + 1} of {steps.length}
          </span>
          <button
            onClick={handleDismiss}
            className="p-1.5 rounded-lg text-[#858B84] hover:text-white hover:bg-white/10 transition-colors"
            title="Dismiss tour"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Interactive Step Card */}
      <div className="mt-3 bg-white/5 rounded-xl p-4 border border-white/10 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-start gap-3.5">
          <div className="w-10 h-10 rounded-xl bg-[#EEF7F1]/20 border border-[#7DB392]/30 text-[#A6CEB7] flex items-center justify-center shrink-0 mt-0.5">
            <StepIcon className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-[#7DB392]">
                0{activeStepIndex + 1}.
              </span>
              <h3 className="text-sm font-bold text-white">{currentStep.title}</h3>
            </div>
            <p className="text-xs text-[#B4B9B2] mt-1 leading-relaxed max-w-2xl">
              {currentStep.desc}
            </p>
          </div>
        </div>

        {/* Step Navigation Controls */}
        <div className="flex items-center gap-2 shrink-0 self-end md:self-center">
          <button
            onClick={() => setActiveStepIndex((prev) => Math.max(0, prev - 1))}
            disabled={activeStepIndex === 0}
            className="p-1.5 rounded-lg border border-white/15 text-[#B4B9B2] hover:text-white hover:bg-white/10 disabled:opacity-30 disabled:cursor-not-allowed transition-colors"
            title="Previous step"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>

          {/* Step dots */}
          <div className="flex items-center gap-1 px-1">
            {steps.map((_, idx) => (
              <button
                key={idx}
                onClick={() => setActiveStepIndex(idx)}
                className={`h-1.5 rounded-full transition-all ${
                  idx === activeStepIndex ? 'w-5 bg-[#7DB392]' : 'w-1.5 bg-white/30 hover:bg-white/50'
                }`}
                aria-label={`Go to step ${idx + 1}`}
              />
            ))}
          </div>

          <button
            onClick={() => {
              if (activeStepIndex < steps.length - 1) {
                setActiveStepIndex((prev) => prev + 1);
              } else {
                handleDismiss();
              }
            }}
            className="px-3 py-1.5 bg-[#2F7454] hover:bg-[#1C4937] text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-xs transition-colors"
          >
            <span>{activeStepIndex === steps.length - 1 ? 'Finish Tour' : 'Next'}</span>
            {activeStepIndex < steps.length - 1 ? (
              <ChevronRight className="w-3.5 h-3.5" />
            ) : (
              <CheckCircle2 className="w-3.5 h-3.5" />
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
