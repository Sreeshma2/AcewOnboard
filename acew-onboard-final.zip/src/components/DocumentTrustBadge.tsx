import React from 'react';
import { ShieldCheck, AlertTriangle, ShieldAlert, CheckCircle2, Info } from 'lucide-react';
import { DocumentTrustCheck, RiskLevel } from '../types';

interface DocumentTrustBadgeProps {
  trustCheck?: DocumentTrustCheck;
  compact?: boolean;
}

export const DocumentTrustBadge: React.FC<DocumentTrustBadgeProps> = ({
  trustCheck,
  compact = false,
}) => {
  if (!trustCheck) return null;

  const { riskLevel, status, reasons, recommendedAction, qualityIssues, mismatches } = trustCheck;

  let badgeColor = 'bg-[#F1E8D8] text-[#465047] border-[#DED4C3]';
  let Icon = Info;

  if (riskLevel === 'Low') {
    badgeColor = 'bg-green-50 text-green-700 border-green-200';
    Icon = CheckCircle2;
  } else if (riskLevel === 'Medium') {
    badgeColor = 'bg-amber-50 text-amber-700 border-amber-200';
    Icon = AlertTriangle;
  } else if (riskLevel === 'High') {
    badgeColor = 'bg-red-50 text-red-700 border-red-200';
    Icon = ShieldAlert;
  }

  if (compact) {
    return (
      <span
        className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[11px] font-bold border ${badgeColor}`}
        title={`Trust Check: ${status} (${riskLevel} Risk)`}
      >
        <Icon className="w-3 h-3" />
        <span>{riskLevel} Risk</span>
      </span>
    );
  }

  return (
    <div className={`p-4 rounded-xl border ${badgeColor} text-xs space-y-2`}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icon className="w-4 h-4 shrink-0" />
          <span className="font-bold text-[#2E342F]">
            Document Trust Check: {status}
          </span>
        </div>
        <span className="font-extrabold uppercase tracking-wider text-[10px] px-2 py-0.5 rounded-full bg-white/80 border border-current">
          Risk: {riskLevel}
        </span>
      </div>

      {reasons && reasons.length > 0 && (
        <div>
          <span className="font-semibold text-[#374039] block text-[11px]">Reasons:</span>
          <ul className="list-disc pl-4 space-y-0.5 text-[#465047] text-[11px] mt-1">
            {reasons.map((r, idx) => (
              <li key={idx}>{r}</li>
            ))}
          </ul>
        </div>
      )}

      {qualityIssues && qualityIssues.length > 0 && (
        <div className="text-[11px] text-[#596159]">
          <span className="font-semibold text-[#465047]">Quality issues: </span>
          {qualityIssues.join(', ')}
        </div>
      )}

      {mismatches && mismatches.length > 0 && (
        <div className="p-2.5 bg-white/90 rounded-lg border border-amber-300 text-amber-900 text-[11px]">
          {mismatches.map((m, idx) => (
            <div key={idx}>
              <strong>Mismatch detected ({m.field}):</strong> Application has "{m.applicationValue}", document reads "{m.documentValue}".
            </div>
          ))}
        </div>
      )}

      {recommendedAction && (
        <div className="text-[11px] text-[#596159] pt-1 border-t border-current/10">
          <strong className="text-[#374039]">Recommended action: </strong>
          {recommendedAction}
        </div>
      )}
    </div>
  );
};
