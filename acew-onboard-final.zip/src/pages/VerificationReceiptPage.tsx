import React, { useState } from 'react';
import {
  FileBadge2,
  Printer,
  Download,
  Share2,
  CheckCircle2,
  ShieldCheck,
  QrCode,
  Building,
  Calendar,
  UserCheck,
  Copy,
  Check,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageOnboardingBanner, OnboardingStep } from '../components/PageOnboardingBanner';
import { ApplicationProgressStepper } from '../components/ApplicationProgressStepper';
import { WorkflowNavigationFooter } from '../components/WorkflowNavigationFooter';

const RECEIPT_STEPS: OnboardingStep[] = [
  {
    title: 'Check Your QR Receipt',
    desc: 'Scan the QR code to check your receipt.',
    icon: QrCode,
  },
  {
    title: 'Review Receipt Details',
    desc: 'Review your verification details here.',
    icon: ShieldCheck,
  },
  {
    title: 'Print Your Receipt',
    desc: 'Print your receipt before campus arrival.',
    icon: Printer,
  },
];

export const VerificationReceiptPage: React.FC = () => {
  const { studentProfile, documents, identityCheck, readinessScore, addToast } = useApp();
  const [copiedLink, setCopiedLink] = useState(false);

  const handlePrint = () => {
    window.print();
  };

  const handleCopyVerificationLink = () => {
    navigator.clipboard.writeText(
      `https://acew-onboard.edu.in/verify/CP-2026-1048?token=SEC-VR-${Date.now()}`
    );
    setCopiedLink(true);
    addToast('Official Verification Link copied to clipboard.', 'success');
    setTimeout(() => setCopiedLink(false), 2000);
  };

  return (
    <div className="space-y-6 pb-12 max-w-7xl mx-auto">
      {/* 6-Stage Stepper */}
      <div className="print:hidden">
        <ApplicationProgressStepper currentStepIndex={6} />
      </div>

      {/* Page-Specific Onboarding Banner */}
      <div className="print:hidden">
        <PageOnboardingBanner
          pageKey="receipt"
          pageTitle="Step 6: Digital Verification Pass & QR Receipt"
          uniqueFocus="Viewing and printing the tamper-proof provisional admission letter, encrypted QR token, and official university credentials."
          description="Your verified university certificate with anti-counterfeit QR code for seamless campus day registration."
          steps={RECEIPT_STEPS}
        />
      </div>

      {/* Top Action Bar (Hidden on print) */}
      <div className="print:hidden p-4 bg-white rounded-2xl border border-[#DED4C3] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <FileBadge2 className="w-5 h-5 text-green-600" />
            <h1 className="text-base font-bold text-[#2E342F]">
              Provisional Verification Receipt &amp; Smart Campus Pass
            </h1>
          </div>
          <p className="text-xs text-[#6B716A] mt-0.5">
            Present this document with QR code at the campus arrival registration desk.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyVerificationLink}
            className="px-3 py-2 bg-[#F1E8D8] hover:bg-[#DED4C3] text-[#465047] font-semibold rounded-xl text-xs transition-colors flex items-center gap-1.5"
          >
            {copiedLink ? <Check className="w-3.5 h-3.5 text-green-600" /> : <Share2 className="w-3.5 h-3.5" />}
            <span>Share Link</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 bg-[#1D2D26] hover:bg-[#26382F] text-white font-bold rounded-xl text-xs shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Receipt</span>
          </button>
          <button
            onClick={() => addToast('PDF Receipt downloaded: ACEW-2026-1048-VR.pdf', 'success')}
            className="px-3.5 py-2 bg-[#2F7454] hover:bg-[#245C43] text-white font-bold rounded-xl text-xs shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Download PDF</span>
          </button>
        </div>
      </div>

      {/* Official Certificate Paper Container */}
      <div className="bg-white p-8 sm:p-12 rounded-2xl border-2 border-[#CEC4B3] shadow-md max-w-4xl mx-auto text-[#2E342F] print:border-none print:shadow-none print:p-0 space-y-8">
        {/* Certificate Header with Institutional Seals */}
        <div className="flex flex-col sm:flex-row items-center justify-between pb-6 border-b-2 border-slate-900 gap-4 text-center sm:text-left">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 rounded-2xl bg-[#174A38] text-white flex items-center justify-center font-extrabold shadow-xs">
              <ShieldCheck className="w-10 h-10 text-[#7DB392]" />
            </div>
            <div>
              <span className="text-[10px] uppercase font-extrabold tracking-widest text-[#6B716A]">
                Tamil Nadu State Higher Education Smart Campus Initiative
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-[#174A38] tracking-tight">
                ACEW Smart Campus Admission Council
              </h2>
              <p className="text-xs text-[#596159] font-medium">
                Official Verification Credential • Certificate No: #ACEW-2026-1048-VR
              </p>
            </div>
          </div>

          <div className="text-right text-xs text-[#596159]">
            <div className="font-bold text-[#2E342F]">Date Issued: 15 Sep 2026</div>
            <div className="text-[11px] text-[#6B716A]">Status: Provisionally Verified</div>
            <div className="mt-1 font-mono text-[11px] bg-[#F1E8D8] px-2 py-0.5 rounded">
              Readiness: {readinessScore}%
            </div>
          </div>
        </div>

        {/* Candidate Profile Details Block */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-5 bg-[#FAF6ED] rounded-xl border border-[#DED4C3] text-xs">
          <div>
            <span className="text-[10px] text-[#6B716A] uppercase font-bold block">Candidate Name</span>
            <span className="text-sm font-bold text-[#2E342F] block mt-0.5">
              {studentProfile.fullName}
            </span>
          </div>

          <div>
            <span className="text-[10px] text-[#6B716A] uppercase font-bold block">Application ID</span>
            <span className="text-sm font-mono font-bold text-[#245C43] block mt-0.5">
              {studentProfile.applicationId}
            </span>
          </div>

          <div>
            <span className="text-[10px] text-[#6B716A] uppercase font-bold block">Programme Enrolled</span>
            <span className="text-xs font-bold text-[#2E342F] block mt-0.5">
              {studentProfile.programme}
            </span>
          </div>

          <div>
            <span className="text-[10px] text-[#6B716A] uppercase font-bold block">Admission Quota</span>
            <span className="text-xs font-bold text-[#2E342F] block mt-0.5">
              Merit / Govt Allocation
            </span>
          </div>
        </div>

        {/* Verified Documents Table */}
        <div className="space-y-3">
          <h3 className="text-xs font-extrabold uppercase tracking-wider text-[#2E342F] flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-green-600" />
            <span>Document Verification Record</span>
          </h3>

          <div className="border border-[#DED4C3] rounded-xl overflow-hidden text-xs">
            <table className="w-full text-left border-collapse">
              <thead className="bg-[#F1E8D8] text-[#465047] font-bold border-b border-[#DED4C3]">
                <tr>
                  <th className="p-3">Document Title</th>
                  <th className="p-3">Reference / File</th>
                  <th className="p-3">Assistive Check</th>
                  <th className="p-3 text-right">Verification Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {documents.map((doc) => (
                  <tr key={doc.id} className="hover:bg-[#FAF6ED]/50">
                    <td className="p-3 font-semibold text-[#2E342F]">{doc.name}</td>
                    <td className="p-3 text-[#6B716A] font-mono text-[11px]">
                      {doc.fileName || 'Pending upload'}
                    </td>
                    <td className="p-3">
                      <span className="text-[10px] font-semibold text-[#1C4937] bg-[#EEF7F1] px-2 py-0.5 rounded-full border border-[#C4E1CF]">
                        {doc.trustCheck?.status || 'Screened'}
                      </span>
                    </td>
                    <td className="p-3 text-right">
                      <span
                        className={`text-[11px] font-bold px-2.5 py-0.5 rounded-full ${
                          doc.status === 'Verified'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-amber-100 text-amber-800'
                        }`}
                      >
                        {doc.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Identity & Liveness Screening Proof */}
        <div className="p-4 bg-[#FAF6ED] rounded-xl border border-[#DED4C3] text-xs space-y-2">
          <div className="flex items-center justify-between font-bold text-[#2E342F]">
            <span>Identity &amp; Liveness Presence Check</span>
            <span className="text-green-700 font-extrabold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              Liveness Verified ({identityCheck.timestamp || '15 Sep, 08:34 PM'})
            </span>
          </div>
          <p className="text-[11px] text-[#596159] leading-relaxed">
            Assistive liveness presence test completed under student consent. Facial match score evaluated against Aadhaar card photograph ({identityCheck.confidence}% confidence).
          </p>
        </div>

        {/* Two Columns: QR Code & Officer Digital Stamp */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4 border-t-2 border-slate-900">
          {/* QR Code Container */}
          <div className="flex items-center gap-4 p-4 bg-[#FAF6ED] rounded-xl border border-[#DED4C3]">
            <div className="p-2 bg-white rounded-xl shadow-xs border border-[#CEC4B3] shrink-0">
              <svg className="w-24 h-24" viewBox="0 0 100 100">
                {/* SVG mock QR pattern */}
                <rect width="100" height="100" fill="white" />
                <rect x="10" y="10" width="25" height="25" fill="#174A38" />
                <rect x="15" y="15" width="15" height="15" fill="white" />
                <rect x="18" y="18" width="9" height="9" fill="#174A38" />

                <rect x="65" y="10" width="25" height="25" fill="#174A38" />
                <rect x="70" y="15" width="15" height="15" fill="white" />
                <rect x="73" y="18" width="9" height="9" fill="#174A38" />

                <rect x="10" y="65" width="25" height="25" fill="#174A38" />
                <rect x="15" y="70" width="15" height="15" fill="white" />
                <rect x="18" y="73" width="9" height="9" fill="#174A38" />

                <rect x="42" y="15" width="6" height="20" fill="#174A38" />
                <rect x="52" y="25" width="8" height="8" fill="#174A38" />
                <rect x="42" y="45" width="18" height="18" fill="#174A38" />
                <rect x="65" y="45" width="12" height="10" fill="#174A38" />
                <rect x="70" y="60" width="20" height="8" fill="#174A38" />
                <rect x="42" y="70" width="12" height="18" fill="#174A38" />
                <rect x="60" y="75" width="10" height="15" fill="#174A38" />
              </svg>
            </div>
            <div>
              <span className="text-xs font-bold text-[#2E342F] block">
                Tamper-Proof Verification QR
              </span>
              <p className="text-[11px] text-[#6B716A] mt-0.5 leading-normal">
                Campus admission desk will scan this QR for instant identity confirmation and badge issuance.
              </p>
              <span className="text-[10px] font-mono text-[#245C43] mt-1 block">
                UID: 3da5-78d2-26a9-483e
              </span>
            </div>
          </div>

          {/* Institutional Officer Signature */}
          <div className="flex flex-col justify-between p-4 bg-[#FAF6ED] rounded-xl border border-[#DED4C3] text-xs">
            <div>
              <span className="text-[10px] uppercase font-bold text-[#858B84] block">
                Authorized By
              </span>
              <p className="text-sm font-bold text-[#2E342F] mt-1">Dr. M. Sundaram, Ph.D.</p>
              <p className="text-[11px] text-[#596159]">
                Dean of Academic Admissions &amp; Verification
              </p>
            </div>

            <div className="mt-4 pt-2 border-t border-[#DED4C3] flex items-center justify-between text-[11px]">
              <span className="text-[#6B716A]">Digitally Verified &amp; Sealed</span>
              <span className="font-bold text-[#1C4937] bg-[#DDEFE4]/60 px-2 py-0.5 rounded">
                Official Seal
              </span>
            </div>
          </div>
        </div>

        {/* Footer Disclaimer */}
        <div className="text-center text-[11px] text-[#858B84] pt-4 border-t border-[#DED4C3]">
          This receipt serves as provisional academic admission credential for physical reporting. Admission is subject to final physical scrutiny of original certificates during campus orientation.
        </div>
      </div>

      {/* Step Navigation Footer */}
      <div className="print:hidden">
        <WorkflowNavigationFooter
          currentStepNumber={6}
          customNextLabel="Return to Applicant Dashboard"
          onNextBeforeNavigate={() => {
            return true;
          }}
        />
      </div>
    </div>
  );
};
