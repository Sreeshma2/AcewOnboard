import React, { useState, useEffect } from 'react';
import {
  ShieldCheck,
  Lock,
  Mail,
  User,
  Key,
  Sparkles,
  ArrowRight,
  UserCheck,
  GraduationCap,
  Eye,
  EyeOff,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Check,
  ChevronDown,
  Layers,
  FileCheck,
  SlidersHorizontal,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageOnboardingBanner, OnboardingStep } from '../components/PageOnboardingBanner';

interface SavedCredential {
  id: string;
  name: string;
  role: 'student' | 'admin';
  email: string;
  passwordDisplay: string;
  badge: string;
  details: string;
  avatarBg: string;
  initials: string;
}

const SAVED_CREDENTIALS: SavedCredential[] = [
  {
    id: 'ananya',
    name: 'Ananya Krishnan',
    role: 'student',
    email: 'ananya.k@example.com',
    passwordDisplay: '••••••••••••',
    badge: 'Student • 72% Ready',
    details: 'App ID: CP-2026-1048 (Class 12 Mismatch Demo)',
    avatarBg: 'bg-gradient-to-br from-[#2F7454] to-[#1C4937]',
    initials: 'AK',
  },
  {
    id: 'sundaram',
    name: 'Dr. M. Sundaram',
    role: 'admin',
    email: 'officer.sundaram@annauniv.edu',
    passwordDisplay: '••••••••••••',
    badge: 'Admission Officer',
    details: 'Staff ID: ADM-OFFICER-01 (Full Scrutiny Queue)',
    avatarBg: 'bg-gradient-to-br from-[#2F7454] to-emerald-700',
    initials: 'MS',
  },
  {
    id: 'kavitha',
    name: 'Kavitha R.',
    role: 'student',
    email: 'kavitha.r@example.com',
    passwordDisplay: '••••••••••••',
    badge: 'Applicant • 25% Ready',
    details: 'App ID: CP-2026-1052 (Initial Document Stage)',
    avatarBg: 'bg-gradient-to-br from-purple-600 to-pink-700',
    initials: 'KR',
  },
];

const LOGIN_ONBOARDING_STEPS: OnboardingStep[] = [
  {
    title: 'Choose Login Type',
    desc: 'Choose Student or Officer login.',
    icon: GraduationCap,
  },
  {
    title: 'Use Demo Login',
    desc: 'Use the demo account to fill login details.',
    icon: Key,
  },
  {
    title: 'Open Demo Account',
    desc: 'Sign in to open the demo application.',
    icon: CheckCircle2,
  },
];

export const LoginPage: React.FC = () => {
  const { setRole, navigateTo, addToast, language } = useApp();

  const [activeTab, setActiveTab] = useState<'student' | 'admin'>('student');
  const [emailOrPhone, setEmailOrPhone] = useState('ananya.k@example.com');
  const [password, setPassword] = useState('StudentPass2026!');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(true);
  const [isLoading, setIsLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');

  // Password Manager Autofill Prompt states
  const [showAutofillPrompt, setShowAutofillPrompt] = useState(true);
  const [isAutofilled, setIsAutofilled] = useState(false);
  const [selectedCredId, setSelectedCredId] = useState<string>('ananya');

  // Trigger autofill for a specific saved credential
  const handleSelectCredential = (cred: SavedCredential, autoSubmit: boolean = false) => {
    setSelectedCredId(cred.id);
    setEmailOrPhone(cred.email);
    setPassword('SecurePass2026!');
    setActiveTab(cred.role);
    setIsAutofilled(true);
    setShowAutofillPrompt(false);

    addToast(`Autofilled credentials for ${cred.name} (${cred.badge})`, 'info');

    if (autoSubmit) {
      executeLogin(cred.role, cred.name, cred.email);
    }
  };

  const executeLogin = (roleToSet: 'student' | 'admin', name: string, email: string) => {
    setIsLoading(true);
    setErrorMessage('');

    setTimeout(() => {
      setIsLoading(false);
      setRole(roleToSet);

      if (roleToSet === 'admin') {
        addToast(`Signed in as Admission Officer ${name}`, 'success');
        navigateTo('/admin/dashboard');
      } else {
        addToast(`Signed in as ${name} (Application ID: CP-2026-1048)`, 'success');
        navigateTo('/student/dashboard');
      }
    }, 600);
  };

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');

    if (!emailOrPhone.trim()) {
      setErrorMessage('Please enter your email or registered phone number.');
      return;
    }
    if (!password.trim()) {
      setErrorMessage('Please enter your password or PIN.');
      return;
    }

    const isOfficer =
      activeTab === 'admin' ||
      emailOrPhone.toLowerCase().includes('officer') ||
      emailOrPhone.toLowerCase().includes('admin');

    const roleToSet: 'student' | 'admin' = isOfficer ? 'admin' : 'student';
    const displayName = isOfficer ? 'Dr. M. Sundaram' : 'Ananya Krishnan';

    executeLogin(roleToSet, displayName, emailOrPhone);
  };

  return (
    <div className="min-h-screen bg-[#FAF6ED] flex flex-col justify-center py-10 px-4 sm:px-6 lg:px-8">
      <div className="max-w-3xl mx-auto w-full">
        {/* Page Onboarding Banner */}
        <PageOnboardingBanner
          pageKey="login"
          pageTitle={language === 'ta' ? 'உள்நுழைவு பக்கம்' : 'Authentication & Access'}
          uniqueFocus="Dedicated to role selection, browser credential autofill prompts, and session security without duplicating dashboard tasks."
          description="Authenticate as an applicant or admission officer. Test automated password manager autofill prompts."
          steps={LOGIN_ONBOARDING_STEPS}
        />

        {/* Brand Header */}
        <div className="text-center mb-6">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-[#2F7454] to-[#7DB392] text-white flex items-center justify-center mx-auto shadow-md">
            <ShieldCheck className="w-7 h-7" />
          </div>
          <h1 className="mt-3 text-2xl sm:text-3xl font-extrabold text-[#2E342F] tracking-tight">
            ACEW Onboard Portal
          </h1>
          <p className="mt-1 text-xs sm:text-sm text-[#596159]">
            {language === 'ta'
              ? 'உங்கள் மாணவர் சேர்க்கை அல்லது அதிகாரி கணக்கில் உள்நுழையவும்'
              : 'Secure University Admission, Compliance & Workflow System'}
          </p>
        </div>

        {/* Main Card Container */}
        <div className="bg-white rounded-2xl shadow-xl border border-[#DED4C3] overflow-hidden">
          {/* Top Role Selector Tabs */}
          <div className="grid grid-cols-2 border-b border-[#DED4C3] bg-[#FAF6ED]/70 p-1.5 gap-1.5">
            <button
              type="button"
              onClick={() => {
                setActiveTab('student');
                if (!isAutofilled) {
                  setEmailOrPhone('ananya.k@example.com');
                  setPassword('StudentPass2026!');
                }
              }}
              className={`py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                activeTab === 'student'
                  ? 'bg-white text-[#245C43] shadow-xs border border-[#DED4C3]/80'
                  : 'text-[#596159] hover:text-[#2E342F] hover:bg-white/50'
              }`}
            >
              <GraduationCap className="w-4 h-4 text-[#2F7454]" />
              <span>Student / Applicant Login</span>
            </button>
            <button
              type="button"
              onClick={() => {
                setActiveTab('admin');
                if (!isAutofilled) {
                  setEmailOrPhone('officer.sundaram@annauniv.edu');
                  setPassword('OfficerPass2026!');
                }
              }}
              className={`py-2.5 px-4 rounded-xl text-xs sm:text-sm font-bold flex items-center justify-center gap-2 transition-all ${
                activeTab === 'admin'
                  ? 'bg-white text-[#245C43] shadow-xs border border-[#DED4C3]/80'
                  : 'text-[#596159] hover:text-[#2E342F] hover:bg-white/50'
              }`}
            >
              <UserCheck className="w-4 h-4 text-[#2F7454]" />
              <span>Admission Officer Login</span>
            </button>
          </div>

          <div className="p-6 sm:p-8 space-y-6">
            {/* SIMULATED BROWSER PASSWORD MANAGER AUTOFILL PROMPT */}
            {showAutofillPrompt && (
              <div className="rounded-xl border border-[#C4E1CF] bg-gradient-to-r from-[#EEF7F1] via-[#F1F6F1]/50 to-[#EEF7F1] p-4 shadow-sm relative animate-in fade-in slide-in-from-top-2">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className="w-9 h-9 rounded-lg bg-[#2F7454] text-white flex items-center justify-center shadow-xs shrink-0 mt-0.5">
                      <Key className="w-4 h-4" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-[#12362A]">
                          Password Manager: Saved Passwords Found
                        </span>
                        <span className="text-[10px] font-semibold bg-[#C4E1CF]/70 text-[#1C4937] px-2 py-0.5 rounded-full">
                          Auto-fill Prompt
                        </span>
                      </div>
                      <p className="text-[11px] text-[#245C43]/90 mt-0.5">
                        Saved credentials detected for <code className="font-mono font-semibold">acew-onboard.edu</code>. Select an account to auto-fill automatically:
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => setShowAutofillPrompt(false)}
                    className="text-[#858B84] hover:text-[#596159] p-1"
                    title="Dismiss autofill prompt"
                  >
                    &times;
                  </button>
                </div>

                {/* Saved Accounts List */}
                <div className="mt-3 grid grid-cols-1 sm:grid-cols-3 gap-2">
                  {SAVED_CREDENTIALS.map((cred) => (
                    <div
                      key={cred.id}
                      onClick={() => handleSelectCredential(cred, false)}
                      className={`cursor-pointer p-2.5 rounded-xl border text-left transition-all hover:shadow-xs flex items-center gap-2.5 ${
                        selectedCredId === cred.id
                          ? 'bg-white border-[#4F936E] ring-2 ring-[#7DB392]/20 shadow-xs'
                          : 'bg-white/70 hover:bg-white border-[#DED4C3]'
                      }`}
                    >
                      <div
                        className={`w-7 h-7 rounded-full text-white text-[10px] font-bold flex items-center justify-center shrink-0 ${cred.avatarBg}`}
                      >
                        {cred.initials}
                      </div>
                      <div className="overflow-hidden flex-1">
                        <div className="text-xs font-bold text-[#2E342F] truncate">
                          {cred.name}
                        </div>
                        <div className="text-[10px] text-[#6B716A] truncate font-mono">
                          {cred.email}
                        </div>
                        <div className="text-[9px] font-semibold text-[#245C43] truncate mt-0.5">
                          {cred.badge}
                        </div>
                      </div>
                      {selectedCredId === cred.id && (
                        <Check className="w-4 h-4 text-[#2F7454] shrink-0" />
                      )}
                    </div>
                  ))}
                </div>

                {/* One-click Autofill & Continue Action */}
                <div className="mt-3 pt-3 border-t border-[#C4E1CF]/60 flex flex-wrap items-center justify-between gap-2">
                  <span className="text-[11px] text-[#6B716A]">
                    Selected: <strong>{SAVED_CREDENTIALS.find((c) => c.id === selectedCredId)?.name}</strong>
                  </span>

                  <div className="flex items-center gap-2">
                    <button
                      type="button"
                      onClick={() => {
                        const target = SAVED_CREDENTIALS.find((c) => c.id === selectedCredId) || SAVED_CREDENTIALS[0];
                        handleSelectCredential(target, false);
                      }}
                      className="px-3 py-1.5 bg-white hover:bg-[#FAF6ED] text-[#245C43] text-xs font-bold rounded-lg border border-[#A6CEB7] shadow-2xs transition-colors"
                    >
                      Fill Credentials Only
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const target = SAVED_CREDENTIALS.find((c) => c.id === selectedCredId) || SAVED_CREDENTIALS[0];
                        handleSelectCredential(target, true);
                      }}
                      className="px-3.5 py-1.5 bg-[#2F7454] hover:bg-[#245C43] text-white text-xs font-bold rounded-lg shadow-xs transition-colors flex items-center gap-1.5"
                    >
                      <Sparkles className="w-3.5 h-3.5" />
                      <span>Autofill &amp; Sign In Instantly</span>
                    </button>
                  </div>
                </div>
              </div>
            )}

            {/* Error Message */}
            {errorMessage && (
              <div className="p-3 bg-red-50 border border-red-200 text-red-800 text-xs rounded-xl flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-red-600 shrink-0" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Login Form */}
            <form onSubmit={handleManualSubmit} className="space-y-4">
              {/* Email / Username field */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-[#465047] flex items-center gap-1">
                    <Mail className="w-3.5 h-3.5 text-[#858B84]" />
                    <span>
                      {activeTab === 'student' ? 'Registered Email or Mobile' : 'Institutional Email (Officer ID)'}
                    </span>
                  </label>
                  {isAutofilled && (
                    <span className="text-[10px] font-semibold text-[#2F7454] bg-[#EEF7F1] px-2 py-0.5 rounded-full border border-[#C4E1CF] flex items-center gap-1">
                      <Check className="w-3 h-3" />
                      Autofilled from saved credentials
                    </span>
                  )}
                </div>

                <div className="relative">
                  <input
                    type="text"
                    required
                    value={emailOrPhone}
                    onChange={(e) => {
                      setEmailOrPhone(e.target.value);
                      setIsAutofilled(false);
                    }}
                    onFocus={() => {
                      if (!showAutofillPrompt) setShowAutofillPrompt(true);
                    }}
                    placeholder={
                      activeTab === 'student' ? 'ananya.k@example.com' : 'officer.sundaram@annauniv.edu'
                    }
                    className={`w-full px-3.5 py-2.5 text-xs sm:text-sm text-[#2E342F] border rounded-xl focus:outline-none focus:ring-2 transition-all ${
                      isAutofilled
                        ? 'bg-[#EEF7F1]/70 border-[#A6CEB7] ring-1 ring-[#7DB392]/30'
                        : 'bg-[#FAF6ED]/50 border-[#CEC4B3] focus:bg-white focus:border-[#4F936E] focus:ring-[#2F7454]'
                    }`}
                  />
                  <div className="absolute right-3 top-2.5 flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => setShowAutofillPrompt(true)}
                      className="text-[#858B84] hover:text-[#2F7454] p-0.5"
                      title="Show saved passwords prompt"
                    >
                      <Key className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </div>

              {/* Password field */}
              <div>
                <div className="flex items-center justify-between mb-1">
                  <label className="text-xs font-bold text-[#465047] flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5 text-[#858B84]" />
                    <span>Password / Security PIN</span>
                  </label>
                  <button
                    type="button"
                    onClick={() => addToast('Demo Password hint: Any password or PIN works!', 'info')}
                    className="text-[11px] font-semibold text-[#2F7454] hover:underline"
                  >
                    Forgot password?
                  </button>
                </div>

                <div className="relative">
                  <input
                    type={showPassword ? 'text' : 'password'}
                    required
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setIsAutofilled(false);
                    }}
                    onFocus={() => {
                      if (!showAutofillPrompt) setShowAutofillPrompt(true);
                    }}
                    placeholder="••••••••••••"
                    className={`w-full px-3.5 py-2.5 text-xs sm:text-sm text-[#2E342F] border rounded-xl focus:outline-none focus:ring-2 transition-all ${
                      isAutofilled
                        ? 'bg-[#EEF7F1]/70 border-[#A6CEB7] ring-1 ring-[#7DB392]/30'
                        : 'bg-[#FAF6ED]/50 border-[#CEC4B3] focus:bg-white focus:border-[#4F936E] focus:ring-[#2F7454]'
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-2.5 text-[#858B84] hover:text-[#596159] p-0.5"
                    title={showPassword ? 'Hide password' : 'Show password'}
                  >
                    {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                  </button>
                </div>
              </div>

              {/* Remember Me & Prompt Reopen */}
              <div className="flex items-center justify-between text-xs pt-1">
                <label className="flex items-center gap-2 cursor-pointer text-[#596159] select-none">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 text-[#2F7454] rounded border-[#CEC4B3] focus:ring-[#2F7454]"
                  />
                  <span>Remember my credentials</span>
                </label>

                {!showAutofillPrompt && (
                  <button
                    type="button"
                    onClick={() => setShowAutofillPrompt(true)}
                    className="text-[#2F7454] hover:text-[#1C4937] font-semibold flex items-center gap-1"
                  >
                    <Key className="w-3.5 h-3.5" />
                    <span>Autofill prompt</span>
                  </button>
                )}
              </div>

              {/* Submit Button */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3 px-4 bg-[#1D2D26] hover:bg-[#26382F] text-white font-bold rounded-xl text-xs sm:text-sm shadow-md transition-all flex items-center justify-center gap-2 disabled:opacity-70"
              >
                {isLoading ? (
                  <span>Authenticating session...</span>
                ) : (
                  <>
                    <span>
                      Sign In as {activeTab === 'student' ? 'Applicant / Student' : 'Admission Officer'}
                    </span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* Quick Demo Shortcuts Bar */}
            <div className="pt-4 border-t border-[#EEE7DA]">
              <div className="text-[11px] font-bold text-[#6B716A] uppercase tracking-wider mb-2 text-center">
                Instant One-Click Demo Personas
              </div>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => {
                    const studentCred = SAVED_CREDENTIALS[0];
                    handleSelectCredential(studentCred, true);
                  }}
                  className="py-2 px-3 rounded-lg bg-[#EEF7F1] hover:bg-[#DDEFE4] text-[#153B2E] border border-[#C4E1CF] text-xs font-semibold flex items-center justify-center gap-2 transition-all"
                >
                  <GraduationCap className="w-4 h-4 text-[#2F7454]" />
                  <span>Student (72% Ready)</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    const officerCred = SAVED_CREDENTIALS[1];
                    handleSelectCredential(officerCred, true);
                  }}
                  className="py-2 px-3 rounded-lg bg-[#EEF7F1] hover:bg-[#DDEFE4] text-[#153B2E] border border-[#C4E1CF] text-xs font-semibold flex items-center justify-center gap-2 transition-all"
                >
                  <UserCheck className="w-4 h-4 text-[#2F7454]" />
                  <span>Officer (Dr. Sundaram)</span>
                </button>
              </div>
            </div>

            {/* Bottom Return Link */}
            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => navigateTo('/')}
                className="text-xs font-semibold text-[#6B716A] hover:text-[#374039] transition-colors"
              >
                &larr; Back to Public Landing Page
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
