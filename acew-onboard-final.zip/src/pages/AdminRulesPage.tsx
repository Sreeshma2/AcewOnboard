import React, { useState } from 'react';
import {
  SlidersHorizontal,
  Plus,
  Download,
  Search,
  CheckCircle2,
  AlertCircle,
  Edit2,
  Layers,
  Save,
  Trash2,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageOnboardingBanner, OnboardingStep } from '../components/PageOnboardingBanner';

const RULES_STEPS: OnboardingStep[] = [
  {
    title: 'Set Course Marks',
    desc: 'Set minimum marks for each course.',
    icon: SlidersHorizontal,
  },
  {
    title: 'Set Required Documents',
    desc: 'Set documents required for each quota.',
    icon: Layers,
  },
  {
    title: 'Set Admission Rules',
    desc: 'Set admission dates and age limits.',
    icon: CheckCircle2,
  },
];

interface AdmissionRule {
  id: string;
  programme: string;
  quota: string;
  minCutoff: number;
  mandatoryDocs: string[];
  maxAge: number;
  deadline: string;
}

export const AdminRulesPage: React.FC = () => {
  const { addToast } = useApp();

  const [rules, setRules] = useState<AdmissionRule[]>([
    {
      id: 'rule-1',
      programme: 'B.Tech Computer Science and Engineering',
      quota: 'Tamil Nadu State Merit Quota',
      minCutoff: 185.0,
      mandatoryDocs: ['Class 10 Marksheet', 'Class 12 Marksheet', 'Transfer Certificate', 'Community Certificate'],
      maxAge: 21,
      deadline: '30 Sep 2026',
    },
    {
      id: 'rule-2',
      programme: 'B.Tech Artificial Intelligence & Data Science',
      quota: 'State Quota (BC / MBC / DNC)',
      minCutoff: 182.5,
      mandatoryDocs: ['Class 10 Marksheet', 'Class 12 Marksheet', 'Community Certificate', 'Nativity Proof'],
      maxAge: 21,
      deadline: '30 Sep 2026',
    },
    {
      id: 'rule-3',
      programme: 'B.Tech Mechanical Engineering',
      quota: 'Open Competition (OC)',
      minCutoff: 165.0,
      mandatoryDocs: ['Class 10 Marksheet', 'Class 12 Marksheet', 'Transfer Certificate'],
      maxAge: 21,
      deadline: '15 Oct 2026',
    },
    {
      id: 'rule-4',
      programme: 'B.Tech Electronics & Communication',
      quota: 'First Graduate Concession',
      minCutoff: 178.0,
      mandatoryDocs: ['Class 10 Marksheet', 'Class 12 Marksheet', 'First Graduate Certificate', 'Joint Declaration'],
      maxAge: 21,
      deadline: '30 Sep 2026',
    },
  ]);

  const [searchTerm, setSearchTerm] = useState('');

  const filteredRules = rules.filter(
    (r) =>
      r.programme.toLowerCase().includes(searchTerm.toLowerCase()) ||
      r.quota.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const handleExport = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(rules, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', 'acew_admission_rules_2026.json');
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    addToast('Admission rules exported as JSON.', 'success');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Page-Specific Onboarding Banner */}
      <PageOnboardingBanner
        pageKey="admin_rules"
        pageTitle="Admission Criteria & Quota Rules Config"
        uniqueFocus="Configuring institution-wide cutoff marks, quota-based document rules, and statutory deadlines without reviewing individual student files."
        description="Define admission parameters, manage cutoff thresholds per degree stream, and export criteria dockets."
        steps={RULES_STEPS}
      />

      {/* Header */}
      <div className="p-6 bg-white rounded-2xl border border-[#DED4C3] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <SlidersHorizontal className="w-6 h-6 text-[#2F7454]" />
            <h1 className="text-xl font-extrabold text-[#2E342F]">Admission Rules Engine</h1>
          </div>
          <p className="text-xs text-[#6B716A] mt-1">
            Configure dynamic document requirements, cutoffs, and verification criteria by academic programme.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExport}
            className="px-3.5 py-2 bg-[#F1E8D8] hover:bg-[#DED4C3] text-[#465047] font-semibold rounded-xl text-xs transition-colors flex items-center gap-1.5"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Config</span>
          </button>
          <button
            onClick={() => addToast('Rule template added. Edit parameters directly below.', 'info')}
            className="px-4 py-2 bg-[#2F7454] hover:bg-[#245C43] text-white font-bold rounded-xl text-xs shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Plus className="w-4 h-4" />
            <span>Add Programme Rule</span>
          </button>
        </div>
      </div>

      {/* Rules Table Container */}
      <div className="bg-white rounded-2xl border border-[#DED4C3] shadow-xs overflow-hidden">
        <div className="p-4 border-b border-[#DED4C3] flex items-center justify-between">
          <div className="relative max-w-xs w-full">
            <Search className="w-3.5 h-3.5 text-[#858B84] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Filter by programme or quota..."
              className="w-full pl-8 pr-3 py-1.5 text-xs bg-[#FAF6ED] border border-[#CEC4B3] rounded-lg focus:outline-none"
            />
          </div>
          <span className="text-xs font-semibold text-[#6B716A]">
            {filteredRules.length} Active Rules
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#FAF6ED] text-[#596159] font-bold border-b border-[#DED4C3]">
              <tr>
                <th className="p-3.5">Degree Programme</th>
                <th className="p-3.5">Category / Quota</th>
                <th className="p-3.5">Min Cutoff</th>
                <th className="p-3.5">Mandatory Certificates</th>
                <th className="p-3.5">Verification Deadline</th>
                <th className="p-3.5 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredRules.map((rule) => (
                <tr key={rule.id} className="hover:bg-[#FAF6ED]/60 transition-colors">
                  <td className="p-3.5 font-bold text-[#2E342F]">{rule.programme}</td>
                  <td className="p-3.5 text-[#465047]">{rule.quota}</td>
                  <td className="p-3.5 font-mono font-bold text-[#245C43]">{rule.minCutoff} / 200</td>
                  <td className="p-3.5">
                    <div className="flex flex-wrap gap-1 max-w-xs">
                      {rule.mandatoryDocs.map((doc, idx) => (
                        <span
                          key={idx}
                          className="text-[10px] bg-[#F1E8D8] text-[#465047] px-1.5 py-0.2 rounded"
                        >
                          {doc}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td className="p-3.5 font-semibold text-[#596159]">{rule.deadline}</td>
                  <td className="p-3.5 text-right">
                    <button
                      onClick={() => addToast(`Editing rule for ${rule.programme}`, 'info')}
                      className="p-1.5 hover:bg-[#F1E8D8] text-[#596159] rounded-lg"
                      title="Edit rule"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
