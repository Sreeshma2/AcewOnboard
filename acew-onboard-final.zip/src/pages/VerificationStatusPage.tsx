import React, { useState } from 'react';
import {
  ClipboardCheck,
  AlertTriangle,
  CheckCircle2,
  FileText,
  Clock,
  UserCheck,
  Sparkles,
  ArrowRight,
  Upload,
  Bot,
  ShieldCheck,
  ExternalLink,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DocumentUploadModal } from '../components/DocumentUploadModal';
import { PageOnboardingBanner, OnboardingStep } from '../components/PageOnboardingBanner';
import { ApplicationProgressStepper } from '../components/ApplicationProgressStepper';
import { WorkflowNavigationFooter } from '../components/WorkflowNavigationFooter';

const VERIFICATION_STEPS: OnboardingStep[] = [
  {
    title: 'Read Corrections',
    desc: 'Read why a document needs correction.',
    icon: AlertTriangle,
  },
  {
    title: 'Add Supporting Proof',
    desc: 'Add a note or upload supporting proof.',
    icon: Sparkles,
  },
  {
    title: 'Check Updates',
    desc: 'Check updates made to your application.',
    icon: Clock,
  },
];

export const VerificationStatusPage: React.FC = () => {
  const {
    studentProfile,
    documents,
    verificationAuditLogs,
    resolveDocumentCorrection,
    addToast,
    navigateTo,
  } = useApp();

  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [selectedProofType, setSelectedProofType] = useState('aadhaar_initial');
  const [explanationNote, setExplanationNote] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const marksheetDoc = documents.find((d) => d.id === 'doc-12th');
  const isCorrectionRequired = marksheetDoc?.status === 'Needs correction';

  const handleQuickConfirm = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      resolveDocumentCorrection(
        'doc-12th',
        'Ananya Krishnan S',
        'Student confirmed initial S stands for father Subramanian as documented in Aadhaar card.'
      );
      setIsSubmitting(false);
      addToast(
        'Correction submitted for officer sign-off. Class 12 status updated to Under Review.',
        'success'
      );
    }, 600);
  };

  return (
    <div className="space-y-6 pb-12 max-w-7xl mx-auto">
      {/* 6-Stage Stepper */}
      <ApplicationProgressStepper currentStepIndex={4} />

      {/* Page-Specific Onboarding Banner */}
      <PageOnboardingBanner
        pageKey="verification"
        pageTitle="Step 4: Verification Audit & Discrepancy Resolution"
        uniqueFocus="Explaining mismatched document fields (like patronymic initials), submitting clarification affidavits, and reviewing the immutable officer audit log."
        description="Review explainable verification decisions, resolve flagged items, and track officer review history."
        steps={VERIFICATION_STEPS}
      />

      {/* Page Header */}
      <div className="p-6 bg-white rounded-2xl border border-[#DED4C3] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ClipboardCheck className="w-6 h-6 text-[#2F7454]" />
            <h1 className="text-xl font-extrabold text-[#2E342F]">Verification Status</h1>
            <span
              className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                isCorrectionRequired
                  ? 'bg-amber-100 text-amber-800 border border-amber-300'
                  : 'bg-green-100 text-green-800 border border-green-300'
              }`}
            >
              {isCorrectionRequired ? 'Correction Action Required' : 'Under Officer Review'}
            </span>
          </div>
          <p className="text-xs text-[#6B716A] mt-1">
            Transparent institutional verification tracking with field-by-field OCR explainability.
          </p>
        </div>

        <button
          onClick={() => navigateTo('/student/receipt')}
          className="px-4 py-2 bg-[#F1E8D8] hover:bg-[#DED4C3] text-[#465047] font-semibold rounded-xl text-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <span>View Verification Receipt</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* 4-Stage Visual Progression Tracker */}
      <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-xs">
        <h3 className="text-xs font-bold uppercase tracking-wider text-[#858B84] mb-4">
          Admission Verification Pipeline
        </h3>
        <div className="grid grid-cols-1 sm:grid-cols-4 gap-4 relative">
          {[
            {
              step: '1. Submitted',
              status: 'Completed',
              desc: 'Application & documents uploaded',
              color: 'bg-green-600 text-white',
            },
            {
              step: '2. Assistive Check',
              status: 'Completed',
              desc: 'OCR extraction & trust screening',
              color: 'bg-green-600 text-white',
            },
            {
              step: '3. Data Resolution',
              status: isCorrectionRequired ? 'In Progress' : 'Completed',
              desc: isCorrectionRequired ? 'Name mismatch resolution pending' : 'Resolved by candidate',
              color: isCorrectionRequired ? 'bg-amber-500 text-white ring-4 ring-amber-100' : 'bg-green-600 text-white',
            },
            {
              step: '4. Officer Sign-off',
              status: isCorrectionRequired ? 'Locked' : 'In Review',
              desc: 'Final desk stamp & QR generation',
              color: 'bg-[#DED4C3] text-[#596159]',
            },
          ].map((s, idx) => (
            <div key={idx} className="p-3 bg-[#FAF6ED] rounded-xl border border-[#DED4C3]/80 space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-[#2E342F]">{s.step}</span>
                <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${s.color}`}>
                  {s.status}
                </span>
              </div>
              <p className="text-[11px] text-[#6B716A] leading-normal">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Main Explainable Correction Card */}
      {isCorrectionRequired && (
        <div className="p-6 bg-amber-50/40 border-2 border-amber-300 rounded-2xl shadow-xs space-y-5">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0">
              <AlertTriangle className="w-5 h-5" />
            </div>
            <div>
              <span className="text-[11px] font-bold uppercase tracking-wider text-amber-900">
                Action Required • Document Correction
              </span>
              <h2 className="text-base font-bold text-[#2E342F] mt-0.5">
                Class 12 Marksheet Name Discrepancy
              </h2>
              <p className="text-xs text-[#465047] mt-1 leading-relaxed">
                Our OCR extraction detected that your name on the uploaded Higher Secondary certificate contains an initial not present in your registered application profile.
              </p>
            </div>
          </div>

          {/* Field OCR Comparison Table */}
          <div className="p-4 bg-white rounded-xl border border-amber-200 shadow-2xs space-y-3">
            <div className="text-xs font-bold text-[#2E342F] pb-2 border-b border-[#EEE7DA] flex items-center justify-between">
              <span>Field Comparison Breakdown</span>
              <span className="text-[11px] font-normal text-[#6B716A]">
                Checked: 14 Sep, 10:15 AM by System OCR &amp; Officer Sundaram
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
              <div className="p-3 bg-[#FAF6ED] rounded-lg border border-[#DED4C3]">
                <span className="text-[11px] text-[#6B716A] font-semibold block">Application Profile Name</span>
                <p className="text-sm font-bold text-[#2E342F] mt-1">Ananya Krishnan</p>
                <span className="text-[10px] text-[#6B716A] mt-1 block">Registered in admission portal</span>
              </div>

              <div className="p-3 bg-amber-50 rounded-lg border border-amber-200">
                <span className="text-[11px] text-amber-800 font-semibold block">Class 12 Certificate OCR</span>
                <p className="text-sm font-bold text-amber-950 mt-1">Ananya Krishnan S</p>
                <span className="text-[10px] text-amber-700 mt-1 block">
                  Initial "S" present (Confidence: 94%)
                </span>
              </div>
            </div>
          </div>

          {/* Resolution Options */}
          <div className="space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-[#465047]">
              How would you like to resolve this discrepancy?
            </h3>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {/* Option A: Quick Confirm Initial */}
              <div className="p-4 bg-white rounded-xl border border-[#DED4C3] shadow-2xs space-y-2 flex flex-col justify-between">
                <div>
                  <h4 className="text-xs font-bold text-[#2E342F]">
                    Option 1: Confirm "S" is your legal initial
                  </h4>
                  <p className="text-[11px] text-[#596159] mt-1 leading-relaxed">
                    Certify that "Ananya Krishnan S" and "Ananya Krishnan" are the same person and matches your father's name (Subramanian) on your Aadhaar card.
                  </p>
                </div>
                <button
                  type="button"
                  disabled={isSubmitting}
                  onClick={handleQuickConfirm}
                  className="w-full mt-3 py-2 px-3 bg-[#2F7454] hover:bg-[#245C43] text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 shadow-2xs"
                >
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>{isSubmitting ? 'Confirming...' : 'Confirm Registered Initial'}</span>
                </button>
              </div>

              {/* Option B: Upload Supporting Proof */}
              <div className="p-4 bg-white rounded-xl border border-[#DED4C3] shadow-2xs space-y-2 flex flex-col justify-between">
                <div>
                  <h4 className="text-xs font-bold text-[#2E342F]">
                    Option 2: Re-upload Clear Marksheet or Gazette
                  </h4>
                  <p className="text-[11px] text-[#596159] mt-1 leading-relaxed">
                    Upload a high-resolution scan of your mark statement or school bonafide certificate clarifying the initial abbreviation.
                  </p>
                </div>
                <button
                  type="button"
                  onClick={() => setIsUploadModalOpen(true)}
                  className="w-full mt-3 py-2 px-3 bg-[#1D2D26] hover:bg-[#26382F] text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-1.5 shadow-2xs"
                >
                  <Upload className="w-3.5 h-3.5" />
                  <span>Re-upload Marksheet Scan</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Document Trust Check Summary */}
      <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#EEE7DA]">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#2F7454]" />
            <h3 className="text-sm font-bold text-[#2E342F]">Document Trust Check Audit</h3>
          </div>
          <span className="text-xs font-bold text-[#245C43] bg-[#EEF7F1] px-2.5 py-0.5 rounded-full border border-[#C4E1CF]">
            Assistive Screening Active
          </span>
        </div>
        <p className="text-xs text-[#596159] leading-relaxed">
          Document Trust Check conducts optical tamper detection, font consistency validation, and edge completeness checks to assist human officers during physical verification.
        </p>
      </div>

      {/* Chronological Audit Log */}
      <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-[#EEE7DA]">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-[#6B716A]" />
            <h3 className="text-sm font-bold text-[#2E342F]">Verification Timeline &amp; Audit Trail</h3>
          </div>
          <span className="text-[11px] text-[#858B84]">Chronological history</span>
        </div>

        <div className="space-y-3">
          {verificationAuditLogs.map((log) => (
            <div key={log.id} className="flex items-start gap-3 text-xs">
              <div className="w-2 h-2 rounded-full bg-[#2F7454] mt-1.5 shrink-0"></div>
              <div className="flex-1 p-3 bg-[#FAF6ED] rounded-xl border border-[#EEE7DA]">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-[#2E342F]">{log.action}</span>
                  <span className="text-[11px] text-[#858B84] font-mono">{log.timestamp}</span>
                </div>
                <p className="text-[#596159] text-[11px] mt-0.5">{log.notes}</p>
                <div className="text-[10px] text-[#858B84] mt-1">
                  Actor: <strong className="text-[#596159]">{log.performedBy}</strong>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Upload Modal */}
      {isUploadModalOpen && (
        <DocumentUploadModal
          isOpen={true}
          docId="doc-12th"
          docName="Class 12 Marksheet (Correction)"
          onClose={() => setIsUploadModalOpen(false)}
        />
      )}

      {/* Step Navigation Footer */}
      <WorkflowNavigationFooter
        currentStepNumber={4}
        customNextLabel="Proceed to Step 5: Onboarding Clearance & Fees"
      />
    </div>
  );
};
