import React from 'react';
import {
  ShieldCheck,
  FileCheck,
  ScanFace,
  CheckCircle2,
  Sparkles,
  ArrowRight,
  GraduationCap,
  Users,
  Compass,
  FileBadge,
  HelpCircle,
  Clock,
  Layers,
  CheckSquare,
  Lock,
} from 'lucide-react';
import { useApp } from '../context/AppContext';

export const LandingPage: React.FC = () => {
  const { navigateTo, setRole } = useApp();

  const features = [
    {
      icon: CheckSquare,
      title: 'Smart Document Checklist',
      desc: 'Personalized document requirements dynamically adapted to your specific degree programme and reservation quota.',
    },
    {
      icon: FileCheck,
      title: 'Explainable Verification',
      desc: 'Transparent verification status with human-readable error reasons, field OCR comparison, and zero cryptic rejections.',
    },
    {
      icon: ShieldCheck,
      title: 'Document Trust Check',
      desc: 'Assistive screening for tampering, edge cropping, and name consistency that flags issues for human officer inspection.',
    },
    {
      icon: ScanFace,
      title: 'Consent-Based Identity Check',
      desc: 'Privacy-first liveness presence check and ID photograph cross-match with full right to manual in-person verification.',
    },
    {
      icon: Compass,
      title: 'Checkbox-Based Onboarding Progress',
      desc: 'Professional task management with automatic state progression, clear unlock rules, and no childish gamification.',
    },
    {
      icon: Sparkles,
      title: 'CampusBuddy AI Assistant',
      desc: 'Multi-turn intelligent chatbot delivering instant guidance, deadline clarity, and bilingual Tamil & English support.',
    },
    {
      icon: FileBadge,
      title: 'Complete Campus Readiness Workflow',
      desc: 'Integrated progression from academic verification to tuition fee payment, hostel allotment, and tamper-proof QR receipts.',
    },
  ];

  const steps = [
    {
      num: '01',
      title: 'Create Your Profile',
      desc: 'Fill in your academic background, contact information, guardian details, and campus preferences in one secure unified profile.',
    },
    {
      num: '02',
      title: 'Verify Identity & Documents',
      desc: 'Upload certificates with instant quality scanning, resolve name mismatches, and complete an assistive identity check.',
    },
    {
      num: '03',
      title: 'Become Campus Ready',
      desc: 'Reach 100% ACEW Readiness, download your digital QR verification receipt, and step onto campus with complete confidence.',
    },
  ];

  return (
    <div className="min-h-screen bg-[#FAF6ED] text-[#2E342F] flex flex-col">
      {/* Top Public Navigation Bar */}
      <nav className="bg-[#174A38] border-b border-[#25392F] text-white px-4 sm:px-6 lg:px-8 py-3.5 sticky top-0 z-40">
        <div className="max-w-6xl mx-auto flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-[#2F7454] to-[#F1F8F3] flex items-center justify-center text-white shadow-sm">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div>
              <span className="font-extrabold text-sm sm:text-base tracking-tight text-white block leading-tight">
                ACEW Onboard
              </span>
              <span className="text-[10px] text-[#858B84] font-medium">Smart Campus Admissions</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => navigateTo('/help')}
              className="hidden md:block text-xs font-semibold text-[#B4B9B2] hover:text-white px-2 py-1 transition-colors"
            >
              Help &amp; FAQs
            </button>
            <button
              onClick={() => navigateTo('/login')}
              className="px-4 py-2 bg-[#2F7454] hover:bg-[#1C4937] text-white rounded-xl text-xs sm:text-sm font-bold shadow-md transition-all flex items-center gap-1.5"
            >
              <Lock className="w-3.5 h-3.5" />
              <span>Login / Sign In</span>
            </button>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#174A38] to-slate-900 text-white pt-16 pb-24 px-4 sm:px-6 lg:px-8">
        {/* Subtle background mesh grid */}
        <div
          className="absolute inset-0 opacity-10 pointer-events-none"
          style={{
            backgroundImage: 'radial-gradient(#7DB392 1px, transparent 1px)',
            backgroundSize: '28px 28px',
          }}
        />

        <div className="relative max-w-5xl mx-auto text-center space-y-6">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#EEF7F1]/20 text-[#A6CEB7] text-xs font-semibold border border-[#7DB392]/30">
            <GraduationCap className="w-3.5 h-3.5 text-[#7DB392]" />
            <span>ACEW Onboard • Smart-Campus Admission &amp; Verification</span>
          </div>

          <h1 className="font-display text-3xl sm:text-5xl lg:text-6xl font-extrabold tracking-tight text-white leading-tight">
            Your complete campus journey, in one trusted place.
          </h1>

          <p className="max-w-2xl mx-auto text-sm sm:text-base text-[#B4B9B2] leading-relaxed">
            ACEW Onboard helps students submit documents, complete a consent-based identity check, resolve verification issues, and finish every important campus task from one simple dashboard.
          </p>

          <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
            <button
              onClick={() => {
                setRole('student');
                navigateTo('/student/dashboard');
              }}
              className="w-full sm:w-auto px-6 py-3.5 bg-[#2F7454] hover:bg-[#1C4937] text-white font-bold rounded-xl shadow-lg transition-all flex items-center justify-center gap-2 text-sm group"
            >
              <span>Start Admission</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
            </button>

            <button
              onClick={() => {
                setRole('student');
                navigateTo('/student/dashboard');
              }}
              className="w-full sm:w-auto px-6 py-3.5 bg-[#26382F] hover:bg-[#3E4740] text-[#D5D9D3] font-semibold rounded-xl border border-[#33473D] transition-all text-sm"
            >
              View Student Demo (72% Score)
            </button>

            <button
              onClick={() => {
                setRole('admin');
                navigateTo('/admin/dashboard');
              }}
              className="w-full sm:w-auto px-6 py-3.5 bg-[#245C43] hover:bg-[#2F7454] text-white font-semibold rounded-xl transition-all text-sm"
            >
              Officer Review Queue
            </button>
          </div>

          {/* Quick stats pills */}
          <div className="pt-8 grid grid-cols-2 sm:grid-cols-4 gap-3 max-w-3xl mx-auto text-left">
            <div className="p-3 bg-white/5 backdrop-blur-xs rounded-xl border border-white/10">
              <span className="text-xl font-bold text-white block">One Profile</span>
              <span className="text-xs text-[#858B84]">Zero redundant data entry</span>
            </div>
            <div className="p-3 bg-white/5 backdrop-blur-xs rounded-xl border border-white/10">
              <span className="text-xl font-bold text-[#7DB392] block">Assistive AI</span>
              <span className="text-xs text-[#858B84]">Never auto-rejects applicants</span>
            </div>
            <div className="p-3 bg-white/5 backdrop-blur-xs rounded-xl border border-white/10">
              <span className="text-xl font-bold text-[#7DB392] block">Human Review</span>
              <span className="text-xs text-[#858B84]">Always an appeal &amp; audit path</span>
            </div>
            <div className="p-3 bg-white/5 backdrop-blur-xs rounded-xl border border-white/10">
              <span className="text-xl font-bold text-[#A6CEB7] block">Bilingual</span>
              <span className="text-xs text-[#858B84]">English &amp; தமிழ் (Tamil)</span>
            </div>
          </div>
        </div>
      </section>

      {/* Process Section: 3-Step Journey */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto w-full">
        <div className="text-center space-y-2 mb-12">
          <span className="text-xs font-extrabold uppercase tracking-widest text-[#2F7454]">
            How ACEW Onboard Works
          </span>
          <h2 className="text-2xl sm:text-3xl font-bold text-[#2E342F]">
            Three Steps to Campus Readiness
          </h2>
          <p className="text-[#596159] text-sm max-w-xl mx-auto">
            From initial application submission to verified smart campus enrollment.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {steps.map((step, idx) => (
            <div
              key={idx}
              className="p-6 bg-white rounded-2xl border border-[#DED4C3] shadow-xs space-y-3 relative overflow-hidden"
            >
              <div className="w-10 h-10 rounded-xl bg-[#EEF7F1] text-[#245C43] font-extrabold flex items-center justify-center text-sm">
                {step.num}
              </div>
              <h3 className="text-base font-bold text-[#2E342F]">{step.title}</h3>
              <p className="text-xs text-[#596159] leading-relaxed">{step.desc}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Feature Highlights Grid */}
      <section className="py-16 bg-[#F1E8D8]/70 border-y border-[#DED4C3]/80 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center space-y-2 mb-12">
            <span className="text-xs font-extrabold uppercase tracking-widest text-[#245C43]">
              Core Capabilities
            </span>
            <h2 className="text-2xl sm:text-3xl font-bold text-[#2E342F]">
              Built for Trust, Compliance &amp; Simplicity
            </h2>
            <p className="text-[#596159] text-sm max-w-xl mx-auto">
              Solving document confusion, identity verification uncertainty, and disjointed campus workflows.
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {features.map((f, idx) => {
              const Icon = f.icon;
              return (
                <div
                  key={idx}
                  className="p-5 bg-white rounded-2xl border border-[#DED4C3]/90 shadow-2xs hover:shadow-xs transition-shadow space-y-2.5"
                >
                  <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-[#EEF7F1] to-[#F1F8F3] text-[#245C43] flex items-center justify-center border border-[#DDEFE4]">
                    <Icon className="w-5 h-5" />
                  </div>
                  <h3 className="text-sm font-bold text-[#2E342F]">{f.title}</h3>
                  <p className="text-xs text-[#596159] leading-relaxed">{f.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Trust & Ethics Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-5xl mx-auto">
        <div className="p-8 bg-gradient-to-br from-[#174A38] to-slate-900 rounded-3xl text-white shadow-xl space-y-6">
          <div className="flex items-center gap-2 text-[#7DB392] text-xs font-bold uppercase tracking-wider">
            <ShieldCheck className="w-4 h-4" />
            <span>Institutional Trust &amp; Privacy Mandate</span>
          </div>

          <h2 className="text-2xl sm:text-3xl font-bold text-white">
            Ethical, Assistive &amp; Always Human-Reviewed
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs text-[#B4B9B2]">
            <div className="p-4 bg-white/5 rounded-xl border border-white/10 space-y-1">
              <strong className="text-white block text-sm">No Automated Disqualifications</strong>
              <p className="leading-relaxed">
                Document Trust Check, liveness, and face cross-match are assistive screening signals only. They are never treated as conclusive proof of fraud or identity.
              </p>
            </div>
            <div className="p-4 bg-white/5 rounded-xl border border-white/10 space-y-1">
              <strong className="text-white block text-sm">Right to Manual Verification</strong>
              <p className="leading-relaxed">
                Students who encounter camera issues or prefer not to use biometric features can request an in-person or manual officer verification without penalty.
              </p>
            </div>
            <div className="p-4 bg-white/5 rounded-xl border border-white/10 space-y-1">
              <strong className="text-white block text-sm">Ephemeral Processing</strong>
              <p className="leading-relaxed">
                Raw camera video streams and biometric facial templates are not permanently stored by default. Only verification status and audit timestamps are kept.
              </p>
            </div>
            <div className="p-4 bg-white/5 rounded-xl border border-white/10 space-y-1">
              <strong className="text-white block text-sm">Full Audit Trail</strong>
              <p className="leading-relaxed">
                Every admission officer approval, rejection note, and correction explanation is permanently logged in a transparent audit ledger.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="mt-auto bg-[#1D2D26] text-[#858B84] py-10 px-4 sm:px-6 lg:px-8 border-t border-[#25392F] text-xs">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-[#7DB392]" />
            <span className="font-bold text-white text-sm">ACEW Onboard</span>
            <span className="text-[#6B716A]">| Tamil Nadu Higher Education Smart Campus Initiative</span>
          </div>

          <div className="flex items-center gap-6 text-xs text-[#858B84]">
            <button onClick={() => navigateTo('/help')} className="hover:text-white transition-colors">
              Privacy Notice
            </button>
            <button onClick={() => navigateTo('/help')} className="hover:text-white transition-colors">
              Help Centre
            </button>
            <button onClick={() => navigateTo('/help')} className="hover:text-white transition-colors">
              Terms of Admission
            </button>
            <span className="text-amber-400 font-semibold">Demo Mode Active</span>
          </div>
        </div>
        <div className="max-w-6xl mx-auto mt-4 pt-4 border-t border-[#25392F]/80 text-center text-[#6B716A] text-[11px]">
          ACEW Onboard (Admission, Compliance, Engagement and Workflow) • Assistive screening platform for university admissions.
        </div>
      </footer>
    </div>
  );
};
