import React, { useState } from 'react';
import {
  ShieldAlert,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ArrowRight,
  FileCheck,
  ScanFace,
  Compass,
  AlertCircle,
  FileText,
  Lock,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Sparkles,
  UserCheck,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { CircularProgress } from '../components/CircularProgress';
import { IdentityResultCard } from '../components/IdentityResultCard';
import { DocumentTrustBadge } from '../components/DocumentTrustBadge';
import { TaskCategory } from '../types';
import { PageOnboardingBanner, OnboardingStep } from '../components/PageOnboardingBanner';

const DASHBOARD_STEPS: OnboardingStep[] = [
  {
    title: 'Check Progress',
    desc: 'Check your application progress here.',
    icon: Compass,
  },
  {
    title: 'Fix Items',
    desc: 'Fix any item marked for your attention.',
    icon: AlertTriangle,
  },
  {
    title: 'View Stages',
    desc: 'Open each stage to see what remains.',
    icon: CheckCircle2,
  },
];

export const StudentDashboard: React.FC = () => {
  const {
    studentProfile,
    documents,
    identityCheck,
    tasks,
    readinessScore,
    completedTasksCount,
    totalTasksCount,
    remainingMandatoryCount,
    currentStage,
    isAcewReady,
    navigateTo,
    language,
  } = useApp();

  // Collapsible category state
  const [collapsedCategories, setCollapsedCategories] = useState<Record<string, boolean>>({
    profile: false,
    documents: false,
    identity: false,
    verification: false,
    admission: false,
    campus_setup: false,
  });

  const toggleCategory = (cat: string) => {
    setCollapsedCategories((prev) => ({ ...prev, [cat]: !prev[cat] }));
  };

  const categories: { key: TaskCategory; name: string; desc: string }[] = [
    { key: 'profile', name: 'A. Profile', desc: 'Personal, contact & guardian details' },
    { key: 'documents', name: 'B. Documents', desc: 'Academic marksheets, identity proof & certificates' },
    { key: 'identity', name: 'C. Identity Check', desc: 'Consent, liveness screening & face cross-match' },
    { key: 'verification', name: 'D. Verification', desc: 'Data confirmation, mismatch resolution & officer review' },
    { key: 'admission', name: 'E. Admission', desc: 'Seat acceptance, fee payment & medical declaration' },
    { key: 'campus_setup', name: 'F. Campus Setup', desc: 'Hostel, student smart ID, Wi-Fi & orientation' },
  ];

  // Document health counts
  const verifiedDocsCount = documents.filter((d) => d.status === 'Verified').length;
  const pendingDocsCount = documents.filter((d) => d.status === 'Pending').length;
  const needsCorrectionDocsCount = documents.filter((d) => d.status === 'Needs correction').length;

  const handleNextTaskClick = () => {
    const nextTask = tasks.find(
      (t) => t.status === 'needs_correction' || (t.isMandatory && t.status === 'pending')
    );
    if (nextTask?.actionRoute) {
      navigateTo(nextTask.actionRoute);
    } else {
      navigateTo('/student/verification');
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Page-Specific Onboarding Banner */}
      <PageOnboardingBanner
        pageKey="dashboard"
        pageTitle="Student Command Center"
        uniqueFocus="Overall Readiness Score monitoring, urgent action alerts, and milestone task progression without duplicated sub-forms."
        description="Your unified admission overview. Check stage progression and follow prioritized tasks to reach 100% readiness."
        steps={DASHBOARD_STEPS}
      />

      {/* Welcome Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-6 bg-gradient-to-r from-[#174A38] to-slate-800 text-white rounded-2xl shadow-sm border border-[#33473D]/50">
        <div>
          <div className="flex items-center gap-2">
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              Good morning, {studentProfile.fullName.split(' ')[0]}.
            </h1>
            <span className="text-[11px] font-bold bg-amber-500/20 text-amber-300 border border-amber-400/30 px-2 py-0.5 rounded-full">
              Action Required
            </span>
          </div>
          <p className="text-xs text-[#B4B9B2] mt-1">
            Application ID: <span className="font-mono text-white font-semibold">{studentProfile.applicationId}</span> • Programme: {studentProfile.programme}
          </p>
        </div>

        <div className="flex items-center gap-2">
          {isAcewReady ? (
            <button
              onClick={() => navigateTo('/student/receipt')}
              className="px-4 py-2 bg-green-600 hover:bg-green-500 text-white font-bold rounded-xl text-xs shadow-xs transition-all flex items-center gap-1.5"
            >
              <span>Download QR Receipt</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          ) : (
            <button
              onClick={handleNextTaskClick}
              className="px-4 py-2 bg-[#2F7454] hover:bg-[#1C4937] text-white font-bold rounded-xl text-xs shadow-xs transition-all flex items-center gap-1.5"
            >
              <span>Continue Next Task</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>
      </div>

      {/* Main Row: Circular Progress Card & Next Required Action */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
        {/* Circular Progress Card */}
        <div className="lg:col-span-5 bg-white p-6 rounded-2xl border border-[#DED4C3] shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between pb-3 border-b border-[#EEE7DA]">
              <div>
                <h2 className="text-base font-bold text-[#2E342F]">ACEW Readiness Score</h2>
                <p className="text-xs text-[#6B716A]">Admission, Compliance, Engagement &amp; Workflow</p>
              </div>
              <span className="text-xs font-bold text-[#245C43] bg-[#EEF7F1] border border-[#C4E1CF] px-2.5 py-1 rounded-full">
                {currentStage}
              </span>
            </div>

            <div className="my-6 flex items-center justify-center">
              <CircularProgress
                score={readinessScore}
                completedTasks={completedTasksCount}
                totalTasks={totalTasksCount}
              />
            </div>
          </div>

          <div className="space-y-3 pt-3 border-t border-[#EEE7DA]">
            <div className="flex items-center justify-between text-xs">
              <span className="text-[#6B716A] font-medium">Mandatory tasks remaining:</span>
              <span className="font-bold text-[#2E342F] bg-[#F1E8D8] px-2 py-0.5 rounded-full">
                {remainingMandatoryCount} tasks
              </span>
            </div>
            <button
              onClick={handleNextTaskClick}
              className="w-full py-2.5 bg-[#2F7454] hover:bg-[#245C43] text-white font-bold rounded-xl text-xs transition-colors flex items-center justify-center gap-2"
            >
              <span>Continue next task</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Next Required Action & Status Highlights */}
        <div className="lg:col-span-7 flex flex-col gap-4">
          {/* Priority Next Action Card */}
          <div className="p-5 bg-gradient-to-br from-amber-50 to-orange-50/50 border-2 border-amber-300/80 rounded-2xl shadow-xs">
            <div className="flex items-start gap-3">
              <div className="w-10 h-10 rounded-xl bg-amber-500 text-white flex items-center justify-center shrink-0 shadow-xs">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <div className="flex-1">
                <span className="text-[11px] font-bold uppercase tracking-wider text-amber-800">
                  Your Next Required Action
                </span>
                <h3 className="text-sm sm:text-base font-bold text-[#2E342F] mt-0.5">
                  Correct your Class 12 marksheet
                </h3>
                <p className="text-xs text-[#465047] mt-1 leading-relaxed">
                  The name on your Class 12 marksheet reads <strong>"Ananya Krishnan S"</strong>, whereas your application profile is registered as <strong>"Ananya Krishnan"</strong>. Please confirm your registered name or upload supporting proof.
                </p>
                <div className="mt-3.5 flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => navigateTo('/student/verification')}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl text-xs shadow-xs transition-colors flex items-center gap-1.5"
                  >
                    <span>Fix now</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => navigateTo('/student/identity-check')}
                    className="px-3 py-2 bg-white hover:bg-[#FAF6ED] text-[#465047] font-semibold rounded-xl text-xs border border-[#CEC4B3] transition-colors"
                  >
                    Review Identity Check
                  </button>
                </div>
              </div>
            </div>
          </div>

          {/* 4 Summary Cards Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 flex-1">
            {/* Card 1: Application Status */}
            <div className="p-4 bg-white rounded-xl border border-[#DED4C3] shadow-2xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-[#6B716A]">Application Status</span>
                <span className="w-2 h-2 rounded-full bg-amber-500"></span>
              </div>
              <p className="text-sm font-bold text-[#2E342F]">Needs correction</p>
              <p className="text-[11px] text-[#6B716A]">
                Last updated today • ID: {studentProfile.applicationId}
              </p>
            </div>

            {/* Card 2: Document Health */}
            <div className="p-4 bg-white rounded-xl border border-[#DED4C3] shadow-2xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-[#6B716A]">Document Health</span>
                <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.2 rounded">
                  Medium Risk
                </span>
              </div>
              <p className="text-sm font-bold text-[#2E342F]">
                {verifiedDocsCount} verified • {pendingDocsCount} pending
              </p>
              <p className="text-[11px] text-amber-700 font-medium">
                {needsCorrectionDocsCount} document needs correction
              </p>
            </div>

            {/* Card 3: Identity Check */}
            <div className="p-4 bg-white rounded-xl border border-[#DED4C3] shadow-2xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-[#6B716A]">Identity Check</span>
                <span className="text-[11px] font-bold text-amber-700 bg-amber-50 px-1.5 py-0.2 rounded">
                  Review Req
                </span>
              </div>
              <p className="text-sm font-bold text-[#2E342F]">
                Liveness: Passed • Match: Inconclusive
              </p>
              <button
                onClick={() => navigateTo('/student/identity-check')}
                className="text-[11px] font-bold text-[#2F7454] hover:underline inline-block pt-0.5"
              >
                Review identity check &rarr;
              </button>
            </div>

            {/* Card 4: Campus Readiness */}
            <div className="p-4 bg-white rounded-xl border border-[#DED4C3] shadow-2xs space-y-1">
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-semibold text-[#6B716A]">Campus Readiness</span>
                <span className="text-[11px] font-bold text-[#245C43] bg-[#EEF7F1] px-1.5 py-0.2 rounded">
                  72%
                </span>
              </div>
              <p className="text-sm font-bold text-[#2E342F]">
                {completedTasksCount} of {totalTasksCount} tasks complete
              </p>
              <p className="text-[11px] text-[#6B716A]">
                {remainingMandatoryCount} mandatory tasks remaining
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Checkbox-Based Onboarding Checklist Model */}
      <div className="bg-white rounded-2xl border border-[#DED4C3] shadow-xs overflow-hidden">
        <div className="p-5 border-b border-[#DED4C3] flex flex-col sm:flex-row sm:items-center justify-between gap-2">
          <div>
            <h2 className="text-base font-bold text-[#2E342F]">
              Checkbox-Based Onboarding Checklist
            </h2>
            <p className="text-xs text-[#6B716A]">
              Tasks automatically update upon completion or officer verification. No manual check-offs.
            </p>
          </div>
          <div className="flex items-center gap-2 text-xs font-semibold text-[#596159]">
            <span className="inline-flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5 text-green-600" /> Completed
            </span>
            <span className="inline-flex items-center gap-1">
              <AlertTriangle className="w-3.5 h-3.5 text-amber-500" /> Action Required
            </span>
            <span className="inline-flex items-center gap-1">
              <Lock className="w-3.5 h-3.5 text-[#858B84]" /> Locked
            </span>
          </div>
        </div>

        {/* Collapsible Category Sections */}
        <div className="divide-y divide-slate-200">
          {categories.map((cat) => {
            const catTasks = tasks.filter((t) => t.category === cat.key);
            const catCompleted = catTasks.filter((t) => t.status === 'completed').length;
            const isCollapsed = collapsedCategories[cat.key];

            return (
              <div key={cat.key} className="transition-colors">
                {/* Category Header Bar */}
                <button
                  type="button"
                  onClick={() => toggleCategory(cat.key)}
                  className="w-full px-5 py-3.5 bg-[#FAF6ED] hover:bg-[#F1E8D8]/70 flex items-center justify-between text-left transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-[#2E342F]">{cat.name}</span>
                    <span className="text-[11px] text-[#6B716A] hidden sm:inline">{cat.desc}</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-xs font-bold text-[#465047] bg-white px-2.5 py-0.5 rounded-full border border-[#DED4C3]">
                      {catCompleted}/{catTasks.length}
                    </span>
                    {isCollapsed ? (
                      <ChevronDown className="w-4 h-4 text-[#6B716A]" />
                    ) : (
                      <ChevronUp className="w-4 h-4 text-[#6B716A]" />
                    )}
                  </div>
                </button>

                {/* Tasks List */}
                {!isCollapsed && (
                  <div className="divide-y divide-slate-100 p-2 sm:p-3 space-y-1">
                    {catTasks.map((task) => {
                      const isCompleted = task.status === 'completed';
                      const isNeedsCorrection = task.status === 'needs_correction';
                      const isLocked = task.status === 'locked';
                      const isOptional = task.status === 'optional' || !task.isMandatory;

                      return (
                        <div
                          key={task.id}
                          className={`p-3 rounded-xl flex items-start justify-between gap-3 transition-colors ${
                            isNeedsCorrection
                              ? 'bg-amber-50/60 border border-amber-200'
                              : isLocked
                              ? 'bg-[#FAF6ED]/70 opacity-80'
                              : 'hover:bg-[#FAF6ED]'
                          }`}
                        >
                          {/* Left: Checkbox Icon + Content */}
                          <div className="flex items-start gap-3 flex-1">
                            <div className="mt-0.5 shrink-0">
                              {isCompleted && (
                                <div className="w-5 h-5 rounded-full bg-green-100 text-green-700 flex items-center justify-center border border-green-300">
                                  <CheckCircle2 className="w-3.5 h-3.5" />
                                </div>
                              )}
                              {isNeedsCorrection && (
                                <div className="w-5 h-5 rounded-full bg-red-100 text-red-700 flex items-center justify-center border border-red-300">
                                  <AlertCircle className="w-3.5 h-3.5" />
                                </div>
                              )}
                              {isLocked && (
                                <div className="w-5 h-5 rounded-full bg-[#DED4C3] text-[#6B716A] flex items-center justify-center">
                                  <Lock className="w-3 h-3" />
                                </div>
                              )}
                              {!isCompleted && !isNeedsCorrection && !isLocked && (
                                <div className="w-5 h-5 rounded-full border-2 border-[#CEC4B3]"></div>
                              )}
                            </div>

                            <div className="space-y-0.5">
                              <div className="flex items-center gap-2">
                                <span className="text-xs font-bold text-[#2E342F]">
                                  {task.name}
                                </span>
                                {isOptional && (
                                  <span className="text-[10px] font-semibold text-[#6B716A] bg-[#DED4C3]/80 px-1.5 py-0.2 rounded">
                                    Optional
                                  </span>
                                )}
                                {task.dueDate && (
                                  <span className="text-[10px] text-[#858B84]">
                                    Due: {task.dueDate}
                                  </span>
                                )}
                              </div>
                              <p className="text-[11px] text-[#596159] leading-normal">
                                {task.description}
                              </p>

                              {task.correctionReason && (
                                <p className="text-[11px] text-red-700 font-semibold pt-0.5">
                                  Reason: {task.correctionReason}
                                </p>
                              )}

                              {task.unlockCondition && isLocked && (
                                <p className="text-[11px] text-[#6B716A] italic pt-0.5 flex items-center gap-1">
                                  <Lock className="w-3 h-3 text-[#858B84]" />
                                  {task.unlockCondition}
                                </p>
                              )}
                            </div>
                          </div>

                          {/* Right: Action Button */}
                          <div className="shrink-0 ml-2">
                            {isCompleted ? (
                              <span className="text-[11px] text-green-700 font-semibold bg-green-50 px-2 py-1 rounded-lg">
                                {task.completedAt || 'Done'}
                              </span>
                            ) : isNeedsCorrection ? (
                              <button
                                onClick={() => navigateTo(task.actionRoute || '/student/verification')}
                                className="px-3 py-1.5 bg-red-600 hover:bg-red-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors"
                              >
                                Fix now
                              </button>
                            ) : isLocked ? (
                              <span className="text-[11px] font-semibold text-[#858B84] px-2 py-1">
                                Locked
                              </span>
                            ) : (
                              <button
                                onClick={() => navigateTo(task.actionRoute || '/student/onboarding')}
                                className="px-3 py-1.5 bg-[#1D2D26] hover:bg-[#26382F] text-white font-semibold text-xs rounded-xl shadow-xs transition-colors"
                              >
                                {task.actionLabel || 'Open'}
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Two Columns: Document Health Panel & Identity Check Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Document Health Panel */}
        <div className="bg-white p-5 rounded-2xl border border-[#DED4C3] shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#EEE7DA]">
            <div className="flex items-center gap-2">
              <FileCheck className="w-5 h-5 text-[#2F7454]" />
              <h3 className="text-sm font-bold text-[#2E342F]">Document Health</h3>
            </div>
            <button
              onClick={() => navigateTo('/student/documents')}
              className="text-xs font-semibold text-[#2F7454] hover:underline"
            >
              View Checklist &rarr;
            </button>
          </div>

          <div className="space-y-2.5">
            {documents.slice(0, 5).map((doc) => {
              const isVerified = doc.status === 'Verified';
              const isCorrection = doc.status === 'Needs correction';

              return (
                <div
                  key={doc.id}
                  className="p-3 rounded-xl border border-[#EEE7DA] bg-[#FAF6ED]/60 flex items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-2.5 overflow-hidden">
                    <FileText className="w-4 h-4 text-[#858B84] shrink-0" />
                    <div className="truncate">
                      <p className="text-xs font-bold text-[#2E342F] truncate">{doc.name}</p>
                      <p className="text-[10px] text-[#6B716A]">
                        {doc.fileName || 'Pending upload'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <span
                      className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                        isVerified
                          ? 'bg-green-100 text-green-800'
                          : isCorrection
                          ? 'bg-red-100 text-red-800'
                          : 'bg-[#DED4C3] text-[#465047]'
                      }`}
                    >
                      {doc.status}
                    </span>
                    {isCorrection && (
                      <button
                        onClick={() => navigateTo('/student/verification')}
                        className="text-[11px] font-bold text-[#2F7454] hover:underline"
                      >
                        Fix
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Identity Status Panel */}
        <div className="bg-white p-5 rounded-2xl border border-[#DED4C3] shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#EEE7DA]">
            <div className="flex items-center gap-2">
              <ScanFace className="w-5 h-5 text-[#2F7454]" />
              <h3 className="text-sm font-bold text-[#2E342F]">Identity Status</h3>
            </div>
            <button
              onClick={() => navigateTo('/student/identity-check')}
              className="text-xs font-semibold text-[#245C43] hover:underline"
            >
              Full Screening Details &rarr;
            </button>
          </div>

          <IdentityResultCard
            identityCheck={identityCheck}
            onRetry={() => navigateTo('/student/identity-check')}
            onRequestManualReview={() => navigateTo('/student/identity-check')}
            onViewPrivacy={() => navigateTo('/help')}
          />
        </div>
      </div>
    </div>
  );
};
