import React, { useState } from 'react';
import {
  ShieldCheck,
  FileCheck2,
  ScanFace,
  AlertTriangle,
  CheckCircle2,
  XCircle,
  Save,
  ArrowLeft,
  Eye,
  Clock,
  UserCheck,
  FileText,
  Sparkles,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DocumentStatus } from '../types';
import { PageOnboardingBanner, OnboardingStep } from '../components/PageOnboardingBanner';

const SCRUTINY_STEPS: OnboardingStep[] = [
  {
    title: 'Review Documents',
    desc: 'Review the student documents.',
    icon: FileCheck2,
  },
  {
    title: 'Approve Or Request Changes',
    desc: 'Approve or request changes with a note.',
    icon: ShieldCheck,
  },
  {
    title: 'Review Identity Result',
    desc: 'Review the identity result and decide next steps.',
    icon: ScanFace,
  },
];

export const AdminReviewApplicationPage: React.FC = () => {
  const {
    studentProfile,
    documents,
    identityCheck,
    readinessScore,
    adminVerifyDocument,
    adminUpdateIdentityStatus,
    navigateTo,
    addToast,
    verificationAuditLogs,
  } = useApp();

  const [docStatus, setDocStatus] = useState<DocumentStatus>('Needs correction');
  const [officerNotes, setOfficerNotes] = useState(
    'Candidate has clarified initial S corresponds to father name Subramanian. Supporting Aadhaar cross-check verified.'
  );
  const [isSubmitting, setIsSubmitting] = useState(false);

  const marksheetDoc = documents.find((d) => d.id === 'doc-12th');

  const handleApproveMarksheet = () => {
    adminVerifyDocument(
      'doc-12th',
      'Verified',
      officerNotes || 'Officer confirmed initial S is acceptable based on Aadhaar linkage.'
    );
    setDocStatus('Verified');
    addToast('Class 12 Marksheet approved by Officer Sundaram.', 'success');
  };

  const handleOverrideIdentity = () => {
    adminUpdateIdentityStatus(
      'passed',
      'Officer Dr. M. Sundaram conducted visual scrutiny and confirmed candidate match despite low-res ID photo.'
    );
    addToast('Identity check manually verified and approved by Officer.', 'success');
  };

  const handleRequestInPerson = () => {
    adminUpdateIdentityStatus(
      'review_required',
      'Officer flagged candidate for in-person biometric scrutiny on physical arrival.'
    );
    addToast('Flagged for physical verification at campus desk on arrival day.', 'info');
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Page-Specific Onboarding Banner */}
      <PageOnboardingBanner
        pageKey="admin_scrutiny"
        pageTitle="Candidate Scrutiny & Officer Authority Workstation"
        uniqueFocus="Executing individual officer overrides, resolving candidate discrepancy files, and signing off on admission eligibility without general list views."
        description="Detailed dossier review for Ananya Krishnan. Review OCR extraction, verify tamper scores, and record official approval notes."
        steps={SCRUTINY_STEPS}
      />

      {/* Top Header & Breadcrumb */}
      <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <button
            onClick={() => navigateTo('/admin/dashboard')}
            className="p-2 hover:bg-[#F1E8D8] rounded-xl text-[#6B716A] transition-colors"
            title="Back to queue"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="text-lg font-bold text-[#2E342F]">{studentProfile.fullName}</h1>
              <span className="text-xs font-mono font-bold text-[#245C43] bg-[#EEF7F1] px-2 py-0.5 rounded">
                {studentProfile.applicationId}
              </span>
              <span className="text-xs font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded-full border border-amber-200">
                Score: {readinessScore}%
              </span>
            </div>
            <p className="text-xs text-[#6B716A] mt-0.5">
              Programme: {studentProfile.programme} • State: {studentProfile.state}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => navigateTo('/student/receipt')}
            className="px-3 py-1.5 bg-[#F1E8D8] hover:bg-[#DED4C3] text-[#465047] text-xs font-semibold rounded-xl"
          >
            Preview Receipt
          </button>
          <button
            onClick={handleApproveMarksheet}
            className="px-4 py-2 bg-green-600 hover:bg-green-700 text-white font-bold rounded-xl text-xs shadow-xs transition-colors flex items-center gap-1.5"
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>Approve Class 12</span>
          </button>
        </div>
      </div>

      {/* Split Screen Scrutiny Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: Document Preview & OCR Discrepancy Breakdown */}
        <div className="lg:col-span-7 space-y-6">
          {/* Class 12 Document Inspection Card */}
          <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#EEE7DA]">
              <div className="flex items-center gap-2">
                <FileText className="w-5 h-5 text-[#2F7454]" />
                <h2 className="text-sm font-bold text-[#2E342F]">Class 12 Marksheet Scrutiny</h2>
              </div>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                  marksheetDoc?.status === 'Verified'
                    ? 'bg-green-100 text-green-800'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                Status: {marksheetDoc?.status}
              </span>
            </div>

            {/* OCR Comparison Table */}
            <div className="bg-[#FAF6ED] rounded-xl p-4 border border-[#DED4C3] space-y-3 text-xs">
              <div className="flex items-center justify-between font-bold text-[#374039]">
                <span>Field Comparison Matrix</span>
                <span className="text-[11px] text-[#245C43] font-semibold bg-[#EEF7F1] px-2 py-0.5 rounded">
                  Assistive OCR Confidence: 94%
                </span>
              </div>

              <div className="divide-y divide-slate-200">
                <div className="py-2 flex justify-between items-center">
                  <span className="text-[#6B716A] font-medium">Candidate Name</span>
                  <div className="text-right">
                    <span className="text-[#6B716A] line-through mr-2">Ananya Krishnan</span>
                    <strong className="text-amber-900 bg-amber-100/70 px-1.5 py-0.5 rounded">
                      Ananya Krishnan S
                    </strong>
                  </div>
                </div>

                <div className="py-2 flex justify-between items-center">
                  <span className="text-[#6B716A] font-medium">Register Number</span>
                  <span className="font-bold text-[#2E342F]">7281940</span>
                </div>

                <div className="py-2 flex justify-between items-center">
                  <span className="text-[#6B716A] font-medium">Date of Birth</span>
                  <span className="font-bold text-[#2E342F]">14/05/2008</span>
                </div>

                <div className="py-2 flex justify-between items-center">
                  <span className="text-[#6B716A] font-medium">Total Marks &amp; %</span>
                  <span className="font-bold text-[#2E342F]">564/600 (94.0%)</span>
                </div>

                <div className="py-2 flex justify-between items-center">
                  <span className="text-[#6B716A] font-medium">Institution</span>
                  <span className="font-bold text-[#2E342F]">Adarsh Matric Higher Sec School</span>
                </div>
              </div>

              <div className="p-2.5 bg-amber-50 text-amber-900 rounded-lg border border-amber-200 text-[11px]">
                <strong>AI Assistive Warning:</strong> Initial "S" represents patronymic Subramanian as corroborated in Aadhaar card. Low probability of candidate substitution.
              </div>
            </div>

            {/* Document Trust Check Details */}
            <div className="p-4 bg-[#FAF6ED] rounded-xl border border-[#DED4C3] space-y-2 text-xs">
              <div className="flex items-center justify-between font-bold text-[#374039]">
                <div className="flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-[#2F7454]" />
                  <span>Document Trust Check Analysis</span>
                </div>
                <span className="text-[10px] uppercase font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full">
                  Medium Risk
                </span>
              </div>
              <ul className="list-disc pl-4 text-[#596159] text-[11px] space-y-0.5">
                <li>No pixel splicing or font alterations detected.</li>
                <li>Hologram seal and state board emblem contours verified.</li>
                <li>Recommended action: Accept with candidate declaration or officer sign-off.</li>
              </ul>
            </div>
          </div>

          {/* Identity Check Scrutiny Card */}
          <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[#EEE7DA]">
              <div className="flex items-center gap-2">
                <ScanFace className="w-5 h-5 text-[#2F7454]" />
                <h2 className="text-sm font-bold text-[#2E342F]">Identity &amp; Liveness Assessment</h2>
              </div>
              <span
                className={`text-xs font-bold px-2 py-0.5 rounded-full ${
                  identityCheck.status === 'passed'
                    ? 'bg-green-100 text-green-800'
                    : 'bg-amber-100 text-amber-800'
                }`}
              >
                {identityCheck.status === 'passed' ? 'Passed / Signed-off' : 'Review Required (68%)'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-3 text-xs">
              <div className="p-3 bg-[#FAF6ED] rounded-xl border border-[#DED4C3]">
                <span className="text-[#6B716A] font-medium">Liveness Presence</span>
                <p className="font-bold text-green-700 mt-1 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Passed (Timestamped)
                </p>
              </div>

              <div className="p-3 bg-[#FAF6ED] rounded-xl border border-[#DED4C3]">
                <span className="text-[#6B716A] font-medium">Face Match Confidence</span>
                <p className="font-bold text-amber-800 mt-1">
                  {identityCheck.confidence}% (Inconclusive)
                </p>
              </div>
            </div>

            <p className="text-xs text-[#596159] leading-relaxed">
              Reason: {identityCheck.reason}
            </p>

            <div className="flex items-center gap-2 pt-2">
              <button
                type="button"
                onClick={handleOverrideIdentity}
                className="px-3.5 py-2 bg-[#2F7454] hover:bg-[#245C43] text-white font-bold rounded-xl text-xs shadow-xs transition-colors flex items-center gap-1.5"
              >
                <UserCheck className="w-3.5 h-3.5" />
                <span>Officer Override (Confirm Identity)</span>
              </button>
              <button
                type="button"
                onClick={handleRequestInPerson}
                className="px-3 py-2 bg-[#F1E8D8] hover:bg-[#DED4C3] text-[#465047] font-semibold rounded-xl text-xs"
              >
                Flag for In-Person Check
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Officer Decision Panel */}
        <div className="lg:col-span-5 space-y-6">
          <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-xs space-y-4">
            <h3 className="text-sm font-bold text-[#2E342F] pb-2 border-b border-[#EEE7DA]">
              Officer Determination &amp; Sign-Off
            </h3>

            <div>
              <label className="text-xs font-bold text-[#465047] block">
                Class 12 Decision Status:
              </label>
              <select
                value={docStatus}
                onChange={(e) => setDocStatus(e.target.value as any)}
                className="w-full mt-1 px-3 py-2 bg-[#FAF6ED] border border-[#CEC4B3] rounded-xl text-xs font-semibold text-[#374039]"
              >
                <option value="Verified">Verified (Approved)</option>
                <option value="Needs correction">Needs correction (Discrepancy)</option>
                <option value="Pending">Under review</option>
                <option value="Rejected">Rejected</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-[#465047] block">
                Verification Ledger Notes:
              </label>
              <textarea
                rows={4}
                value={officerNotes}
                onChange={(e) => setOfficerNotes(e.target.value)}
                placeholder="Enter audit notes for state compliance log..."
                className="w-full mt-1 p-3 text-xs bg-[#FAF6ED] border border-[#CEC4B3] rounded-xl text-[#374039] focus:outline-none focus:border-[#4F936E]"
              />
            </div>

            <button
              type="button"
              disabled={isSubmitting}
              onClick={() => {
                setIsSubmitting(true);
                setTimeout(() => {
                  adminVerifyDocument('doc-12th', docStatus, officerNotes);
                  setIsSubmitting(false);
                  addToast('Officer determination updated successfully.', 'success');
                }, 500);
              }}
              className="w-full py-2.5 bg-[#2F7454] hover:bg-[#245C43] text-white font-bold rounded-xl text-xs shadow-xs transition-colors flex items-center justify-center gap-2"
            >
              <Save className="w-4 h-4" />
              <span>{isSubmitting ? 'Saving...' : 'Save & Publish Determination'}</span>
            </button>
          </div>

          {/* Audit History Ledger */}
          <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-xs space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-[#EEE7DA] text-[#2E342F] font-bold text-xs">
              <Clock className="w-4 h-4 text-[#6B716A]" />
              <span>Audit Trail (Application CP-2026-1048)</span>
            </div>

            <div className="space-y-2 text-xs">
              {verificationAuditLogs.slice(0, 4).map((log) => (
                <div key={log.id} className="p-2.5 bg-[#FAF6ED] rounded-lg border border-[#EEE7DA]">
                  <div className="flex justify-between items-center text-[11px]">
                    <strong className="text-[#374039]">{log.action}</strong>
                    <span className="text-[#858B84] font-mono">{log.timestamp}</span>
                  </div>
                  <p className="text-[11px] text-[#596159] mt-1">{log.notes}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
