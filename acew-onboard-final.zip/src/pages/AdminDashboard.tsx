import React, { useState } from 'react';
import {
  Users,
  CheckCircle2,
  AlertTriangle,
  Clock,
  ShieldCheck,
  Search,
  Filter,
  ArrowRight,
  UserCheck,
  FileText,
  ScanFace,
  ChevronRight,
  LifeBuoy,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageOnboardingBanner, OnboardingStep } from '../components/PageOnboardingBanner';

const ADMIN_DASHBOARD_STEPS: OnboardingStep[] = [
  {
    title: 'Review Applications',
    desc: 'Open an application to review it.',
    icon: Users,
  },
  {
    title: 'Check Progress',
    desc: 'Check current application progress.',
    icon: ShieldCheck,
  },
  {
    title: 'Open Applicant Details',
    desc: 'Select an applicant to view details.',
    icon: ArrowRight,
  },
];

export const AdminDashboard: React.FC = () => {
  const { navigateTo, documents, identityCheck, supportTickets } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'needs_action' | 'verified'>('all');
  const [searchQuery, setSearchQuery] = useState('');

  const applications = [
    {
      id: 'CP-2026-1048',
      name: 'Ananya Krishnan',
      programme: 'B.Tech Computer Science and Engineering',
      score: 72,
      docStatus: '1 Action Required',
      identityStatus: 'Review Required (68%)',
      risk: 'Medium',
      submittedAt: '14 Sep, 09:30 AM',
      isDemoTarget: true,
    },
    {
      id: 'CP-2026-1049',
      name: 'R. Vignesh Kumar',
      programme: 'B.Tech Mechanical Engineering',
      score: 95,
      docStatus: 'All Verified',
      identityStatus: 'Passed (94%)',
      risk: 'Low',
      submittedAt: '14 Sep, 11:20 AM',
    },
    {
      id: 'CP-2026-1050',
      name: 'S. Meenakshi',
      programme: 'B.Tech Electronics & Communication',
      score: 48,
      docStatus: '2 Pending Upload',
      identityStatus: 'Not Started',
      risk: 'High',
      submittedAt: '15 Sep, 08:15 AM',
    },
    {
      id: 'CP-2026-1051',
      name: 'G. Karthik',
      programme: 'B.Tech Artificial Intelligence & Data Science',
      score: 100,
      docStatus: 'All Verified',
      identityStatus: 'Passed (98%)',
      risk: 'Low',
      submittedAt: '13 Sep, 04:45 PM',
    },
  ];

  const filteredApps = applications.filter((app) => {
    if (activeTab === 'needs_action' && app.risk === 'Low') return false;
    if (activeTab === 'verified' && app.score < 100) return false;
    if (searchQuery.trim()) {
      return (
        app.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        app.id.toLowerCase().includes(searchQuery.toLowerCase())
      );
    }
    return true;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Page-Specific Onboarding Banner */}
      <PageOnboardingBanner
        pageKey="admin_dashboard"
        pageTitle="Admission Officer Review Hub"
        uniqueFocus="Managing the university triage queue, applicant risk scoring, and queue-wide metrics without individual applicant editing."
        description="Monitor verified vs pending applicant quotas, triage discrepancies, and manage officer workload across faculties."
        steps={ADMIN_DASHBOARD_STEPS}
      />

      {/* Top Officer Header */}
      <div className="p-6 bg-gradient-to-r from-[#153B2E] to-slate-900 text-white rounded-2xl shadow-sm border border-[#25392F] flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-6 h-6 text-[#7DB392]" />
            <h1 className="text-xl sm:text-2xl font-extrabold tracking-tight">
              Admission Officer Workstation
            </h1>
          </div>
          <p className="text-xs text-[#B4B9B2] mt-1">
            Logged in as <strong className="text-white">Dr. M. Sundaram</strong> • Verification Desk 1 • Academic Year 2026-27
          </p>
        </div>

        <button
          onClick={() => navigateTo('/admin/rules')}
          className="px-4 py-2 bg-[#2F7454] hover:bg-[#1C4937] text-white font-bold rounded-xl text-xs shadow-xs transition-colors self-start sm:self-auto"
        >
          Manage Admission Rules &amp; Quotas
        </button>
      </div>

      {/* Metrics Row */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-2xs space-y-1">
          <span className="text-xs font-semibold text-[#6B716A]">Total Applications</span>
          <p className="text-2xl font-black text-[#2E342F]">1,248</p>
          <span className="text-[11px] text-[#2F7454] font-medium">+42 received today</span>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-2xs space-y-1">
          <span className="text-xs font-semibold text-[#6B716A]">Fully Verified</span>
          <p className="text-2xl font-black text-green-700">892</p>
          <span className="text-[11px] text-[#6B716A] font-medium">71.4% enrollment rate</span>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-2xs space-y-1">
          <span className="text-xs font-semibold text-[#6B716A]">Requires Officer Review</span>
          <p className="text-2xl font-black text-amber-600">108</p>
          <span className="text-[11px] text-amber-700 font-medium">Includes 1 demo target</span>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-2xs space-y-1">
          <span className="text-xs font-semibold text-[#6B716A]">Avg. Verification Turnaround</span>
          <p className="text-2xl font-black text-[#2E342F]">4.2 hrs</p>
          <span className="text-[11px] text-[#6B716A] font-medium">Compliant with state SLA</span>
        </div>
      </div>

      {/* Applications Review Queue Table */}
      <div className="bg-white rounded-2xl border border-[#DED4C3] shadow-xs overflow-hidden">
        <div className="p-5 border-b border-[#DED4C3] flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-sm font-bold text-[#2E342F]">Applicant Scrutiny Queue</h2>
            <p className="text-xs text-[#6B716A]">
              Select candidate to review OCR extracted fields and identity screening results.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-[#858B84] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search candidate name or ID..."
                className="pl-8 pr-3 py-1.5 text-xs bg-[#FAF6ED] border border-[#CEC4B3] rounded-lg focus:outline-none focus:border-[#4F936E]"
              />
            </div>

            <div className="flex bg-[#F1E8D8] p-0.5 rounded-lg text-xs font-bold">
              <button
                onClick={() => setActiveTab('all')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  activeTab === 'all' ? 'bg-white text-[#2E342F] shadow-2xs' : 'text-[#6B716A]'
                }`}
              >
                All
              </button>
              <button
                onClick={() => setActiveTab('needs_action')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  activeTab === 'needs_action' ? 'bg-white text-amber-700 shadow-2xs' : 'text-[#6B716A]'
                }`}
              >
                Review Required
              </button>
              <button
                onClick={() => setActiveTab('verified')}
                className={`px-2.5 py-1 rounded-md transition-colors ${
                  activeTab === 'verified' ? 'bg-white text-green-700 shadow-2xs' : 'text-[#6B716A]'
                }`}
              >
                Verified
              </button>
            </div>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead className="bg-[#FAF6ED] text-[#596159] font-bold border-b border-[#DED4C3]">
              <tr>
                <th className="p-3.5">Candidate &amp; ID</th>
                <th className="p-3.5">Degree Programme</th>
                <th className="p-3.5">ACEW Readiness</th>
                <th className="p-3.5">Document Status</th>
                <th className="p-3.5">Identity Screening</th>
                <th className="p-3.5">Trust Risk</th>
                <th className="p-3.5 text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredApps.map((app) => (
                <tr
                  key={app.id}
                  className={`hover:bg-[#FAF6ED] transition-colors ${
                    app.isDemoTarget ? 'bg-amber-50/30' : ''
                  }`}
                >
                  <td className="p-3.5">
                    <div className="font-bold text-[#2E342F] flex items-center gap-1.5">
                      <span>{app.name}</span>
                      {app.isDemoTarget && (
                        <span className="text-[10px] bg-[#DDEFE4] text-[#1C4937] font-extrabold px-1.5 py-0.2 rounded">
                          Current Demo
                        </span>
                      )}
                    </div>
                    <span className="text-[11px] font-mono text-[#6B716A]">{app.id}</span>
                  </td>

                  <td className="p-3.5 text-[#596159] max-w-[200px] truncate">{app.programme}</td>

                  <td className="p-3.5">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-[#2E342F]">{app.score}%</span>
                      <div className="w-16 h-1.5 bg-[#DED4C3] rounded-full overflow-hidden">
                        <div
                          className="h-full bg-[#2F7454]"
                          style={{ width: `${app.score}%` }}
                        ></div>
                      </div>
                    </div>
                  </td>

                  <td className="p-3.5">
                    <span
                      className={`text-[11px] font-semibold ${
                        app.docStatus.includes('Action') ? 'text-amber-700' : 'text-[#465047]'
                      }`}
                    >
                      {app.docStatus}
                    </span>
                  </td>

                  <td className="p-3.5">
                    <span
                      className={`text-[11px] font-semibold ${
                        app.identityStatus.includes('Review')
                          ? 'text-amber-700 font-bold'
                          : 'text-[#465047]'
                      }`}
                    >
                      {app.identityStatus}
                    </span>
                  </td>

                  <td className="p-3.5">
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded-full ${
                        app.risk === 'Low'
                          ? 'bg-green-100 text-green-800'
                          : app.risk === 'Medium'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-red-100 text-red-800'
                      }`}
                    >
                      {app.risk} Risk
                    </span>
                  </td>

                  <td className="p-3.5 text-right">
                    <button
                      onClick={() => navigateTo(`/admin/applications/${app.id}`)}
                      className="px-3 py-1.5 bg-[#1D2D26] hover:bg-[#26382F] text-white font-bold rounded-lg text-xs shadow-2xs transition-colors inline-flex items-center gap-1"
                    >
                      <span>Review</span>
                      <ChevronRight className="w-3 h-3" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Support & Dispute Requests Queue */}
      <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-xs space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[#EEE7DA]">
          <div className="flex items-center gap-2">
            <LifeBuoy className="w-5 h-5 text-[#2F7454]" />
            <h3 className="text-sm font-bold text-[#2E342F]">
              Candidate Support &amp; Dispute Escalations
            </h3>
          </div>
          <span className="text-xs font-bold text-[#6B716A]">
            {supportTickets.length} active tickets
          </span>
        </div>

        <div className="space-y-2">
          {supportTickets.map((t) => (
            <div
              key={t.id}
              className="p-3 bg-[#FAF6ED] rounded-xl border border-[#DED4C3] flex items-center justify-between text-xs"
            >
              <div>
                <span className="font-bold text-[#2E342F]">
                  {t.studentName} ({t.studentId})
                </span>
                <span className="text-[11px] text-[#6B716A] ml-2 font-mono">• {t.id}</span>
                <p className="text-[11px] text-[#596159] mt-0.5">{t.message}</p>
              </div>

              <div className="flex items-center gap-2">
                <span className="text-[10px] font-bold text-amber-800 bg-amber-100 px-2 py-0.5 rounded-full">
                  {t.status}
                </span>
                <button
                  onClick={() => navigateTo('/admin/applications/CP-2026-1048')}
                  className="px-2.5 py-1 bg-[#2F7454] text-white font-semibold rounded-lg text-xs hover:bg-[#245C43]"
                >
                  View File
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
