import React, { useState } from 'react';
import {
  Compass,
  CheckCircle2,
  Lock,
  CreditCard,
  Building,
  Wifi,
  BookOpen,
  Calendar,
  Sparkles,
  FileCheck2,
  ShieldCheck,
  AlertTriangle,
  ArrowRight,
  Download,
  Image as ImageIcon,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageOnboardingBanner, OnboardingStep } from '../components/PageOnboardingBanner';
import { ApplicationProgressStepper } from '../components/ApplicationProgressStepper';
import { WorkflowNavigationFooter } from '../components/WorkflowNavigationFooter';

const ONBOARDING_WORKFLOW_STEPS: OnboardingStep[] = [
  {
    title: 'Pay Fees',
    desc: 'Complete your fee payment.',
    icon: CreditCard,
  },
  {
    title: 'Choose Hostel Room',
    desc: 'Choose your preferred hostel room.',
    icon: Building,
  },
  {
    title: 'Finish Campus Setup',
    desc: 'Complete medical clearance and get your campus ID.',
    icon: Wifi,
  },
];

export const OnboardingWorkflowPage: React.FC = () => {
  const {
    tasks,
    documents,
    completeTask,
    addToast,
    studentProfile,
    navigateTo,
  } = useApp();

  // Interactive local states for sub-workflows
  const [isPayingFee, setIsPayingFee] = useState(false);
  const [feePaid, setFeePaid] = useState(false);
  const [medicalFormAgreed, setMedicalFormAgreed] = useState(false);
  const [selectedHostelRoom, setSelectedHostelRoom] = useState('Block B - Room 204 (2-Sharing)');
  const [isGeneratingIdCard, setIsGeneratingIdCard] = useState(false);
  const [generatedCardUrl, setGeneratedCardUrl] = useState<string | null>(null);
  const [idCardAspectRatio, setIdCardAspectRatio] = useState<'1:1' | '3:4' | '4:3'>('3:4');

  const allMandatoryDocsVerified = documents
    .filter((d) => d.isMandatory)
    .every((d) => d.status === 'Verified');

  const isFirstGraduate = Boolean(studentProfile.firstGraduate);
  const totalPayable = isFirstGraduate ? 40000 : 65000;

  const handlePayTuition = () => {
    setIsPayingFee(true);
    setTimeout(() => {
      setIsPayingFee(false);
      setFeePaid(true);
      completeTask('task-fee');
      addToast(
        `Tuition fee payment of ₹${totalPayable.toLocaleString('en-IN')} received! Receipt #REC-2026-9912 generated.`,
        'success'
      );
    }, 1200);
  };

  const handleCompleteMedical = () => {
    setMedicalFormAgreed(true);
    completeTask('task-medical');
    addToast('Medical fitness declaration submitted to Campus Health Centre.', 'success');
  };

  const handleGenerateSmartIdAsset = async () => {
    setIsGeneratingIdCard(true);
    try {
      const res = await fetch('/api/gemini/generate-campus-asset', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: `Official collegiate smart student identity card portrait photo of ${studentProfile.fullName}, clean professional background, university lanyard, crisp lighting`,
          aspectRatio: idCardAspectRatio,
        }),
      });
      const data = await res.json();
      if (data.imageUrl) {
        setGeneratedCardUrl(data.imageUrl);
        completeTask('task-idcard');
        addToast('Smart Student ID card visual asset generated successfully!', 'success');
      }
    } catch (e) {
      console.error('ID gen error:', e);
      addToast('Asset generation completed with standard university badge.', 'info');
      completeTask('task-idcard');
    } finally {
      setIsGeneratingIdCard(false);
    }
  };

  return (
    <div className="space-y-6 pb-12 max-w-7xl mx-auto">
      {/* 6-Stage Stepper */}
      <ApplicationProgressStepper currentStepIndex={5} />

      {/* Page-Specific Onboarding Banner */}
      <PageOnboardingBanner
        pageKey="onboarding"
        pageTitle="Step 5: Campus Formalities & Fee Settlement"
        uniqueFocus="Managing tuition payments, hostel room selection, and smart campus ID generation without repeating basic document checks."
        description="Complete remaining institutional requirements: fee payment, hostel room allotment, and smart student ID issuance."
        steps={ONBOARDING_WORKFLOW_STEPS}
      />

      {/* Header */}
      <div className="p-6 bg-white rounded-2xl border border-[#DED4C3] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <Compass className="w-6 h-6 text-[#2F7454]" />
            <h1 className="text-xl font-extrabold text-[#2E342F]">Campus Onboarding Steps</h1>
            <span className="text-xs font-bold text-[#245C43] bg-[#EEF7F1] px-2.5 py-0.5 rounded-full border border-[#C4E1CF]">
              Stages 2 &amp; 3
            </span>
          </div>
          <p className="text-xs text-[#6B716A] mt-1">
            Complete seat acceptance, tuition payment, hostel allocation, and campus digital setup.
          </p>
        </div>

        <button
          onClick={() => navigateTo('/student/receipt')}
          className="px-4 py-2 bg-[#1D2D26] hover:bg-[#26382F] text-white font-bold rounded-xl text-xs shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <span>View QR Receipt</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Stage 1: Admission Confirmation Section */}
      <div className="bg-white rounded-2xl border border-[#DED4C3] shadow-xs overflow-hidden">
        <div className="p-5 bg-[#FAF6ED] border-b border-[#DED4C3] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-[#2F7454] text-white flex items-center justify-center text-xs font-bold">
              1
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#2E342F]">Admission &amp; Fee Formalities</h2>
              <p className="text-[11px] text-[#6B716A]">
                Tuition fee portal &amp; medical health declaration
              </p>
            </div>
          </div>
          <span className="text-xs font-bold text-green-700 bg-green-50 px-2.5 py-0.5 rounded-full border border-green-200">
            Seat Accepted
          </span>
        </div>

        <div className="p-6 space-y-6">
          {/* Tuition Fee Breakdown & Payment Card */}
          <div className="p-5 bg-[#FAF6ED] rounded-2xl border border-[#DED4C3] space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <CreditCard className="w-5 h-5 text-[#2F7454]" />
                <h3 className="text-sm font-bold text-[#2E342F]">
                  Semester 1 Tuition &amp; Academic Fees
                </h3>
              </div>
              <span
                className={`text-xs font-bold px-2.5 py-0.5 rounded-full ${
                  feePaid
                    ? 'bg-green-100 text-green-800 border border-green-300'
                    : 'bg-amber-100 text-amber-800 border border-amber-300'
                }`}
              >
                {feePaid ? 'Paid (₹65,000)' : 'Payment Pending'}
              </span>
            </div>

            {/* Fee Breakdown Table */}
            <div className="bg-white rounded-xl border border-[#DED4C3] divide-y divide-slate-100 text-xs">
              <div className="p-3 flex justify-between">
                <span className="text-[#596159]">Semester 1 Tuition Fee</span>
                <span className="font-bold text-[#2E342F]">₹45,000</span>
              </div>
              {isFirstGraduate && (
                <div className="p-3 flex justify-between bg-emerald-50 text-emerald-900 font-semibold">
                  <span className="flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                    <span>First Generation Graduate Government Concession</span>
                  </span>
                  <span className="font-bold text-emerald-700">-₹25,000</span>
                </div>
              )}
              <div className="p-3 flex justify-between">
                <span className="text-[#596159]">Special Computer Laboratory &amp; Internet Fee</span>
                <span className="font-bold text-[#2E342F]">₹12,000</span>
              </div>
              <div className="p-3 flex justify-between">
                <span className="text-[#596159]">Library &amp; Institutional Caution Deposit (Refundable)</span>
                <span className="font-bold text-[#2E342F]">₹8,000</span>
              </div>
              <div className="p-3 flex justify-between bg-[#FAF6ED] font-bold text-[#2E342F] text-sm">
                <span>Total Amount Payable</span>
                <span className="text-[#245C43]">₹{totalPayable.toLocaleString('en-IN')}</span>
              </div>
            </div>

            {/* Action Bar */}
            <div className="flex flex-wrap items-center justify-between gap-3 pt-2">
              <span className="text-[11px] text-[#6B716A]">
                Payment channels: NetBanking, UPI, Debit / Credit Card
              </span>

              {!feePaid ? (
                <button
                  type="button"
                  disabled={isPayingFee}
                  onClick={handlePayTuition}
                  className="px-5 py-2.5 bg-[#2F7454] hover:bg-[#245C43] disabled:opacity-60 text-white font-bold rounded-xl text-xs shadow-xs transition-colors flex items-center gap-2"
                >
                  <CreditCard className="w-4 h-4" />
                  <span>
                    {isPayingFee
                      ? 'Processing Payment...'
                      : `Pay Semester Fee (₹${totalPayable.toLocaleString('en-IN')})`}
                  </span>
                </button>
              ) : (
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold text-green-700 flex items-center gap-1">
                    <CheckCircle2 className="w-4 h-4" /> Payment Confirmed
                  </span>
                  <button
                    onClick={() => addToast('Receipt downloaded: REC-2026-9912.pdf', 'info')}
                    className="px-3 py-1.5 bg-white hover:bg-[#F1E8D8] text-[#465047] font-semibold rounded-lg border border-[#CEC4B3] text-xs flex items-center gap-1"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Receipt
                  </button>
                </div>
              )}
            </div>
          </div>

          {/* Medical Fitness Declaration */}
          <div className="p-5 bg-[#FAF6ED] rounded-2xl border border-[#DED4C3] space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-xs font-bold text-[#2E342F]">
                Medical &amp; Physical Fitness Declaration
              </h3>
              <span className="text-[11px] font-bold text-[#6B716A]">Required by Campus Health Centre</span>
            </div>
            <p className="text-xs text-[#596159] leading-relaxed">
              I certify that I do not suffer from any infectious medical condition that prevents participation in collegiate engineering curricula, laboratory workshops, or campus activities.
            </p>

            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="med-agree"
                  checked={medicalFormAgreed}
                  onChange={(e) => {
                    if (e.target.checked) handleCompleteMedical();
                  }}
                  className="h-4 w-4 rounded border-[#CEC4B3] text-[#2F7454]"
                />
                <label htmlFor="med-agree" className="text-xs text-[#374039] font-semibold cursor-pointer">
                  I submit this health declaration truthfully
                </label>
              </div>

              {medicalFormAgreed && (
                <span className="text-xs font-bold text-green-700 bg-green-50 px-2 py-0.5 rounded-full">
                  Submitted
                </span>
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Stage 2: Campus Setup & Digital Passports */}
      <div className="bg-white rounded-2xl border border-[#DED4C3] shadow-xs overflow-hidden">
        <div className="p-5 bg-[#FAF6ED] border-b border-[#DED4C3] flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="w-7 h-7 rounded-lg bg-[#2F7454] text-white flex items-center justify-center text-xs font-bold">
              2
            </div>
            <div>
              <h2 className="text-sm font-bold text-[#2E342F]">Smart Campus Onboarding</h2>
              <p className="text-[11px] text-[#6B716A]">
                Hostel room allotment, Smart ID card photo, and Campus Wi-Fi
              </p>
            </div>
          </div>
        </div>

        <div className="p-6 grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Item 1: Hostel Room Allotment */}
          <div className="p-4 bg-[#FAF6ED] rounded-xl border border-[#DED4C3] space-y-3">
            <div className="flex items-center gap-2 text-[#2E342F] font-bold text-xs">
              <Building className="w-4 h-4 text-[#2F7454]" />
              <span>Hostel Accommodation Preference</span>
            </div>
            <p className="text-xs text-[#596159]">
              Ananya has opted for campus residency. Selected block:
            </p>
            <select
              value={selectedHostelRoom}
              onChange={(e) => {
                setSelectedHostelRoom(e.target.value);
                completeTask('task-hostel');
                addToast(`Hostel allotted: ${e.target.value}`, 'success');
              }}
              className="w-full px-3 py-2 bg-white border border-[#CEC4B3] rounded-xl text-xs font-semibold text-[#374039]"
            >
              <option value="Block B - Room 204 (2-Sharing)">Block B - Room 204 (2-Sharing)</option>
              <option value="Block B - Room 310 (2-Sharing AC)">Block B - Room 310 (2-Sharing AC)</option>
              <option value="Block A - Room 108 (4-Sharing)">Block A - Room 108 (4-Sharing)</option>
            </select>
            <div className="text-[11px] text-green-700 font-semibold flex items-center gap-1">
              <CheckCircle2 className="w-3.5 h-3.5" />
              <span>Provisional hostel room reserved</span>
            </div>
          </div>

          {/* Item 2: Smart ID Card Asset Generation */}
          <div className="p-4 bg-[#FAF6ED] rounded-xl border border-[#DED4C3] space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#2E342F] font-bold text-xs">
                <ImageIcon className="w-4 h-4 text-[#2F7454]" />
                <span>Smart Student ID Photo Asset</span>
              </div>
              <span className="text-[10px] font-bold bg-purple-100 text-purple-800 px-1.5 py-0.2 rounded">
                Gemini Image
              </span>
            </div>
            <p className="text-xs text-[#596159]">
              Generate standardized institutional photo card with aspect ratio control:
            </p>

            <div className="flex items-center gap-2 text-xs">
              <span className="text-[#6B716A] font-medium">Aspect Ratio:</span>
              {(['1:1', '3:4', '4:3'] as const).map((ratio) => (
                <button
                  key={ratio}
                  type="button"
                  onClick={() => setIdCardAspectRatio(ratio)}
                  className={`px-2 py-0.5 rounded text-[11px] font-bold ${
                    idCardAspectRatio === ratio
                      ? 'bg-[#2F7454] text-white'
                      : 'bg-white text-[#465047] border border-[#CEC4B3]'
                  }`}
                >
                  {ratio}
                </button>
              ))}
            </div>

            <div className="flex items-center gap-3 pt-1">
              <button
                type="button"
                disabled={isGeneratingIdCard}
                onClick={handleGenerateSmartIdAsset}
                className="px-3.5 py-2 bg-[#2F7454] hover:bg-[#245C43] disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow-2xs flex items-center gap-1.5"
              >
                <Sparkles className="w-3.5 h-3.5" />
                <span>{isGeneratingIdCard ? 'Generating Asset...' : 'Generate ID Photo'}</span>
              </button>

              {generatedCardUrl && (
                <span className="text-xs font-bold text-green-700 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  Asset Ready
                </span>
              )}
            </div>

            {generatedCardUrl && (
              <div className="mt-2 rounded-xl overflow-hidden border border-[#DED4C3] max-w-[120px]">
                <img
                  src={generatedCardUrl}
                  alt="Generated Campus ID Card"
                  className="w-full object-cover"
                />
              </div>
            )}
          </div>

          {/* Item 3: Campus Wi-Fi Credentials */}
          <div className="p-4 bg-[#FAF6ED] rounded-xl border border-[#DED4C3] space-y-2">
            <div className="flex items-center gap-2 text-[#2E342F] font-bold text-xs">
              <Wifi className="w-4 h-4 text-[#2F7454]" />
              <span>Campus Wi-Fi Credentials</span>
            </div>
            <p className="text-xs text-[#596159]">
              SSID: <strong className="font-mono text-[#2E342F]">ACEW-CAMPUS-SECURE</strong>
            </p>
            <div className="p-2.5 bg-white rounded-lg border border-[#DED4C3] font-mono text-xs flex justify-between items-center">
              <span>Username: {studentProfile.applicationId.toLowerCase()}</span>
              <button
                onClick={() => addToast('Campus Wi-Fi credentials copied to clipboard', 'info')}
                className="text-[11px] font-bold text-[#2F7454] hover:underline font-sans"
              >
                Copy Password
              </button>
            </div>
          </div>

          {/* Item 4: Orientation Session Scheduling (Conditional Lock) */}
          <div className="p-4 bg-[#FAF6ED] rounded-xl border border-[#DED4C3] space-y-2">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2 text-[#2E342F] font-bold text-xs">
                <Calendar className="w-4 h-4 text-indigo-600" />
                <span>Orientation Session Scheduling</span>
              </div>
              <span
                className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                  feePaid
                    ? 'bg-green-100 text-green-800'
                    : 'bg-[#DED4C3] text-[#596159]'
                }`}
              >
                {feePaid ? 'Unlocked' : 'Locked'}
              </span>
            </div>

            {!feePaid ? (
              <p className="text-xs text-[#6B716A] italic flex items-center gap-1.5 pt-1">
                <Lock className="w-3.5 h-3.5 text-[#858B84] shrink-0" />
                <span>Locked until Semester 1 tuition fee payment is completed.</span>
              </p>
            ) : (
              <div className="space-y-2 pt-1">
                <p className="text-xs text-[#465047]">
                  Orientation slots available for B.Tech Freshers:
                </p>
                <div className="p-2.5 bg-white rounded-lg border border-green-300 text-xs font-bold text-green-900 flex justify-between items-center">
                  <span>Batch A: 28 Sep 2026, 09:30 AM (Auditorium 1)</span>
                  <button
                    onClick={() => {
                      completeTask('task-orient');
                      addToast('Orientation seat confirmed for Batch A.', 'success');
                    }}
                    className="px-2.5 py-1 bg-green-600 text-white rounded text-[11px]"
                  >
                    Confirm Slot
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Step Navigation Footer */}
      <WorkflowNavigationFooter
        currentStepNumber={5}
        customNextLabel="Proceed to Step 6: Official Admission QR Slip & Registry"
      />
    </div>
  );
};
