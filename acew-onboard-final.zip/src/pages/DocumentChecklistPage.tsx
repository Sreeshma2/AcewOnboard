import React, { useState } from 'react';
import {
  FileCheck,
  FileText,
  Upload,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Filter,
  Eye,
  AlertCircle,
  HelpCircle,
  Sparkles,
  BookOpen,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { DocumentUploadModal } from '../components/DocumentUploadModal';
import { DocumentTrustBadge } from '../components/DocumentTrustBadge';
import { DocumentItem } from '../types';
import { PageOnboardingBanner, OnboardingStep } from '../components/PageOnboardingBanner';
import { ApplicationProgressStepper } from '../components/ApplicationProgressStepper';
import { WorkflowNavigationFooter } from '../components/WorkflowNavigationFooter';

const DOCUMENT_STEPS: OnboardingStep[] = [
  {
    title: 'Check Documents',
    desc: 'Check which documents you need to upload.',
    icon: FileCheck,
  },
  {
    title: 'Upload Documents',
    desc: 'Upload clear documents for quick checking.',
    icon: Sparkles,
  },
  {
    title: 'Fix A Document',
    desc: 'Upload a new file when correction is needed.',
    icon: Upload,
  },
];

export const DocumentChecklistPage: React.FC = () => {
  const { documents, navigateTo, setInstructionGuideOpen, quickVerifyAllDocs } = useApp();

  const [activeFilter, setActiveFilter] = useState<'all' | 'required' | 'action' | 'verified' | 'pending'>('all');
  const [selectedDocForUpload, setSelectedDocForUpload] = useState<{ id: string; name: string } | null>(null);

  const filteredDocs = documents.filter((doc) => {
    if (activeFilter === 'required') return doc.isMandatory;
    if (activeFilter === 'action') return doc.status === 'Needs correction';
    if (activeFilter === 'verified') return doc.status === 'Verified';
    if (activeFilter === 'pending') return doc.status === 'Pending' || doc.status === 'Uploaded' || doc.status === 'Review required';
    return true;
  });

  const verifiedCount = documents.filter((d) => d.status === 'Verified').length;
  const actionCount = documents.filter((d) => d.status === 'Needs correction').length;
  const pendingCount = documents.filter(
    (d) => d.status === 'Pending' || d.status === 'Uploaded' || d.status === 'Review required'
  ).length;

  return (
    <div className="space-y-6 pb-12 max-w-7xl mx-auto">
      {/* 6-Stage Stepper */}
      <ApplicationProgressStepper currentStepIndex={2} />

      {/* Page-Specific Onboarding Banner */}
      <PageOnboardingBanner
        pageKey="documents"
        pageTitle="Step 2: Document Checklist & Scans"
        uniqueFocus="Managing certificate uploads, automated OCR tamper/glare analysis, and correction uploads without repeating identity checks or fees."
        description="Review all required academic, reservation, and identification certificates. Upload high-clarity scans for automated pre-screening."
        steps={DOCUMENT_STEPS}
      />

      {/* Quick Action Bar for instant demoing/evaluating */}
      <div className="p-4 bg-gradient-to-r from-emerald-50 to-[#F1F8F3] rounded-2xl border border-emerald-200/80 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h4 className="text-xs font-bold text-emerald-950">Fast Verification &amp; Evaluation Testing</h4>
          <p className="text-[11px] text-emerald-700 mt-0.5">
            You can upload your own PDF/image files individually below, or use the quick action to verify all certificates at once.
          </p>
        </div>
        <button
          type="button"
          onClick={quickVerifyAllDocs}
          className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-colors shrink-0 flex items-center gap-1.5"
        >
          <Sparkles className="w-3.5 h-3.5" />
          <span>Quick-Upload &amp; Verify All (+30%)</span>
        </button>
      </div>

      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-6 bg-white rounded-2xl border border-[#DED4C3] shadow-xs">
        <div>
          <div className="flex items-center gap-2">
            <FileCheck className="w-6 h-6 text-[#2F7454]" />
            <h1 className="text-xl font-extrabold text-[#2E342F]">Document Checklist</h1>
            <span className="text-xs font-bold text-[#596159] bg-[#F1E8D8] px-2.5 py-0.5 rounded-full">
              B.Tech CSE Admission
            </span>
          </div>
          <p className="text-xs text-[#6B716A] mt-1">
            Personalized document requirements based on your qualifying examination and state quota.
          </p>
        </div>

        {/* Counts & Guide Button */}
        <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
          <button
            onClick={() => setInstructionGuideOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-[#EEF7F1] text-[#245C43] hover:bg-[#DDEFE4] rounded-lg border border-[#C4E1CF] transition-colors"
          >
            <BookOpen className="w-3.5 h-3.5 text-[#2F7454]" />
            <span>Process Instructions</span>
          </button>
          <span className="px-3 py-1.5 bg-green-50 text-green-700 rounded-lg border border-green-200">
            {verifiedCount} Verified
          </span>
          <span className="px-3 py-1.5 bg-amber-50 text-amber-700 rounded-lg border border-amber-200">
            {actionCount} Action Required
          </span>
          <span className="px-3 py-1.5 bg-[#F1E8D8] text-[#465047] rounded-lg border border-[#DED4C3]">
            {pendingCount} Pending
          </span>
        </div>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'all', label: `All Documents (${documents.length})` },
          { id: 'action', label: `Action Required (${actionCount})`, highlight: actionCount > 0 },
          { id: 'required', label: 'Mandatory Only' },
          { id: 'verified', label: `Verified (${verifiedCount})` },
          { id: 'pending', label: `Pending (${pendingCount})` },
        ].map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveFilter(tab.id as any)}
            className={`px-3.5 py-2 text-xs font-bold rounded-xl transition-all whitespace-nowrap ${
              activeFilter === tab.id
                ? 'bg-[#2F7454] text-white shadow-xs'
                : tab.highlight
                ? 'bg-amber-100 text-amber-800 hover:bg-amber-200 border border-amber-300'
                : 'bg-white text-[#596159] hover:bg-[#FAF6ED] border border-[#DED4C3]'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Documents Grid */}
      <div className="space-y-4">
        {filteredDocs.map((doc) => {
          const isVerified = doc.status === 'Verified';
          const isNeedsCorrection = doc.status === 'Needs correction';
          const isPending = doc.status === 'Pending';

          return (
            <div
              key={doc.id}
              className={`p-5 rounded-2xl border transition-all ${
                isNeedsCorrection
                  ? 'bg-red-50/20 border-red-200 shadow-xs'
                  : isVerified
                  ? 'bg-white border-[#DED4C3] hover:border-[#CEC4B3]'
                  : 'bg-white border-[#DED4C3]'
              }`}
            >
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                {/* Left info */}
                <div className="flex items-start gap-3 flex-1">
                  <div
                    className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                      isVerified
                        ? 'bg-green-100 text-green-700'
                        : isNeedsCorrection
                        ? 'bg-red-100 text-red-700'
                        : 'bg-[#F1E8D8] text-[#596159]'
                    }`}
                  >
                    <FileText className="w-5 h-5" />
                  </div>

                  <div className="space-y-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h3 className="text-sm font-bold text-[#2E342F]">{doc.name}</h3>
                      {doc.isMandatory ? (
                        <span className="text-[10px] font-bold uppercase tracking-wider text-red-700 bg-red-50 px-2 py-0.5 rounded-full border border-red-200">
                          Mandatory
                        </span>
                      ) : (
                        <span className="text-[10px] font-bold text-[#6B716A] bg-[#F1E8D8] px-2 py-0.5 rounded-full">
                          Optional
                        </span>
                      )}
                      <span
                        className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${
                          isVerified
                            ? 'bg-green-100 text-green-800'
                            : isNeedsCorrection
                            ? 'bg-red-100 text-red-800'
                            : isPending
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-[#F1E8D8] text-[#465047]'
                        }`}
                      >
                        {doc.status}
                      </span>
                    </div>

                    <p className="text-xs text-[#596159] leading-relaxed">
                      {doc.purpose || 'Official verification document required for institutional registration.'}
                    </p>

                    <div className="flex flex-wrap items-center gap-4 text-[11px] text-[#6B716A] pt-1">
                      <span>
                        Formats: <strong className="text-[#465047]">{(doc.acceptedFormats || ['PDF', 'JPG', 'PNG']).join(', ')}</strong>
                      </span>
                      <span>
                        Max size: <strong className="text-[#465047]">{doc.maxSizeMb || 5} MB</strong>
                      </span>
                      {doc.fileName && (
                        <span>
                          File: <strong className="text-[#465047] font-mono">{doc.fileName}</strong> ({doc.fileSize || '1.2 MB'})
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* Right Actions */}
                <div className="flex items-center gap-2 shrink-0">
                  {isNeedsCorrection && (
                    <button
                      onClick={() => navigateTo('/student/verification')}
                      className="px-4 py-2 bg-red-600 hover:bg-red-700 text-white font-bold rounded-xl text-xs shadow-xs transition-colors"
                    >
                      Resolve Mismatch
                    </button>
                  )}

                  <button
                    onClick={() => setSelectedDocForUpload({ id: doc.id, name: doc.name })}
                    className="px-3.5 py-2 bg-[#1D2D26] hover:bg-[#26382F] text-white font-semibold rounded-xl text-xs shadow-xs transition-colors flex items-center gap-1.5"
                  >
                    <Upload className="w-3.5 h-3.5" />
                    <span>{doc.fileName ? 'Replace File' : 'Upload Document'}</span>
                  </button>
                </div>
              </div>

              {/* Document Trust Badge Display */}
              {doc.trustCheck && (
                <div className="mt-4 pt-3 border-t border-[#EEE7DA]">
                  <DocumentTrustBadge trustCheck={doc.trustCheck} />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Upload Modal */}
      {selectedDocForUpload && (
        <DocumentUploadModal
          isOpen={true}
          docId={selectedDocForUpload.id}
          docName={selectedDocForUpload.name}
          onClose={() => setSelectedDocForUpload(null)}
        />
      )}

      {/* Step Navigation Footer */}
      <WorkflowNavigationFooter
        currentStepNumber={2}
        customNextLabel="Proceed to Step 3: Identity & Presence Check"
      />
    </div>
  );
};
