import React, { useState } from 'react';
import {
  ScanFace,
  ShieldCheck,
  AlertTriangle,
  Camera,
  CheckCircle2,
  RefreshCw,
  UserCheck,
  Lock,
  Eye,
  Info,
  ArrowRight,
  ShieldAlert,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { IdentityResultCard } from '../components/IdentityResultCard';
import { LivenessCameraModal } from '../components/LivenessCameraModal';
import { PageOnboardingBanner, OnboardingStep } from '../components/PageOnboardingBanner';
import { ApplicationProgressStepper } from '../components/ApplicationProgressStepper';
import { WorkflowNavigationFooter } from '../components/WorkflowNavigationFooter';
import { Sparkles } from 'lucide-react';

const IDENTITY_STEPS: OnboardingStep[] = [
  {
    title: 'Give Consent',
    desc: 'Give consent before starting the identity check.',
    icon: ShieldCheck,
  },
  {
    title: 'Follow Camera Steps',
    desc: 'Follow the camera instructions on screen.',
    icon: Camera,
  },
  {
    title: 'Check Identity',
    desc: 'Wait for your identity result.',
    icon: UserCheck,
  },
];

export const IdentityCheckPage: React.FC = () => {
  const {
    identityCheck,
    performLivenessCheck,
    requestManualIdentityReview,
    addToast,
    navigateTo,
  } = useApp();

  const [isCameraModalOpen, setIsCameraModalOpen] = useState(false);
  const [showPrivacyModal, setShowPrivacyModal] = useState(false);

  const handleLivenessSuccess = (result: {
    liveness: 'Passed';
    faceMatch: 'Match' | 'Review required';
    confidence: number;
    reason?: string;
  }) => {
    performLivenessCheck(result);
    addToast(
      result.faceMatch === 'Match'
        ? 'Identity check passed! Liveness confirmed & photo matched (96%).'
        : 'Identity check complete: Liveness passed, face match marked for officer review (68%).',
      result.faceMatch === 'Match' ? 'success' : 'warning'
    );
  };

  return (
    <div className="space-y-6 pb-12 max-w-7xl mx-auto">
      {/* 6-Stage Stepper */}
      <ApplicationProgressStepper currentStepIndex={3} />

      {/* Page-Specific Onboarding Banner */}
      <PageOnboardingBanner
        pageKey="identity"
        pageTitle="Step 3: Consent-Based Identity & Presence Check"
        uniqueFocus="Managing real-time camera liveness detection, ID photo similarity cross-matching, and manual in-person review requests."
        description="Verify your identity with privacy-first biometric presence checks or request a manual officer review."
        steps={IDENTITY_STEPS}
      />

      {/* Quick Action Toolbar */}
      <div className="p-4 bg-gradient-to-r from-[#EEF7F1] to-[#F1F8F3] rounded-2xl border border-[#C4E1CF]/80 shadow-xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
        <div>
          <h4 className="text-xs font-bold text-[#12362A]">Interactive Evaluation Presence Test</h4>
          <p className="text-[11px] text-[#245C43] mt-0.5">
            Launch live webcam detection or trigger automated facial match confirmation.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() =>
              handleLivenessSuccess({
                liveness: 'Passed',
                faceMatch: 'Match',
                confidence: 98,
                reason: 'Real-time camera presence confirmed and photo matched against verified Aadhaar card.',
              })
            }
            className="px-3.5 py-2 bg-[#2F7454] hover:bg-[#245C43] text-white font-bold text-xs rounded-xl shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Instant Match Confirmation (98%)</span>
          </button>
        </div>
      </div>

      {/* Page Header */}
      <div className="p-6 bg-white rounded-2xl border border-[#DED4C3] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <ScanFace className="w-6 h-6 text-[#2F7454]" />
            <h1 className="text-xl font-extrabold text-[#2E342F]">Consent-Based Identity Check</h1>
            <span className="text-xs font-bold text-[#245C43] bg-[#EEF7F1] px-2.5 py-0.5 rounded-full border border-[#C4E1CF]">
              Assistive Screening
            </span>
          </div>
          <p className="text-xs text-[#6B716A] mt-1 max-w-2xl leading-relaxed">
            Confirms student presence in real time and checks photo similarity against government ID, without permanent biometric data storage.
          </p>
        </div>

        <button
          onClick={() => setIsCameraModalOpen(true)}
          className="px-5 py-2.5 bg-[#2F7454] hover:bg-[#245C43] text-white font-bold rounded-xl text-xs shadow-xs transition-all flex items-center gap-2 shrink-0"
        >
          <Camera className="w-4 h-4" />
          <span>Launch Camera Check</span>
        </button>
      </div>

      {/* Main Status Card */}
      <IdentityResultCard
        identityCheck={identityCheck}
        onRetry={() => setIsCameraModalOpen(true)}
        onRequestManualReview={requestManualIdentityReview}
        onViewPrivacy={() => setShowPrivacyModal(true)}
      />

      {/* 3-Stage Explanation Grid */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-2xs space-y-2">
          <div className="w-8 h-8 rounded-xl bg-[#EEF7F1] text-[#245C43] font-bold flex items-center justify-center text-xs">
            1
          </div>
          <h3 className="text-sm font-bold text-[#2E342F]">Consent &amp; Preparation</h3>
          <p className="text-xs text-[#596159] leading-relaxed">
            Explicit permission requested before camera starts. You retain the absolute right to opt out and choose in-person officer verification.
          </p>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-2xs space-y-2">
          <div className="w-8 h-8 rounded-xl bg-[#EEF7F1] text-[#245C43] font-bold flex items-center justify-center text-xs">
            2
          </div>
          <h3 className="text-sm font-bold text-[#2E342F]">Liveness Detection</h3>
          <p className="text-xs text-[#596159] leading-relaxed">
            Randomized actions (head turns, blinks) confirm real-time physical presence and safeguard against photograph spoofing.
          </p>
        </div>

        <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-2xs space-y-2">
          <div className="w-8 h-8 rounded-xl bg-[#F1F6F1] text-[#1C4937] font-bold flex items-center justify-center text-xs">
            3
          </div>
          <h3 className="text-sm font-bold text-[#2E342F]">ID Photo Comparison</h3>
          <p className="text-xs text-[#596159] leading-relaxed">
            A live selfie frame is compared to the photo extracted from your Aadhaar or passport. Inconclusive matches are escalated to human officers.
          </p>
        </div>
      </div>

      {/* Privacy Notice Banner */}
      <div className="p-5 bg-[#1D2D26] text-white rounded-2xl shadow-sm space-y-3">
        <div className="flex items-center gap-2 text-[#7DB392] font-bold text-xs uppercase tracking-wider">
          <Lock className="w-4 h-4" />
          <span>Biometric Privacy &amp; Data Rights</span>
        </div>
        <p className="text-xs text-[#B4B9B2] leading-relaxed">
          Your privacy is protected by Tamil Nadu state higher education digital governance policies. Raw video streams are processed in temporary browser memory and never stored in university databases.
        </p>
        <div className="pt-2 flex items-center justify-between text-xs">
          <button
            onClick={() => setShowPrivacyModal(true)}
            className="text-[#A6CEB7] font-semibold hover:underline flex items-center gap-1"
          >
            <Info className="w-3.5 h-3.5" />
            <span>Read Complete Privacy Disclosure &rarr;</span>
          </button>
          <button
            onClick={requestManualIdentityReview}
            className="text-[#858B84] hover:text-white underline text-[11px]"
          >
            Opt-out and request in-person review
          </button>
        </div>
      </div>

      {/* Camera Screening Modal */}
      <LivenessCameraModal
        isOpen={isCameraModalOpen}
        onClose={() => setIsCameraModalOpen(false)}
        onSuccess={handleLivenessSuccess}
      />

      {/* Privacy Policy Modal */}
      {showPrivacyModal && (
        <div className="fixed inset-0 z-50 bg-[#1D2D26]/80 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="w-full max-w-lg bg-white rounded-2xl p-6 space-y-4 shadow-2xl text-[#2E342F]">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="text-sm font-bold flex items-center gap-2 text-[#2E342F]">
                <ShieldCheck className="w-5 h-5 text-[#2F7454]" />
                Identity Verification Privacy Policy
              </h3>
              <button
                onClick={() => setShowPrivacyModal(false)}
                className="text-[#858B84] hover:text-[#465047] text-xs font-bold"
              >
                Close
              </button>
            </div>
            <div className="text-xs text-[#465047] space-y-2.5 leading-relaxed">
              <p>
                <strong>1. Purpose of Processing:</strong> ACEW Onboard conducts assistive liveness checks solely to confirm applicant presence and protect candidates from identity fraud.
              </p>
              <p>
                <strong>2. Zero Permanent Biometric Storage:</strong> Video streams and facial feature vectors are discarded immediately following the session. Only the pass/review audit status is recorded.
              </p>
              <p>
                <strong>3. Human Review Override:</strong> Automated face comparison is an assistive signal only. No student is denied admission automatically based on AI similarity scores.
              </p>
              <p>
                <strong>4. Manual Verification Alternative:</strong> You can choose in-person verification with a university officer at the admission office without prejudice to your merit ranking.
              </p>
            </div>
            <div className="pt-3 border-t text-right">
              <button
                onClick={() => setShowPrivacyModal(false)}
                className="px-4 py-2 bg-[#1D2D26] text-white font-bold rounded-xl text-xs"
              >
                I Understand
              </button>
            </div>
          </div>
        </div>
      )}
      {/* Step Navigation Footer */}
      <WorkflowNavigationFooter
        currentStepNumber={3}
        customNextLabel="Proceed to Step 4: Verification & Scrutiny"
      />
    </div>
  );
};
