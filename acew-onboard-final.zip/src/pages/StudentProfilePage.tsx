import React, { useState, useEffect } from 'react';
import {
  User,
  Mail,
  Phone,
  MapPin,
  GraduationCap,
  Home,
  Utensils,
  Bus,
  Save,
  CheckCircle2,
  Sparkles,
  Calculator,
  Award,
  BookOpen,
  RotateCcw,
  Zap,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { StudentProfile } from '../types';
import { PageOnboardingBanner, OnboardingStep } from '../components/PageOnboardingBanner';
import { ApplicationProgressStepper } from '../components/ApplicationProgressStepper';
import { WorkflowNavigationFooter } from '../components/WorkflowNavigationFooter';

const PROFILE_STEPS: OnboardingStep[] = [
  {
    title: 'Enter Details',
    desc: 'Enter your name and admission details.',
    icon: User,
  },
  {
    title: 'Enter Marks',
    desc: 'Enter your Class 12 marks.',
    icon: Calculator,
  },
  {
    title: 'Choose Options',
    desc: 'Choose your campus and scholarship options.',
    icon: Award,
  },
];

export const StudentProfilePage: React.FC = () => {
  const {
    studentProfile,
    updateStudentProfile,
    startFreshApplication,
    resetToBlankApplication,
    addToast,
    navigateTo,
  } = useApp();

  const [formData, setFormData] = useState<StudentProfile>({
    ...studentProfile,
    mathsMark: studentProfile.mathsMark ?? 98,
    physicsMark: studentProfile.physicsMark ?? 96,
    chemistryMark: studentProfile.chemistryMark ?? 94,
    cutoffScore: studentProfile.cutoffScore ?? 193.0,
    firstGraduate: studentProfile.firstGraduate ?? true,
    categoryQuota: studentProfile.categoryQuota ?? studentProfile.admissionCategory ?? 'BC (Backward Class)',
  });

  // Keep local form in sync if context profile changes (e.g. via quick load)
  useEffect(() => {
    setFormData({
      ...studentProfile,
      mathsMark: studentProfile.mathsMark ?? 98,
      physicsMark: studentProfile.physicsMark ?? 96,
      chemistryMark: studentProfile.chemistryMark ?? 94,
      cutoffScore: studentProfile.cutoffScore ?? 193.0,
      firstGraduate: studentProfile.firstGraduate ?? true,
      categoryQuota: studentProfile.categoryQuota ?? studentProfile.admissionCategory ?? 'BC (Backward Class)',
    });
  }, [studentProfile]);

  // Compute cutoff whenever marks change
  const handleMarkChange = (field: 'mathsMark' | 'physicsMark' | 'chemistryMark', val: number) => {
    const clamped = Math.max(0, Math.min(100, isNaN(val) ? 0 : val));
    const nextForm = { ...formData, [field]: clamped };
    const m = field === 'mathsMark' ? clamped : (nextForm.mathsMark || 0);
    const p = field === 'physicsMark' ? clamped : (nextForm.physicsMark || 0);
    const c = field === 'chemistryMark' ? clamped : (nextForm.chemistryMark || 0);
    const computed = Number((m + (p + c) / 2).toFixed(2));
    nextForm.cutoffScore = computed;
    setFormData(nextForm);
  };

  const handleSave = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!formData.fullName.trim()) {
      addToast('Please enter your full legal candidate name.', 'warning');
      return;
    }
    updateStudentProfile(formData);
  };

  const handleAutoFillFirstGraduate = () => {
    startFreshApplication({
      fullName: 'Sreeshma Sureshkumar',
      dateOfBirth: '2008-05-21',
      gender: 'Female',
      email: 'sreeshma.student@example.com',
      phone: '+91 94441 23456',
      registerNumber: 'TN-HSC-2026-904218',
      schoolBoard: 'Tamil Nadu State Board',
      schoolName: 'Kendriya Vidyalaya Higher Secondary, Chennai',
      mathsMark: 98,
      physicsMark: 96,
      chemistryMark: 94,
      cutoffScore: 193.0,
      firstGraduate: true,
      admissionCategory: 'BC (Backward Class)',
      categoryQuota: 'BC (Backward Class)',
      programme: 'B.Tech Computer Science and Engineering',
      hostelRequired: true,
    });
  };

  const handleAutoFillTopRanker = () => {
    startFreshApplication({
      fullName: 'K. R. Vigneshwaran',
      dateOfBirth: '2008-03-12',
      gender: 'Male',
      email: 'vignesh.kr@example.com',
      phone: '+91 98840 77123',
      registerNumber: 'TN-HSC-2026-781902',
      schoolBoard: 'Tamil Nadu State Board',
      schoolName: 'DAV Boys Senior Secondary School, Gopalapuram',
      mathsMark: 100,
      physicsMark: 99,
      chemistryMark: 98,
      cutoffScore: 198.5,
      firstGraduate: false,
      admissionCategory: 'General / Open Competition (OC)',
      categoryQuota: 'General / Open Competition (OC)',
      programme: 'B.Tech Computer Science and Engineering',
      hostelRequired: false,
    });
  };

  const handleClearBlank = () => {
    resetToBlankApplication();
  };

  const cutoff = formData.cutoffScore ?? 193.0;

  return (
    <div className="space-y-6 pb-12 max-w-7xl mx-auto">
      {/* 6-Stage Application Stepper Header */}
      <ApplicationProgressStepper currentStepIndex={1} />

      {/* Page-Specific Onboarding Banner */}
      <PageOnboardingBanner
        pageKey="profile"
        pageTitle="Step 1: Student Profile & TNEA Cutoff"
        uniqueFocus="Providing candidate bio-data, 12th marksheet subject scores, quota eligibility, and hostel accommodation preferences."
        description="Verify your legal demographic information and qualifying marks. Real-time cutoff calculation determines eligibility for top collegiate departments."
        steps={PROFILE_STEPS}
      />

      {/* Quick Fill / Auto-Fill Toolbar */}
      <div className="p-4 bg-gradient-to-r from-[#EEF7F1] to-[#F1F6F1] rounded-2xl border border-[#C4E1CF]/80 shadow-xs flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-[#153B2E] font-semibold">
          <Zap className="w-4 h-4 text-[#2F7454] fill-[#2F7454] shrink-0" />
          <span>Need quick realistic details for demonstration or evaluation?</span>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleAutoFillFirstGraduate}
            className="px-3 py-1.5 bg-white hover:bg-[#DDEFE4] text-[#245C43] text-xs font-bold rounded-xl border border-[#A6CEB7] shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-[#2F7454]" />
            <span>Fill: First Graduate (Cutoff 193.00)</span>
          </button>
          <button
            type="button"
            onClick={handleAutoFillTopRanker}
            className="px-3 py-1.5 bg-white hover:bg-indigo-100 text-[#1C4937] text-xs font-bold rounded-xl border border-indigo-300 shadow-xs transition-colors flex items-center gap-1.5"
          >
            <Award className="w-3.5 h-3.5 text-indigo-600" />
            <span>Fill: Top Ranker (Cutoff 198.50)</span>
          </button>
          <button
            type="button"
            onClick={handleClearBlank}
            className="px-3 py-1.5 bg-[#F1E8D8] hover:bg-[#DED4C3] text-[#465047] text-xs font-bold rounded-xl border border-[#CEC4B3] transition-colors flex items-center gap-1.5"
          >
            <RotateCcw className="w-3.5 h-3.5 text-[#6B716A]" />
            <span>Clear to Blank (0%)</span>
          </button>
        </div>
      </div>

      {/* Main Profile Form */}
      <form onSubmit={handleSave} className="space-y-6">
        {/* Section 1: Candidate Bio-Data */}
        <div className="p-6 bg-white rounded-2xl border border-[#DED4C3] shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#EEE7DA]">
            <div className="flex items-center gap-2 text-[#2E342F] font-bold text-sm">
              <div className="w-7 h-7 rounded-lg bg-[#DDEFE4] text-[#245C43] flex items-center justify-center">
                <User className="w-4 h-4" />
              </div>
              <span>1. Candidate Bio-Data &amp; Identity</span>
            </div>
            <span className="text-[11px] font-bold text-[#6B716A] bg-[#F1E8D8] px-2.5 py-1 rounded-full">
              Permanent Records
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="md:col-span-2">
              <label className="text-xs font-bold text-[#465047] block mb-1">
                Full Legal Name <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={formData.fullName}
                onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                placeholder="e.g. Sreeshma Sureshkumar"
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-semibold text-[#2E342F] focus:ring-2 focus:ring-[#2F7454] focus:border-[#4F936E] transition-all"
              />
              <p className="text-[11px] text-[#858B84] mt-1">
                Must match Class 10 &amp; 12 certificates exactly (e.g. expansion of father's initial).
              </p>
            </div>

            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">
                Application Number
              </label>
              <input
                type="text"
                disabled
                value={formData.applicationId}
                className="w-full px-3.5 py-2 bg-[#FAF6ED] border border-[#DED4C3] rounded-xl text-xs font-mono font-bold text-[#596159]"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">
                Date of Birth <span className="text-red-500">*</span>
              </label>
              <input
                type="date"
                required
                value={formData.dateOfBirth}
                onChange={(e) => setFormData({ ...formData, dateOfBirth: e.target.value })}
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-medium text-[#2E342F]"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">Gender</label>
              <select
                value={formData.gender}
                onChange={(e) => setFormData({ ...formData, gender: e.target.value })}
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-medium text-[#2E342F]"
              >
                <option value="Female">Female</option>
                <option value="Male">Male</option>
                <option value="Other">Other</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">Blood Group</label>
              <select
                value={formData.bloodGroup || 'O+'}
                onChange={(e) => setFormData({ ...formData, bloodGroup: e.target.value })}
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-medium text-[#2E342F]"
              >
                <option value="O+">O positive (O+)</option>
                <option value="A+">A positive (A+)</option>
                <option value="B+">B positive (B+)</option>
                <option value="AB+">AB positive (AB+)</option>
                <option value="O-">O negative (O-)</option>
                <option value="A-">A negative (A-)</option>
                <option value="B-">B negative (B-)</option>
                <option value="AB-">AB negative (AB-)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">Mother Tongue</label>
              <input
                type="text"
                value={formData.motherTongue || 'Tamil'}
                onChange={(e) => setFormData({ ...formData, motherTongue: e.target.value })}
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-medium text-[#2E342F]"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">Nationality</label>
              <input
                type="text"
                value={formData.nationality || 'Indian'}
                onChange={(e) => setFormData({ ...formData, nationality: e.target.value })}
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-medium text-[#2E342F]"
              />
            </div>

            {/* First Generation Graduate Toggle */}
            <div className="flex flex-col justify-center p-3 bg-amber-50/70 border border-amber-200 rounded-xl">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-amber-900">First Generation Graduate</span>
                <input
                  type="checkbox"
                  id="fg-checkbox"
                  checked={Boolean(formData.firstGraduate)}
                  onChange={(e) => setFormData({ ...formData, firstGraduate: e.target.checked })}
                  className="w-4 h-4 rounded text-[#2F7454] focus:ring-[#2F7454] border-[#CEC4B3]"
                />
              </div>
              <p className="text-[10px] text-amber-800 mt-1 leading-tight">
                Entitles eligible candidates to a ₹25,000 government tuition concession.
              </p>
            </div>
          </div>
        </div>

        {/* Section 2: Contact & Residential Coordinates */}
        <div className="p-6 bg-white rounded-2xl border border-[#DED4C3] shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#EEE7DA]">
            <div className="flex items-center gap-2 text-[#2E342F] font-bold text-sm">
              <div className="w-7 h-7 rounded-lg bg-indigo-100 text-[#1C4937] flex items-center justify-center">
                <Mail className="w-4 h-4" />
              </div>
              <span>2. Contact &amp; Residential Coordinates</span>
            </div>
            <span className="text-[11px] font-bold text-[#6B716A] bg-[#F1E8D8] px-2.5 py-1 rounded-full">
              Dispatch &amp; Alerts
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">
                Student Email Address <span className="text-red-500">*</span>
              </label>
              <input
                type="email"
                required
                value={formData.email}
                onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-medium text-[#2E342F]"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">
                Mobile Number <span className="text-red-500">*</span>
              </label>
              <input
                type="tel"
                required
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-medium text-[#2E342F]"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">
                Parent / Guardian Phone <span className="text-red-500">*</span>
              </label>
              <input
                type="tel"
                required
                value={formData.guardianPhone}
                onChange={(e) => setFormData({ ...formData, guardianPhone: e.target.value })}
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-medium text-[#2E342F]"
              />
            </div>

            <div className="md:col-span-2">
              <label className="text-xs font-bold text-[#465047] block mb-1">
                Permanent Postal Address <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={formData.permanentAddress || formData.address}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    permanentAddress: e.target.value,
                    address: e.target.value,
                  })
                }
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-medium text-[#2E342F]"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">Parent / Guardian Name</label>
              <input
                type="text"
                value={formData.guardianName}
                onChange={(e) => setFormData({ ...formData, guardianName: e.target.value })}
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-medium text-[#2E342F]"
              />
            </div>
          </div>
        </div>

        {/* Section 3: Qualifying Academic Record & Real-time Cutoff Calculator */}
        <div className="p-6 bg-white rounded-2xl border border-[#DED4C3] shadow-xs space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-[#EEE7DA]">
            <div className="flex items-center gap-2 text-[#2E342F] font-bold text-sm">
              <div className="w-7 h-7 rounded-lg bg-emerald-100 text-emerald-700 flex items-center justify-center">
                <GraduationCap className="w-4 h-4" />
              </div>
              <span>3. Class 12 Marks &amp; Live TNEA Cutoff Calculator</span>
            </div>
            <span className="text-[11px] font-bold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full">
              Automated Evaluation
            </span>
          </div>

          {/* Academic Basic Inputs */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">
                School Examination Board
              </label>
              <select
                value={formData.schoolBoard || 'Tamil Nadu State Board'}
                onChange={(e) => setFormData({ ...formData, schoolBoard: e.target.value })}
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-medium text-[#2E342F]"
              >
                <option value="Tamil Nadu State Board">Tamil Nadu State Board (HSC)</option>
                <option value="CBSE">Central Board of Secondary Education (CBSE)</option>
                <option value="CISCE / ISC">Council for Indian School Certificate (ISC)</option>
                <option value="Other State Board">Other State Board</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">
                Class 12 Registration / Roll No. <span className="text-red-500">*</span>
              </label>
              <input
                type="text"
                required
                value={formData.registerNumber || ''}
                onChange={(e) => setFormData({ ...formData, registerNumber: e.target.value })}
                placeholder="e.g. TN-HSC-2026-904218"
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-mono font-bold text-[#2E342F]"
              />
            </div>

            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">Year of Passing</label>
              <input
                type="text"
                value={formData.passingYear || '2026'}
                onChange={(e) => setFormData({ ...formData, passingYear: e.target.value })}
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-medium text-[#2E342F]"
              />
            </div>
          </div>

          {/* Interactive Marks Table & Cutoff Gauge */}
          <div className="p-4 bg-[#FAF6ED] rounded-2xl border border-[#DED4C3]/80">
            <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
              {/* 3 Subject Inputs */}
              <div className="grid grid-cols-3 gap-3 w-full lg:w-3/5">
                <div>
                  <label className="text-[11px] font-bold text-[#465047] block mb-1">
                    Mathematics (100)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={formData.mathsMark ?? 98}
                    onChange={(e) => handleMarkChange('mathsMark', parseFloat(e.target.value))}
                    className="w-full px-3 py-2 bg-white border border-[#CEC4B3] rounded-xl text-sm font-bold text-center text-[#245C43] focus:ring-2 focus:ring-[#2F7454]"
                  />
                  <span className="text-[10px] text-[#858B84] block text-center mt-0.5">Weight: 100%</span>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-[#465047] block mb-1">
                    Physics (100)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={formData.physicsMark ?? 96}
                    onChange={(e) => handleMarkChange('physicsMark', parseFloat(e.target.value))}
                    className="w-full px-3 py-2 bg-white border border-[#CEC4B3] rounded-xl text-sm font-bold text-center text-[#245C43] focus:ring-2 focus:ring-[#2F7454]"
                  />
                  <span className="text-[10px] text-[#858B84] block text-center mt-0.5">Weight: 50%</span>
                </div>

                <div>
                  <label className="text-[11px] font-bold text-[#465047] block mb-1">
                    Chemistry (100)
                  </label>
                  <input
                    type="number"
                    min="0"
                    max="100"
                    value={formData.chemistryMark ?? 94}
                    onChange={(e) => handleMarkChange('chemistryMark', parseFloat(e.target.value))}
                    className="w-full px-3 py-2 bg-white border border-[#CEC4B3] rounded-xl text-sm font-bold text-center text-[#245C43] focus:ring-2 focus:ring-[#2F7454]"
                  />
                  <span className="text-[10px] text-[#858B84] block text-center mt-0.5">Weight: 50%</span>
                </div>
              </div>

              {/* Dynamic Live Cutoff Card */}
              <div className="w-full lg:w-2/5 p-3.5 bg-gradient-to-br from-[#2F7454] to-[#1C4937] text-white rounded-xl shadow-xs">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-[#DDEFE4] flex items-center gap-1">
                    <Calculator className="w-3.5 h-3.5" />
                    <span>TNEA Engineering Cutoff</span>
                  </span>
                  <span className="text-[10px] font-bold px-2 py-0.5 bg-white/20 rounded-full">
                    Formula: M + (P+C)/2
                  </span>
                </div>
                <div className="mt-2 flex items-baseline gap-2">
                  <span className="text-3xl font-black font-mono tracking-tight">
                    {cutoff.toFixed(2)}
                  </span>
                  <span className="text-xs text-[#C4E1CF] font-semibold">/ 200.00</span>
                </div>
                <p className="text-[11px] text-[#DDEFE4] mt-1 font-medium">
                  {cutoff >= 190 ? (
                    <span className="text-emerald-300 font-bold">
                      ✓ Eligible for CEG / MIT Campus Tier-1 Allotment
                    </span>
                  ) : cutoff >= 175 ? (
                    <span className="text-[#C4E1CF] font-bold">
                      ✓ Eligible for Top Autonomous Tier-1 Engineering Branches
                    </span>
                  ) : (
                    <span className="text-amber-200 font-bold">
                      Qualified for State University Engineering Counseling
                    </span>
                  )}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Section 4: Programme & Campus Preferences */}
        <div className="p-6 bg-white rounded-2xl border border-[#DED4C3] shadow-xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-[#EEE7DA]">
            <div className="flex items-center gap-2 text-[#2E342F] font-bold text-sm">
              <div className="w-7 h-7 rounded-lg bg-[#DDEFE4] text-[#245C43] flex items-center justify-center">
                <Home className="w-4 h-4" />
              </div>
              <span>4. Programme Allotment &amp; Residential Logistics</span>
            </div>
            <span className="text-[11px] font-bold text-[#6B716A] bg-[#F1E8D8] px-2.5 py-1 rounded-full">
              Campus Setup
            </span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">
                Admitted Degree Programme
              </label>
              <select
                value={formData.programme}
                onChange={(e) => setFormData({ ...formData, programme: e.target.value })}
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-semibold text-[#2E342F]"
              >
                <option value="B.Tech Computer Science and Engineering">
                  B.Tech Computer Science and Engineering
                </option>
                <option value="B.Tech Artificial Intelligence & Data Science">
                  B.Tech Artificial Intelligence &amp; Data Science
                </option>
                <option value="B.E. Electronics and Communication Engineering">
                  B.E. Electronics and Communication Engineering
                </option>
                <option value="B.Tech Information Technology">
                  B.Tech Information Technology
                </option>
                <option value="B.E. Mechanical Engineering">
                  B.E. Mechanical Engineering
                </option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">
                Admission Quota / Category
              </label>
              <select
                value={formData.admissionCategory}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    admissionCategory: e.target.value,
                    categoryQuota: e.target.value,
                  })
                }
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-semibold text-[#2E342F]"
              >
                <option value="General / Open Competition (OC)">General / Open Competition (OC)</option>
                <option value="BC (Backward Class)">BC (Backward Class)</option>
                <option value="BCM (Backward Class Muslim)">BCM (Backward Class Muslim)</option>
                <option value="MBC/DNC (Most Backward Class)">MBC/DNC (Most Backward Class)</option>
                <option value="SC (Scheduled Caste)">SC (Scheduled Caste)</option>
                <option value="SCA (Scheduled Caste Arunthathiyar)">SCA (Scheduled Caste Arunthathiyar)</option>
                <option value="ST (Scheduled Tribe)">ST (Scheduled Tribe)</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold text-[#465047] block mb-1">
                Hostel Residency Requirement
              </label>
              <select
                value={formData.hostelRequired ? 'yes' : 'no'}
                onChange={(e) =>
                  setFormData({
                    ...formData,
                    hostelRequired: e.target.value === 'yes',
                    hostelPreference: e.target.value === 'yes' ? 'Yes' : 'No',
                  })
                }
                className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-semibold text-[#2E342F]"
              >
                <option value="yes">Hostel Resident (Campus Housing)</option>
                <option value="no">Day Scholar (Commuter)</option>
              </select>
            </div>

            {formData.hostelRequired && (
              <>
                <div>
                  <label className="text-xs font-bold text-[#465047] block mb-1">
                    Room Sharing Preference
                  </label>
                  <select
                    value={formData.roomPreference || 'Block A - 2-Sharing Room'}
                    onChange={(e) => setFormData({ ...formData, roomPreference: e.target.value })}
                    className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-medium text-[#2E342F]"
                  >
                    <option value="Block A - 2-Sharing Room (Attached Bath)">
                      Block A - 2-Sharing Room (Attached Bath)
                    </option>
                    <option value="Block B - 3-Sharing Room (Non-AC)">
                      Block B - 3-Sharing Room (Non-AC)
                    </option>
                    <option value="Block C - Single Room (Senior/AC)">
                      Block C - Single Room (AC)
                    </option>
                  </select>
                </div>

                <div>
                  <label className="text-xs font-bold text-[#465047] block mb-1">
                    Cafeteria / Mess Preference
                  </label>
                  <select
                    value={formData.foodPreference || 'South Indian Vegetarian'}
                    onChange={(e) => setFormData({ ...formData, foodPreference: e.target.value })}
                    className="w-full px-3.5 py-2 border border-[#CEC4B3] rounded-xl text-xs font-medium text-[#2E342F]"
                  >
                    <option value="South Indian Vegetarian">South Indian Vegetarian</option>
                    <option value="South Indian Non-Vegetarian">South Indian Non-Vegetarian</option>
                    <option value="Special Multi-Cuisine Mess">Special Multi-Cuisine Mess</option>
                  </select>
                </div>
              </>
            )}
          </div>
        </div>

        {/* Save Bar */}
        <div className="flex items-center justify-between p-4 bg-white rounded-2xl border border-[#DED4C3] shadow-xs">
          <span className="text-xs text-[#6B716A] font-medium">
            Remember to save before proceeding to document uploads.
          </span>
          <button
            type="submit"
            className="px-6 py-2.5 bg-[#2F7454] hover:bg-[#245C43] text-white font-bold rounded-xl text-xs shadow-sm shadow-[#2F7454]/20 flex items-center gap-2 transition-colors"
          >
            <Save className="w-4 h-4" />
            <span>Save Profile &amp; Cutoff Details</span>
          </button>
        </div>

        {/* Step-by-Step Navigation Footer */}
        <WorkflowNavigationFooter
          currentStepNumber={1}
          onNextBeforeNavigate={() => {
            if (!formData.fullName.trim()) {
              addToast('Please enter your full legal candidate name.', 'warning');
              return false;
            }
            updateStudentProfile(formData);
            return true;
          }}
          customNextLabel="Proceed to Step 2: Document Uploads & OCR"
        />
      </form>
    </div>
  );
};
