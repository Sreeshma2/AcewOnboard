import React, { useState } from 'react';
import {
  HelpCircle,
  Search,
  MessageSquare,
  Phone,
  Mail,
  MapPin,
  ChevronDown,
  ChevronUp,
  LifeBuoy,
  Send,
  ShieldCheck,
  FileQuestion,
  Lock,
} from 'lucide-react';
import { useApp } from '../context/AppContext';
import { PageOnboardingBanner, OnboardingStep } from '../components/PageOnboardingBanner';

const HELP_STEPS: OnboardingStep[] = [
  {
    title: 'Search FAQs',
    desc: 'Search common questions for quick answers.',
    icon: HelpCircle,
  },
  {
    title: 'Send A Help Request',
    desc: 'Send a help request when you need assistance.',
    icon: Send,
  },
  {
    title: 'Find Support Contacts',
    desc: 'Find contact details for support.',
    icon: Phone,
  },
];

export const HelpSupportPage: React.FC = () => {
  const { studentProfile, addToast, language } = useApp();

  const [searchQuery, setSearchQuery] = useState('');
  const [openFaqIndex, setOpenFaqIndex] = useState<number | null>(0);
  const [ticketCategory, setTicketCategory] = useState('Document Verification');
  const [ticketMessage, setTicketMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const faqs = [
    {
      q: 'Why did my Class 12 marksheet require correction?',
      a: 'The OCR extraction found a name difference between your registered profile ("Ananya Krishnan") and your certificate ("Ananya Krishnan S"). In Tamil Nadu universities, patronymic initials must be verified against government identity documents (such as Aadhaar) to ensure accurate degree certificate issuance.',
    },
    {
      q: 'Why do I need to complete an assistive identity check?',
      a: 'The consent-based identity check ensures applicant authenticity and protects candidates against identity theft. It compares your live selfie with your government ID photo. It is an assistive signal only and will never automatically reject an applicant.',
    },
    {
      q: 'Can I opt out of the camera-based identity check?',
      a: 'Yes, absolutely. Under our student privacy rights policy, any applicant may choose manual, in-person verification with an admission officer upon physical arrival at the campus admission desk without any penalty or ranking detriment.',
    },
    {
      q: 'How does Document Trust Check work?',
      a: 'Document Trust Check performs optical forensic screening for image blur, edge cropping, resolution quality, and digital font tampering. It highlights irregularities for human officer inspection rather than making automated eligibility decisions.',
    },
    {
      q: 'What should I do if my document is marked as low resolution?',
      a: 'Please upload a clean color PDF or JPG scan taken in good lighting with all four corners visible. Ensure text, register numbers, and signatures are legible.',
    },
    {
      q: 'When does the orientation session unlock?',
      a: 'Orientation registration unlocks once mandatory document verification is completed and the Semester 1 tuition fee payment is confirmed.',
    },
    {
      q: 'Are my biometric facial templates stored permanently?',
      a: 'No. Raw camera streams and facial landmark vectors are processed ephemerally in browser memory and deleted immediately after the session. Only the verification result timestamp is recorded.',
    },
    {
      q: 'How can I download my official QR verification receipt?',
      a: 'Once your documents and identity check are reviewed by an admission officer, you can download or print your tamper-proof QR receipt from the Receipt tab in your sidebar.',
    },
  ];

  const filteredFaqs = faqs.filter(
    (f) =>
      f.q.toLowerCase().includes(searchQuery.toLowerCase()) ||
      f.a.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleSubmitTicket = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ticketMessage.trim()) return;

    setIsSubmitting(true);
    try {
      await fetch('/api/support-tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          studentId: studentProfile.applicationId,
          studentName: studentProfile.fullName,
          category: ticketCategory,
          message: ticketMessage,
        }),
      });
      addToast('Support ticket logged with Admission Helpdesk. Ref #TCK-2026', 'success');
      setTicketMessage('');
    } catch (e) {
      addToast('Ticket received. An admission officer will review your query.', 'info');
      setTicketMessage('');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Page-Specific Onboarding Banner */}
      <PageOnboardingBanner
        pageKey="help"
        pageTitle="Help Desk & Admission Policies"
        uniqueFocus="Official institutional FAQs, submitting support escalation tickets, and contacting faculty helpdesks without duplicating profile forms."
        description="Search policies on document initial discrepancies, biometric privacy rights, and open direct tickets with the admission office."
        steps={HELP_STEPS}
      />

      {/* Header */}
      <div className="p-6 bg-white rounded-2xl border border-[#DED4C3] shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <HelpCircle className="w-6 h-6 text-[#2F7454]" />
            <h1 className="text-xl font-extrabold text-[#2E342F]">Help Centre &amp; Policies</h1>
          </div>
          <p className="text-xs text-[#6B716A] mt-1">
            Frequently asked questions, official admission policies, and student dispute resolution.
          </p>
        </div>

        <div className="relative max-w-xs w-full">
          <Search className="w-4 h-4 text-[#858B84] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search help topics..."
            className="w-full pl-9 pr-3 py-2 text-xs bg-[#FAF6ED] border border-[#CEC4B3] rounded-xl focus:outline-none focus:border-[#4F936E]"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left Column: FAQs Accordion */}
        <div className="lg:col-span-7 space-y-4">
          <div className="bg-white rounded-2xl border border-[#DED4C3] shadow-xs p-5 space-y-3">
            <h2 className="text-sm font-bold text-[#2E342F] flex items-center gap-2">
              <FileQuestion className="w-4 h-4 text-[#2F7454]" />
              <span>Admission &amp; Verification FAQs</span>
            </h2>

            <div className="divide-y divide-slate-100">
              {filteredFaqs.map((faq, idx) => {
                const isOpen = openFaqIndex === idx;
                return (
                  <div key={idx} className="py-2.5">
                    <button
                      type="button"
                      onClick={() => setOpenFaqIndex(isOpen ? null : idx)}
                      className="w-full flex items-center justify-between text-left py-1 text-xs font-bold text-[#2E342F] hover:text-[#245C43] transition-colors"
                    >
                      <span>{faq.q}</span>
                      {isOpen ? (
                        <ChevronUp className="w-4 h-4 text-[#858B84] shrink-0 ml-2" />
                      ) : (
                        <ChevronDown className="w-4 h-4 text-[#858B84] shrink-0 ml-2" />
                      )}
                    </button>
                    {isOpen && (
                      <p className="text-xs text-[#596159] leading-relaxed pt-2 pb-1">
                        {faq.a}
                      </p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Privacy & Legal Disclosure */}
          <div className="p-5 bg-[#1D2D26] text-white rounded-2xl shadow-sm space-y-2.5 text-xs">
            <div className="flex items-center gap-2 text-[#7DB392] font-bold uppercase tracking-wider text-[11px]">
              <Lock className="w-3.5 h-3.5" />
              <span>Student Data Rights &amp; Due Process</span>
            </div>
            <p className="text-[#B4B9B2] leading-relaxed">
              Every applicant has the right to transparent explanations of any flagged document issue, full access to their audit logs, and an in-person review process before any final admission determination is formalized.
            </p>
          </div>
        </div>

        {/* Right Column: Contact Admission Desk & Submit Ticket */}
        <div className="lg:col-span-5 space-y-6">
          {/* Contact Details Card */}
          <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-xs space-y-3 text-xs">
            <h3 className="text-sm font-bold text-[#2E342F] pb-2 border-b border-[#EEE7DA]">
              Admission Directorate Contacts
            </h3>

            <div className="space-y-2 text-[#596159]">
              <div className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#2F7454] shrink-0" />
                <span>Admission Helpline: +91 (044) 2235-8000</span>
              </div>
              <div className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#2F7454] shrink-0" />
                <span>admissions@acew-onboard.edu.in</span>
              </div>
              <div className="flex items-start gap-2.5">
                <MapPin className="w-4 h-4 text-[#2F7454] shrink-0 mt-0.5" />
                <span>
                  Admin Block, Ground Floor, ACEW Campus, Sardar Patel Road, Guindy, Chennai - 600 025.
                </span>
              </div>
            </div>

            <div className="pt-2 text-[11px] text-[#6B716A] border-t border-[#EEE7DA]">
              Office Hours: Monday - Saturday, 09:00 AM to 05:30 PM IST
            </div>
          </div>

          {/* Submit Support Ticket Card */}
          <div className="p-5 bg-white rounded-2xl border border-[#DED4C3] shadow-xs space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-[#EEE7DA] text-[#2E342F] font-bold text-sm">
              <LifeBuoy className="w-4 h-4 text-[#2F7454]" />
              <span>Raise Verification Query / Ticket</span>
            </div>

            <form onSubmit={handleSubmitTicket} className="space-y-3 text-xs">
              <div>
                <label className="text-[11px] font-bold text-[#465047] block">Query Category</label>
                <select
                  value={ticketCategory}
                  onChange={(e) => setTicketCategory(e.target.value)}
                  className="w-full mt-1 px-3 py-2 bg-[#FAF6ED] border border-[#CEC4B3] rounded-xl text-xs font-semibold"
                >
                  <option value="Document Verification">Document Verification (Name / Marksheet)</option>
                  <option value="Identity Check">Identity Check &amp; Liveness</option>
                  <option value="Fee Payment">Tuition Fee &amp; Banking</option>
                  <option value="Hostel & Campus Setup">Hostel Accommodation &amp; Transport</option>
                  <option value="Other">Other Query</option>
                </select>
              </div>

              <div>
                <label className="text-[11px] font-bold text-[#465047] block">
                  Describe Your Issue or Explanation:
                </label>
                <textarea
                  rows={4}
                  value={ticketMessage}
                  onChange={(e) => setTicketMessage(e.target.value)}
                  placeholder="Provide registration details, discrepancy reason, or document explanation..."
                  className="w-full mt-1 p-3 bg-[#FAF6ED] border border-[#CEC4B3] rounded-xl text-xs focus:outline-none focus:border-[#4F936E]"
                  required
                />
              </div>

              <button
                type="submit"
                disabled={isSubmitting || !ticketMessage.trim()}
                className="w-full py-2.5 bg-[#2F7454] hover:bg-[#245C43] disabled:opacity-50 text-white font-bold rounded-xl text-xs shadow-xs transition-colors flex items-center justify-center gap-2"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isSubmitting ? 'Submitting Ticket...' : 'Submit to Admission Desk'}</span>
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};
