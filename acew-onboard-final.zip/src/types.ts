/**
 * ACEW Onboard Domain Types
 * Admission, Compliance, Engagement and Workflow
 */

export type UserRole = 'student' | 'admin' | 'guest';

export type Language = 'en' | 'ta';

export type RiskLevel = 'Low' | 'Medium' | 'High';

export type DocumentStatus =
  | 'Pending'
  | 'Uploaded'
  | 'Verified'
  | 'Needs correction'
  | 'Review required'
  | 'Rejected';

export type TaskStatus =
  | 'completed'
  | 'current'
  | 'needs_correction'
  | 'pending'
  | 'optional'
  | 'locked';

export type TaskCategory =
  | 'profile'
  | 'documents'
  | 'identity'
  | 'verification'
  | 'admission'
  | 'campus_setup';

export interface OnboardingTask {
  id: string;
  category: TaskCategory;
  name: string;
  description: string;
  status: TaskStatus;
  isMandatory: boolean;
  weight: number; // weight percentage contribution
  dueDate?: string;
  department?: string;
  actionLabel?: string;
  actionRoute?: string;
  unlockCondition?: string;
  completedAt?: string;
  correctionReason?: string;
}

export interface ExtractedOcrFields {
  studentName: string;
  dateOfBirth: string;
  registerNumber: string;
  institutionName: string;
  totalMarks: string;
  percentage: string;
  passingYear: string;
  stream: string;
  confidence: number;
}

export interface TrustCheckMismatch {
  field: string;
  applicationValue: string;
  documentValue: string;
  message: string;
}

export interface DocumentTrustCheck {
  riskLevel: RiskLevel;
  status: 'Verified' | 'Review required' | 'Needs correction';
  qualityIssues: string[];
  mismatches: TrustCheckMismatch[];
  reasons: string[];
  recommendedAction: string;
  hash?: string;
}

export interface DocumentItem {
  id: string;
  name: string;
  code: string;
  isMandatory: boolean;
  status: DocumentStatus;
  purpose?: string;
  acceptedFormats?: string[];
  maxSizeMb?: number;
  fileUrl?: string;
  fileName?: string;
  fileSize?: string;
  uploadedAt?: string;
  verifiedAt?: string;
  correctionMessage?: string;
  ocr?: ExtractedOcrFields;
  trustCheck?: DocumentTrustCheck;
}

export interface IdentityCheckState {
  hasConsent: boolean;
  consentTimestamp?: string;
  status: 'not_started' | 'consent_required' | 'in_progress' | 'passed' | 'review_required' | 'failed';
  livenessResult?: 'Passed' | 'Failed' | 'Inconclusive';
  faceCrossMatchResult?: 'Match' | 'Review required' | 'No match';
  confidence: number;
  reason?: string;
  recommendedAction?: string;
  timestamp?: string;
  verificationMode: 'Demo mode' | 'Manual review' | 'Approved provider';
  isMandatory: boolean;
  retryCount: number;
  manualReviewRequested: boolean;
  manuallyVerifiedBy?: string;
}

export interface StudentProfile {
  applicationId: string;
  fullName: string;
  dateOfBirth: string;
  gender: string;
  bloodGroup?: string;
  nationality?: string;
  motherTongue?: string;
  email: string;
  phone: string;
  address: string;
  permanentAddress?: string;
  city: string;
  state: string;
  pincode: string;
  registerNumber?: string;
  schoolBoard?: string;
  schoolName?: string;
  passingYear?: string;
  mediumOfInstruction?: string;
  guardianName: string;
  guardianPhone: string;
  guardianRelation: string;
  programme: string;
  department: string;
  admissionCategory: string; // General, OBC, SC, ST, etc.
  categoryQuota?: string;
  mathsMark?: number;
  physicsMark?: number;
  chemistryMark?: number;
  cutoffScore?: number;
  firstGraduate?: boolean;
  avatarUrl?: string;
  hostelPreference: 'Yes' | 'No' | 'Undecided';
  hostelRequired?: boolean;
  roomPreference?: string;
  foodPreference?: string;
  scholarshipRequirement: 'Yes' | 'No';
  transportRequired: 'Yes' | 'No' | boolean;
  currentStage: string;
  medicalSubmitted?: boolean;
  feePaid?: boolean;
  orientationRegistered?: boolean;
}

export interface AuditLogEntry {
  id: string;
  timestamp: string;
  actor: string;
  actorRole: string;
  action: string;
  details: string;
  targetId: string;
  category: 'Document' | 'Identity' | 'Admission' | 'System';
}

export interface AdminApplication {
  id: string;
  applicationId: string;
  studentName: string;
  email: string;
  phone: string;
  programme: string;
  category: string;
  submittedDate: string;
  status: 'Needs correction' | 'Under Review' | 'Verified' | 'Enrolled';
  riskLevel: RiskLevel;
  identityStatus: 'Passed' | 'Review required' | 'Pending' | 'Manual review requested' | 'Manually verified';
  progressPercentage: number;
  completedTasks: number;
  totalTasks: number;
  documents: DocumentItem[];
  identityCheck: IdentityCheckState;
  auditLogs: AuditLogEntry[];
  adminNotes: string[];
}

export interface CampusBuddyMessage {
  id: string;
  sender: 'user' | 'assistant' | 'system';
  text: string;
  timestamp: string;
  modelUsed?: string;
  latencyMs?: number;
  isSimulated?: boolean;
  suggestedActions?: { label: string; action: string }[];
}

export type AvaMessage = CampusBuddyMessage;

export interface DatabaseApplicationRecord {
  id: string;
  application_id: string;
  full_name: string;
  email: string;
  phone: string;
  programme: string;
  category: string;
  status: 'Needs correction' | 'Under Review' | 'Verified' | 'Enrolled' | 'Pending';
  readiness_score: number;
  documents_verified: number;
  identity_status: string;
  notes: string;
  created_at: string;
  updated_at: string;
}

export interface DatabaseStats {
  technology: string;
  databaseFile: string;
  primaryEntity: string;
  totalRecords: number;
  fileSizeBytes: number;
  fileSizeKb: string;
  isPersistent: boolean;
  supportedOperations: string[];
}

export interface DocumentRule {
  id: string;
  programme: string;
  category: string;
  documentName: string;
  isMandatory: boolean;
  dueDaysFromAdmission: number;
  unlockCondition?: string;
  isIdentityCheckMandatory: boolean;
}
