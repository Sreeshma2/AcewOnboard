import React from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { CampusBuddy } from './components/CampusBuddy';

// Pages
import { LandingPage } from './pages/LandingPage';
import { LoginPage } from './pages/LoginPage';
import { StudentDashboard } from './pages/StudentDashboard';
import { StudentProfilePage } from './pages/StudentProfilePage';
import { DocumentChecklistPage } from './pages/DocumentChecklistPage';
import { IdentityCheckPage } from './pages/IdentityCheckPage';
import { VerificationStatusPage } from './pages/VerificationStatusPage';
import { OnboardingWorkflowPage } from './pages/OnboardingWorkflowPage';
import { VerificationReceiptPage } from './pages/VerificationReceiptPage';
import { AdminDashboard } from './pages/AdminDashboard';
import { AdminReviewApplicationPage } from './pages/AdminReviewApplicationPage';
import { AdminRulesPage } from './pages/AdminRulesPage';
import { HelpSupportPage } from './pages/HelpSupportPage';
import { InstructionGuideModal } from './components/InstructionGuideModal';
import { CheckCircle2, AlertTriangle, AlertCircle, Info, X } from 'lucide-react';

const AppContent: React.FC = () => {
  const {
    currentRoute,
    role,
    toasts,
    removeToast,
    isInstructionGuideOpen,
    setInstructionGuideOpen,
  } = useApp();

  // Determine if full-bleed page (no sidebar)
  const isFullBleed = currentRoute === '/' || currentRoute === '/login';

  const renderActivePage = () => {
    switch (currentRoute) {
      case '/':
        return <LandingPage />;
      case '/login':
        return <LoginPage />;
      case '/student/dashboard':
        return <StudentDashboard />;
      case '/student/profile':
        return <StudentProfilePage />;
      case '/student/documents':
        return <DocumentChecklistPage />;
      case '/student/identity-check':
        return <IdentityCheckPage />;
      case '/student/verification':
        return <VerificationStatusPage />;
      case '/student/onboarding':
        return <OnboardingWorkflowPage />;
      case '/student/receipt':
        return <VerificationReceiptPage />;
      case '/admin/dashboard':
      case '/admin/applications':
        return <AdminDashboard />;
      case '/admin/applications/CP-2026-1048':
        return <AdminReviewApplicationPage />;
      case '/admin/rules':
        return <AdminRulesPage />;
      case '/help':
        return <HelpSupportPage />;
      default:
        // Fallback based on role
        return role === 'admin' ? <AdminDashboard /> : <StudentDashboard />;
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF6ED] text-[#2E342F] flex flex-col font-sans antialiased selection:bg-[#2F7454] selection:text-white">
      {/* Universal Header */}
      {!isFullBleed && <Header />}

      {/* Main Workspace */}
      <div className="flex-1 flex flex-col md:flex-row w-full">
        {/* Sidebar for authenticated views */}
        {!isFullBleed && <Sidebar />}

        {/* Center Canvas */}
        <main
          className={`flex-1 w-full ${
            !isFullBleed
              ? 'p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto md:pb-8 pb-20 overflow-x-hidden'
              : ''
          }`}
        >
          {renderActivePage()}
        </main>
      </div>

      {/* AVA Floating AI Assistant (shown on student views & help) */}
      {!isFullBleed && role === 'student' && <CampusBuddy />}

      {/* Pop-up Instruction Guide Modal with Pictographic Steps */}
      <InstructionGuideModal
        isOpen={isInstructionGuideOpen}
        onClose={() => setInstructionGuideOpen(false)}
      />

      {/* Global Toast Notification Container */}
      <div
        className="fixed top-20 right-5 z-50 flex flex-col gap-2 max-w-sm pointer-events-none"
        aria-live="polite"
      >
        {toasts.map((toast) => (
          <div
            key={toast.id}
            className={`pointer-events-auto p-3.5 rounded-xl shadow-lg border text-xs flex items-start gap-2.5 transition-all transform animate-in fade-in slide-in-from-top-2 ${
              toast.type === 'success'
                ? 'bg-green-50 text-green-900 border-green-200'
                : toast.type === 'warning'
                ? 'bg-amber-50 text-amber-900 border-amber-200'
                : toast.type === 'error'
                ? 'bg-red-50 text-red-900 border-red-200'
                : 'bg-[#EEF7F1] text-[#153B2E] border-[#C4E1CF]'
            }`}
          >
            <div className="mt-0.5 shrink-0">
              {toast.type === 'success' && <CheckCircle2 className="w-4 h-4 text-green-600" />}
              {toast.type === 'warning' && <AlertTriangle className="w-4 h-4 text-amber-600" />}
              {toast.type === 'error' && <AlertCircle className="w-4 h-4 text-red-600" />}
              {toast.type === 'info' && <Info className="w-4 h-4 text-[#2F7454]" />}
            </div>

            <div className="flex-1 leading-normal font-medium">{toast.message}</div>

            <button
              onClick={() => removeToast(toast.id)}
              className="text-[#858B84] hover:text-[#465047] p-0.5"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
