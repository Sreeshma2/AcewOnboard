import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  UserRole,
  Language,
  StudentProfile,
  DocumentItem,
  IdentityCheckState,
  OnboardingTask,
  AdminApplication,
  AuditLogEntry,
  DocumentRule,
} from '../types';
import {
  INITIAL_STUDENT_PROFILE,
  INITIAL_DOCUMENTS,
  INITIAL_IDENTITY_CHECK,
  INITIAL_ONBOARDING_TASKS,
  INITIAL_ADMIN_APPLICATIONS,
  INITIAL_RULES,
} from '../data/initialData';

export interface ToastItem {
  id: string;
  message: string;
  type: 'success' | 'warning' | 'error' | 'info';
}

interface AppContextType {
  role: UserRole;
  setRole: (role: UserRole) => void;
  currentRoute: string;
  navigateTo: (route: string) => void;
  language: Language;
  setLanguage: (lang: Language) => void;
  isDemoMode: boolean;
  setIsDemoMode: (val: boolean) => void;

  studentProfile: StudentProfile;
  updateStudentProfile: (updates: Partial<StudentProfile>) => void;

  documents: DocumentItem[];
  uploadDocument: (docId: string, fileData: { name: string; size: string; url?: string }) => void;
  resolveDocumentCorrection: (docId: string, confirmedName: string, proofNote?: string) => void;

  identityCheck: IdentityCheckState;
  setIdentityConsent: (consent: boolean) => void;
  completeLivenessCheck: (result: 'Passed' | 'Failed' | 'Inconclusive') => void;
  completeFaceCrossMatch: (result: 'Match' | 'Review required' | 'No match', confidence: number, reason?: string) => void;
  requestManualIdentityReview: () => void;

  tasks: OnboardingTask[];
  readinessScore: number;
  completedTasksCount: number;
  totalTasksCount: number;
  remainingMandatoryCount: number;
  currentStage: string;
  isAcewReady: boolean;

  adminApplications: AdminApplication[];
  selectedAdminAppId: string;
  setSelectedAdminAppId: (id: string) => void;
  adminApproveDocument: (appId: string, docId: string, note?: string) => void;
  adminRejectDocument: (appId: string, docId: string, reason: string) => void;
  adminRequestCorrection: (appId: string, docId: string, explanation: string) => void;
  adminVerifyIdentity: (appId: string, approved: boolean, note: string) => void;
  adminApproveApplication: (appId: string, note?: string) => void;

  documentRules: DocumentRule[];
  updateDocumentRule: (rule: DocumentRule) => void;
  addDocumentRule: (rule: DocumentRule) => void;
  deleteDocumentRule: (ruleId: string) => void;

  auditLogs: AuditLogEntry[];
  toasts: ToastItem[];
  addToast: (message: string, type?: 'success' | 'warning' | 'error' | 'info') => void;
  removeToast: (id: string) => void;
  resetToDemo: () => void;
  startFreshApplication: (initialData?: Partial<StudentProfile>) => void;
  resetToBlankApplication: () => void;
  quickVerifyAllDocs: () => void;

  // Specific student action handlers
  payTuitionFee: () => void;
  submitMedicalDeclaration: () => void;
  registerOrientationSlot: () => void;
  completeTask: (taskId: string) => void;
  performLivenessCheck: (result: { liveness: 'Passed' | 'Failed' | 'Inconclusive'; faceMatch?: 'Match' | 'Review required' | 'No match'; confidence?: number; reason?: string }) => void;
  adminVerifyDocument: (docId: string, status: any, notes?: string) => void;
  adminUpdateIdentityStatus: (status: 'passed' | 'review_required' | 'failed', notes?: string) => void;
  verificationAuditLogs: { id: string; action: string; timestamp: string; notes: string; performedBy: string }[];
  supportTickets: { id: string; studentId: string; studentName: string; category: string; message: string; status: string; createdAt: string }[];

  isInstructionGuideOpen: boolean;
  setInstructionGuideOpen: (open: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [role, setRoleState] = useState<UserRole>('student');
  const [currentRoute, setCurrentRoute] = useState<string>('/student/dashboard');
  const [language, setLanguage] = useState<Language>('en');
  const [isDemoMode, setIsDemoMode] = useState<boolean>(true);
  const [isInstructionGuideOpen, setInstructionGuideOpen] = useState<boolean>(false);

  const [studentProfile, setStudentProfile] = useState<StudentProfile>(INITIAL_STUDENT_PROFILE);
  const [documents, setDocuments] = useState<DocumentItem[]>(INITIAL_DOCUMENTS);
  const [identityCheck, setIdentityCheck] = useState<IdentityCheckState>(INITIAL_IDENTITY_CHECK);
  const [tasks, setTasks] = useState<OnboardingTask[]>(INITIAL_ONBOARDING_TASKS);
  const [adminApplications, setAdminApplications] = useState<AdminApplication[]>(INITIAL_ADMIN_APPLICATIONS);
  const [selectedAdminAppId, setSelectedAdminAppId] = useState<string>('CP-2026-1048');
  const [documentRules, setDocumentRules] = useState<DocumentRule[]>(INITIAL_RULES);
  const [auditLogs, setAuditLogs] = useState<AuditLogEntry[]>(INITIAL_ADMIN_APPLICATIONS[0].auditLogs);
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  // Browser navigation sync
  const navigateTo = (route: string) => {
    setCurrentRoute(route);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const setRole = (newRole: UserRole) => {
    setRoleState(newRole);
    if (newRole === 'student') {
      navigateTo('/student/dashboard');
    } else if (newRole === 'admin') {
      navigateTo('/admin/dashboard');
    } else {
      navigateTo('/');
    }
  };

  const addToast = (message: string, type: 'success' | 'warning' | 'error' | 'info' = 'info') => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).substr(2, 4)}`;
    setToasts((prev) => [...prev, { id, message, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4500);
  };

  const removeToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Weighted score calculation according to section 11:
  // Profile: 15% | Documents: 30% | Identity Check: 5% | Verification: 20% | Admission: 15% | Campus Setup: 15%
  // Sum of weights is 100
  const completedTasks = tasks.filter((t) => t.status === 'completed');
  const completedTasksCount = completedTasks.length;
  const totalTasksCount = tasks.length;
  const mandatoryTasks = tasks.filter((t) => t.isMandatory);
  const remainingMandatoryCount = mandatoryTasks.filter((t) => t.status !== 'completed').length;

  const totalAvailableWeight = tasks.reduce((sum, t) => sum + (t.weight || 0), 0) || 100;
  const completedWeight = completedTasks.reduce((sum, t) => sum + (t.weight || 0), 0);

  // When all mandatory tasks are complete, score is 100%
  const isAcewReady = remainingMandatoryCount === 0;
  const rawScore = Math.round((completedWeight / totalAvailableWeight) * 100);
  const readinessScore = isAcewReady ? 100 : Math.min(rawScore, 99);

  let currentStage = 'Verification';
  if (readinessScore < 25) currentStage = 'Started';
  else if (readinessScore < 50) currentStage = 'Building application';
  else if (readinessScore < 75) currentStage = 'Verification in progress';
  else if (readinessScore < 100) currentStage = 'Almost campus ready';
  else currentStage = 'ACEW Ready';

  // Check and unlock tasks automatically (e.g. orientation locks until mandatory docs are verified)
  useEffect(() => {
    const mandatoryDocsVerified = documents
      .filter((d) => d.isMandatory)
      .every((d) => d.status === 'Verified');

    setTasks((prevTasks) =>
      prevTasks.map((t) => {
        if (t.id === 'task-cam-6') {
          // Freshers Orientation
          if (mandatoryDocsVerified && t.status === 'locked') {
            return {
              ...t,
              status: 'pending',
              unlockCondition: 'Unlocked! You can now register for your orientation slot.',
            };
          }
        }
        return t;
      })
    );
  }, [documents]);

  const updateStudentProfile = (updates: Partial<StudentProfile>) => {
    let computedCutoff = updates.cutoffScore;
    const m = updates.mathsMark !== undefined ? updates.mathsMark : studentProfile.mathsMark;
    const p = updates.physicsMark !== undefined ? updates.physicsMark : studentProfile.physicsMark;
    const c = updates.chemistryMark !== undefined ? updates.chemistryMark : studentProfile.chemistryMark;
    if (m !== undefined && p !== undefined && c !== undefined && !isNaN(m) && !isNaN(p) && !isNaN(c)) {
      computedCutoff = Number((Number(m) + (Number(p) + Number(c)) / 2).toFixed(2));
    }

    const updated: StudentProfile = {
      ...studentProfile,
      ...updates,
      ...(computedCutoff !== undefined ? { cutoffScore: computedCutoff } : {}),
    };
    setStudentProfile(updated);

    // If student entered core profile fields, complete Stage 1 profile tasks
    if (updated.fullName && updated.email && updated.phone) {
      setTasks((prev) =>
        prev.map((t) => {
          if (t.category === 'profile') {
            return {
              ...t,
              status: 'completed',
              completedAt: 'Just now',
            };
          }
          return t;
        })
      );
    }

    // Sync to SQLite backend asynchronously
    try {
      fetch(`/api/database/applications/${updated.applicationId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          full_name: updated.fullName,
          email: updated.email,
          phone: updated.phone,
          programme: updated.programme,
          category: updated.admissionCategory,
          status: 'In Progress',
          notes: `Updated by student. Cutoff score: ${computedCutoff ?? 'N/A'}`,
        }),
      }).catch(() => {});
    } catch (e) {}

    addToast('Profile saved. Stage 1 verified & synced to admission registry.', 'success');
  };

  const uploadDocument = (docId: string, fileData: { name: string; size: string; url?: string }) => {
    setDocuments((prev) =>
      prev.map((doc) => {
        if (doc.id === docId) {
          return {
            ...doc,
            status: 'Uploaded',
            fileName: fileData.name,
            fileSize: fileData.size,
            uploadedAt: 'Just now',
            correctionMessage: undefined,
          };
        }
        return doc;
      })
    );

    // Update corresponding task if applicable
    if (docId === 'doc-tc') {
      setTasks((prev) =>
        prev.map((t) =>
          t.id === 'task-doc-5' ? { ...t, status: 'completed', completedAt: 'Just now' } : t
        )
      );
    }

    addToast(`Document "${fileData.name}" uploaded. Queued for verification.`, 'success');
  };

  const resolveDocumentCorrection = (docId: string, confirmedName: string, proofNote?: string) => {
    setDocuments((prev) =>
      prev.map((doc) => {
        if (doc.id === docId) {
          return {
            ...doc,
            status: 'Uploaded',
            correctionMessage: `Student confirmed name as "${confirmedName}". ${proofNote || 'Awaiting officer sign-off.'}`,
            trustCheck: doc.trustCheck
              ? {
                  ...doc.trustCheck,
                  status: 'Review required',
                  reasons: [
                    `Student confirmation submitted: "${confirmedName}"`,
                    'Pending officer review verification',
                  ],
                }
              : undefined,
          };
        }
        return doc;
      })
    );

    // Update tasks
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === 'task-doc-4') {
          return {
            ...t,
            status: 'completed',
            completedAt: 'Just now',
            correctionReason: undefined,
          };
        }
        if (t.id === 'task-verif-3') {
          return {
            ...t,
            status: 'completed',
            completedAt: 'Just now',
            correctionReason: undefined,
          };
        }
        return t;
      })
    );

    const logEntry: AuditLogEntry = {
      id: `log-${Date.now()}`,
      timestamp: 'Just now',
      actor: `${studentProfile.fullName} (Student)`,
      actorRole: 'Student',
      action: 'Document Correction Submitted',
      details: `Student confirmed legal name "${confirmedName}" with supporting note: ${proofNote || 'None'}`,
      targetId: docId,
      category: 'Document',
    };
    setAuditLogs((prev) => [logEntry, ...prev]);

    addToast('Correction submitted! Admission officer has been notified for final review.', 'success');
  };

  const setIdentityConsent = (consent: boolean) => {
    setIdentityCheck((prev) => ({
      ...prev,
      hasConsent: consent,
      consentTimestamp: consent ? 'Just now' : undefined,
      status: consent ? 'in_progress' : 'consent_required',
    }));
  };

  const completeLivenessCheck = (result: 'Passed' | 'Failed' | 'Inconclusive') => {
    setIdentityCheck((prev) => ({
      ...prev,
      livenessResult: result,
      status: result === 'Passed' ? 'in_progress' : 'review_required',
    }));

    if (result === 'Passed') {
      addToast('Liveness screening passed. Processing face cross-match with ID...', 'info');
    } else {
      addToast('Liveness check inconclusive. You may retry or request manual review.', 'warning');
    }
  };

  const completeFaceCrossMatch = (
    result: 'Match' | 'Review required' | 'No match',
    confidence: number,
    reason?: string
  ) => {
    const isPassed = result === 'Match';
    setIdentityCheck((prev) => ({
      ...prev,
      faceCrossMatchResult: result,
      confidence,
      reason: reason || (isPassed ? 'Face match confirmed with high confidence.' : 'Resolution difference requires officer review.'),
      status: isPassed ? 'passed' : 'review_required',
      timestamp: 'Just now',
      recommendedAction: isPassed
        ? 'Awaiting final admission officer confirmation.'
        : 'Request manual review or retry with improved lighting.',
    }));

    // Update task
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === 'task-ident-3') {
          return {
            ...t,
            status: isPassed ? 'completed' : 'needs_correction',
            completedAt: isPassed ? 'Just now' : undefined,
            correctionReason: isPassed ? undefined : reason,
          };
        }
        return t;
      })
    );

    const logEntry: AuditLogEntry = {
      id: `log-${Date.now()}`,
      timestamp: 'Just now',
      actor: 'System (Identity Check)',
      actorRole: 'System',
      action: isPassed ? 'Face Cross-Match Passed' : 'Face Cross-Match Review Queued',
      details: `Screening confidence ${confidence}%. Result: ${result}. Reason: ${reason || 'Automated screening analysis.'}`,
      targetId: 'identity-check',
      category: 'Identity',
    };
    setAuditLogs((prev) => [logEntry, ...prev]);

    if (isPassed) {
      addToast(`Identity Check Passed (${confidence}% confidence).`, 'success');
    } else {
      addToast(`Identity Check: Review Required (${confidence}%). Officer review available.`, 'warning');
    }
  };

  const requestManualIdentityReview = () => {
    setIdentityCheck((prev) => ({
      ...prev,
      manualReviewRequested: true,
      status: 'review_required',
      recommendedAction: 'Manual verification requested. Admission officer will inspect during document verification.',
    }));

    // Update admin application
    setAdminApplications((prev) =>
      prev.map((app) =>
        app.applicationId === studentProfile.applicationId
          ? {
              ...app,
              identityStatus: 'Manual review requested',
              identityCheck: { ...app.identityCheck, manualReviewRequested: true },
            }
          : app
      )
    );

    const logEntry: AuditLogEntry = {
      id: `log-${Date.now()}`,
      timestamp: 'Just now',
      actor: `${studentProfile.fullName} (Student)`,
      actorRole: 'Student',
      action: 'Manual Identity Review Requested',
      details: 'Student requested in-person or manual officer verification alternative.',
      targetId: 'identity-check',
      category: 'Identity',
    };
    setAuditLogs((prev) => [logEntry, ...prev]);

    addToast('Manual review requested. An officer will inspect your ID record without penalizing your score.', 'success');
  };

  // Admin actions
  const adminApproveDocument = (appId: string, docId: string, note?: string) => {
    setDocuments((prev) =>
      prev.map((doc) => {
        if (doc.id === docId) {
          return {
            ...doc,
            status: 'Verified',
            verifiedAt: 'Just now',
            correctionMessage: undefined,
            trustCheck: doc.trustCheck
              ? { ...doc.trustCheck, status: 'Verified', riskLevel: 'Low', recommendedAction: 'Approved by officer.' }
              : undefined,
          };
        }
        return doc;
      })
    );

    // Update tasks
    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === 'task-verif-4') {
          return { ...t, status: 'completed', completedAt: 'Just now' };
        }
        return t;
      })
    );

    const logEntry: AuditLogEntry = {
      id: `log-${Date.now()}`,
      timestamp: 'Just now',
      actor: 'Officer Sundaram (Admin)',
      actorRole: 'Admission Officer',
      action: 'Document Approved',
      details: `Officer approved document ${docId}. Note: ${note || 'All credentials verified.'}`,
      targetId: docId,
      category: 'Document',
    };
    setAuditLogs((prev) => [logEntry, ...prev]);

    addToast('Document marked as Verified in applicant record.', 'success');
  };

  const adminRejectDocument = (appId: string, docId: string, reason: string) => {
    setDocuments((prev) =>
      prev.map((doc) =>
        doc.id === docId ? { ...doc, status: 'Rejected', correctionMessage: reason } : doc
      )
    );

    const logEntry: AuditLogEntry = {
      id: `log-${Date.now()}`,
      timestamp: 'Just now',
      actor: 'Officer Sundaram (Admin)',
      actorRole: 'Admission Officer',
      action: 'Document Rejected with Cause',
      details: `Document rejected. Mandatory reason: "${reason}". Human review completed.`,
      targetId: docId,
      category: 'Document',
    };
    setAuditLogs((prev) => [logEntry, ...prev]);

    addToast('Document marked as Rejected with mandatory reason recorded.', 'warning');
  };

  const adminRequestCorrection = (appId: string, docId: string, explanation: string) => {
    setDocuments((prev) =>
      prev.map((doc) =>
        doc.id === docId ? { ...doc, status: 'Needs correction', correctionMessage: explanation } : doc
      )
    );

    const logEntry: AuditLogEntry = {
      id: `log-${Date.now()}`,
      timestamp: 'Just now',
      actor: 'Officer Sundaram (Admin)',
      actorRole: 'Admission Officer',
      action: 'Correction Requested',
      details: `Correction required: "${explanation}". Applicant task reset to Needs Correction.`,
      targetId: docId,
      category: 'Document',
    };
    setAuditLogs((prev) => [logEntry, ...prev]);

    addToast('Correction request sent to applicant dashboard.', 'info');
  };

  const adminVerifyIdentity = (appId: string, approved: boolean, note: string) => {
    setIdentityCheck((prev) => ({
      ...prev,
      status: approved ? 'passed' : 'failed',
      manuallyVerifiedBy: approved ? 'Officer Sundaram (Admissions)' : undefined,
      verificationMode: 'Manual review',
      reason: note,
    }));

    setTasks((prev) =>
      prev.map((t) => {
        if (t.id === 'task-ident-3') {
          return {
            ...t,
            status: approved ? 'completed' : 'needs_correction',
            completedAt: approved ? 'Just now' : undefined,
            correctionReason: approved ? undefined : note,
          };
        }
        return t;
      })
    );

    const logEntry: AuditLogEntry = {
      id: `log-${Date.now()}`,
      timestamp: 'Just now',
      actor: 'Officer Sundaram (Admin)',
      actorRole: 'Admission Officer',
      action: approved ? 'Identity Manually Verified' : 'Identity Verification Refused',
      details: `Manual review resolution: ${approved ? 'VERIFIED' : 'FAILED'}. Officer note: "${note}".`,
      targetId: 'identity-check',
      category: 'Identity',
    };
    setAuditLogs((prev) => [logEntry, ...prev]);

    addToast(
      approved ? 'Identity check marked as Manually Verified by Officer.' : 'Identity check rejected with note.',
      approved ? 'success' : 'error'
    );
  };

  const adminApproveApplication = (appId: string, note?: string) => {
    setAdminApplications((prev) =>
      prev.map((app) =>
        app.applicationId === appId ? { ...app, status: 'Verified', progressPercentage: 100 } : app
      )
    );

    // Also mark student tasks
    setTasks((prev) =>
      prev.map((t) => (t.isMandatory ? { ...t, status: 'completed', completedAt: 'Just now' } : t))
    );

    setDocuments((prev) =>
      prev.map((d) => (d.isMandatory ? { ...d, status: 'Verified', verifiedAt: 'Just now' } : d))
    );

    setIdentityCheck((prev) => ({
      ...prev,
      status: 'passed',
      livenessResult: 'Passed',
      faceCrossMatchResult: 'Match',
      confidence: 96,
      verificationMode: 'Manual review',
      manuallyVerifiedBy: 'Officer Sundaram',
    }));

    const logEntry: AuditLogEntry = {
      id: `log-${Date.now()}`,
      timestamp: 'Just now',
      actor: 'Officer Sundaram (Admin)',
      actorRole: 'Admission Officer',
      action: 'Complete Application Approved',
      details: `Full admission verified for ${appId}. Note: ${note || 'All verification requirements fulfilled.'}`,
      targetId: appId,
      category: 'Admission',
    };
    setAuditLogs((prev) => [logEntry, ...prev]);

    addToast(`Application ${appId} fully approved. Student is now ACEW Ready!`, 'success');
  };

  const updateDocumentRule = (rule: DocumentRule) => {
    setDocumentRules((prev) => prev.map((r) => (r.id === rule.id ? rule : r)));
    addToast('Document rule updated.', 'success');
  };

  const addDocumentRule = (rule: DocumentRule) => {
    setDocumentRules((prev) => [...prev, rule]);
    addToast('New document rule added.', 'success');
  };

  const deleteDocumentRule = (ruleId: string) => {
    setDocumentRules((prev) => prev.filter((r) => r.id !== ruleId));
    addToast('Document rule deleted.', 'info');
  };

  // Student specific task handlers
  const payTuitionFee = () => {
    setTasks((prev) =>
      prev.map((t) => (t.id === 'task-adm-3' ? { ...t, status: 'completed', completedAt: 'Just now' } : t))
    );
    setStudentProfile((prev) => ({ ...prev, feePaid: true }));
    addToast('Semester 1 tuition fee (₹65,000) paid successfully via NetBanking.', 'success');
  };

  const submitMedicalDeclaration = () => {
    setTasks((prev) =>
      prev.map((t) => (t.id === 'task-adm-4' ? { ...t, status: 'completed', completedAt: 'Just now' } : t))
    );
    setStudentProfile((prev) => ({ ...prev, medicalSubmitted: true }));
    addToast('Medical fitness declaration signed and submitted to Campus Health Centre.', 'success');
  };

  const registerOrientationSlot = () => {
    setTasks((prev) =>
      prev.map((t) => (t.id === 'task-cam-6' ? { ...t, status: 'completed', completedAt: 'Just now' } : t))
    );
    setStudentProfile((prev) => ({ ...prev, orientationRegistered: true }));
    addToast('Orientation slot booked: 28 Sep 2026, 09:30 AM (Auditorium 1).', 'success');
  };

  // Support tickets & audit logs state
  const [supportTickets, setSupportTickets] = useState([
    {
      id: 'TCK-2026-01',
      studentId: 'CP-2026-1048',
      studentName: 'Ananya Krishnan',
      category: 'Document Verification',
      message: 'Class 12 marksheet initial S explanation submitted along with Aadhaar card proof.',
      status: 'In Review',
      createdAt: '14 Sep, 11:30 AM',
    },
    {
      id: 'TCK-2026-02',
      studentId: 'CP-2026-1050',
      studentName: 'S. Meenakshi',
      category: 'Fee Payment',
      message: 'Challan payment generated at Indian Bank Guindy branch.',
      status: 'Open',
      createdAt: '15 Sep, 08:45 AM',
    },
  ]);

  const [verificationAuditLogs, setVerificationAuditLogs] = useState([
    {
      id: 'log-1',
      action: 'Document Correction Requested',
      timestamp: '14 Sep, 10:15 AM',
      notes: 'Name mismatch: Initial S present on Higher Secondary statement.',
      performedBy: 'Officer Sundaram + Assistive OCR',
    },
    {
      id: 'log-2',
      action: 'Identity Liveness Presence Confirmed',
      timestamp: '14 Sep, 09:45 AM',
      notes: 'Active blinking and smile challenge passed with 98% liveness confidence.',
      performedBy: 'System Assistive Vision',
    },
    {
      id: 'log-3',
      action: 'Application Initial Submission',
      timestamp: '13 Sep, 04:30 PM',
      notes: 'Candidate completed Stage 1 profile and uploaded basic certificates.',
      performedBy: 'Candidate (Ananya Krishnan)',
    },
  ]);

  const completeTask = (taskId: string) => {
    setTasks((prev) =>
      prev.map((t) =>
        t.id === taskId || t.id.includes(taskId.replace('task-', ''))
          ? { ...t, status: 'completed', completedAt: 'Just now' }
          : t
      )
    );
  };

  const performLivenessCheck = (result: {
    liveness: 'Passed' | 'Failed' | 'Inconclusive';
    faceMatch?: 'Match' | 'Review required' | 'No match';
    confidence?: number;
    reason?: string;
  }) => {
    setIdentityCheck((prev) => ({
      ...prev,
      hasConsent: true,
      livenessResult: result.liveness,
      faceCrossMatchResult: result.faceMatch || 'Review required',
      confidence: result.confidence || 68,
      reason: result.reason || 'Photograph resolution variation',
      status: result.liveness === 'Passed' && result.faceMatch === 'Match' ? 'passed' : 'review_required',
      timestamp: 'Just now',
    }));
    completeTask('task-liveness');
    completeTask('task-ident-2');
  };

  const adminVerifyDocument = (docId: string, status: any, notes?: string) => {
    setDocuments((prev) =>
      prev.map((d) =>
        d.id === docId ? { ...d, status: status, verifiedAt: 'Just now' } : d
      )
    );
    if (status === 'Verified') {
      completeTask('task-doc-12th');
      completeTask('task-ver-5');
    }
    setVerificationAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        action: `Document ${status}: ${docId}`,
        timestamp: 'Just now',
        notes: notes || `Document status transitioned to ${status}`,
        performedBy: 'Dr. M. Sundaram (Admission Officer)',
      },
      ...prev,
    ]);
  };

  const adminUpdateIdentityStatus = (
    status: 'passed' | 'review_required' | 'failed',
    notes?: string
  ) => {
    setIdentityCheck((prev) => ({
      ...prev,
      status,
      manuallyVerifiedBy: status === 'passed' ? 'Dr. M. Sundaram' : undefined,
    }));
    if (status === 'passed') {
      completeTask('task-ident-2');
    }
    setVerificationAuditLogs((prev) => [
      {
        id: `log-${Date.now()}`,
        action: `Identity ${status === 'passed' ? 'Manually Approved' : 'Flagged for Review'}`,
        timestamp: 'Just now',
        notes: notes || 'Officer conducted manual visual check.',
        performedBy: 'Dr. M. Sundaram (Admission Officer)',
      },
      ...prev,
    ]);
  };

  const resetToDemo = () => {
    setIsDemoMode(true);
    setStudentProfile(INITIAL_STUDENT_PROFILE);
    setDocuments(INITIAL_DOCUMENTS);
    setIdentityCheck(INITIAL_IDENTITY_CHECK);
    setTasks(INITIAL_ONBOARDING_TASKS);
    setAdminApplications(INITIAL_ADMIN_APPLICATIONS);
    setDocumentRules(INITIAL_RULES);
    setAuditLogs(INITIAL_ADMIN_APPLICATIONS[0].auditLogs);
    addToast('Loaded sample scrutiny case (Ananya Krishnan - 72% Readiness Score).', 'info');
  };

  const startFreshApplication = (customData?: Partial<StudentProfile>) => {
    setIsDemoMode(false);
    const newAppId = `CP-2026-${Math.floor(2000 + Math.random() * 8000)}`;
    const m = customData?.mathsMark ?? 98;
    const p = customData?.physicsMark ?? 96;
    const c = customData?.chemistryMark ?? 94;
    const cutoff = Number((m + (p + c) / 2).toFixed(2));

    const freshProfile: StudentProfile = {
      applicationId: newAppId,
      fullName: customData?.fullName || 'Sreeshma Sureshkumar',
      dateOfBirth: customData?.dateOfBirth || '2008-05-21',
      gender: customData?.gender || 'Female',
      bloodGroup: customData?.bloodGroup || 'O+',
      nationality: 'Indian',
      motherTongue: 'Tamil',
      email: customData?.email || 'sreeshma.student@example.com',
      phone: customData?.phone || '+91 94441 23456',
      address: '14, College Road, Anna Nagar',
      permanentAddress: '14, College Road, Anna Nagar, Chennai, Tamil Nadu - 600040',
      city: 'Chennai',
      state: 'Tamil Nadu',
      pincode: '600040',
      registerNumber: 'TN-HSC-2026-904218',
      schoolBoard: 'Tamil Nadu State Board',
      schoolName: 'Kendriya Vidyalaya / Higher Secondary School, Chennai',
      passingYear: '2026',
      mediumOfInstruction: 'English',
      mathsMark: m,
      physicsMark: p,
      chemistryMark: c,
      cutoffScore: cutoff,
      guardianName: 'M. Sureshkumar',
      guardianPhone: '+91 94441 23457',
      guardianRelation: 'Father',
      programme: 'B.Tech Computer Science and Engineering',
      department: 'Department of Computing Technologies',
      admissionCategory: 'BC (Backward Class)',
      categoryQuota: 'BC (Backward Class)',
      firstGraduate: true,
      hostelPreference: 'Yes',
      hostelRequired: true,
      roomPreference: 'Block A - 2-Sharing Room (Attached Bath)',
      foodPreference: 'South Indian Vegetarian',
      scholarshipRequirement: 'Yes',
      transportRequired: 'No',
      currentStage: 'Step 1 Profile Verified',
      medicalSubmitted: false,
      feePaid: false,
      orientationRegistered: false,
      ...customData,
    };

    setStudentProfile(freshProfile);

    // Set clean pending documents
    setDocuments(
      INITIAL_DOCUMENTS.map((d) => ({
        ...d,
        status: 'Pending',
        fileName: undefined,
        fileSize: undefined,
        uploadedAt: undefined,
        verifiedAt: undefined,
        trustCheck: undefined,
        correctionMessage: undefined,
      }))
    );

    // Reset identity check
    setIdentityCheck({
      ...INITIAL_IDENTITY_CHECK,
      status: 'not_started',
      hasConsent: false,
      livenessResult: undefined,
      faceCrossMatchResult: undefined,
      confidence: 0,
      timestamp: undefined,
      reason: undefined,
      manualReviewRequested: false,
      manuallyVerifiedBy: undefined,
    });

    // Profile tasks completed (15%), rest pending
    setTasks(
      INITIAL_ONBOARDING_TASKS.map((t) => {
        if (t.category === 'profile') {
          return { ...t, status: 'completed', completedAt: 'Just now' };
        }
        return {
          ...t,
          status: t.isMandatory ? 'pending' : 'optional',
          completedAt: undefined,
          correctionReason: undefined,
        };
      })
    );

    // Save into SQLite backend
    try {
      fetch('/api/database/applications', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          application_id: freshProfile.applicationId,
          full_name: freshProfile.fullName,
          email: freshProfile.email,
          phone: freshProfile.phone,
          programme: freshProfile.programme,
          category: freshProfile.admissionCategory,
          status: 'In Progress',
          readiness_score: 15,
          documents_verified: 0,
          identity_status: 'Not started',
          notes: `Fresh applicant registered. TNEA Cutoff: ${cutoff}/200`,
        }),
      }).catch(() => {});
    } catch (e) {}

    addToast(`New Application (${freshProfile.applicationId}) initialized for ${freshProfile.fullName}!`, 'success');
  };

  const resetToBlankApplication = () => {
    setIsDemoMode(false);
    const newAppId = `CP-2026-${Math.floor(1000 + Math.random() * 9000)}`;
    const blankProfile: StudentProfile = {
      applicationId: newAppId,
      fullName: '',
      dateOfBirth: '',
      gender: '',
      bloodGroup: '',
      nationality: 'Indian',
      motherTongue: '',
      email: '',
      phone: '',
      address: '',
      permanentAddress: '',
      city: '',
      state: '',
      pincode: '',
      registerNumber: '',
      schoolBoard: '',
      schoolName: '',
      passingYear: '2026',
      mediumOfInstruction: 'English',
      mathsMark: undefined,
      physicsMark: undefined,
      chemistryMark: undefined,
      cutoffScore: undefined,
      guardianName: '',
      guardianPhone: '',
      guardianRelation: '',
      programme: 'B.Tech Computer Science and Engineering',
      department: 'Department of Computing Technologies',
      admissionCategory: 'General / Open Competition (OC)',
      categoryQuota: 'General / Open Competition (OC)',
      firstGraduate: false,
      hostelPreference: 'No',
      hostelRequired: false,
      roomPreference: '',
      foodPreference: '',
      scholarshipRequirement: 'No',
      transportRequired: 'No',
      currentStage: 'Not Started',
      medicalSubmitted: false,
      feePaid: false,
      orientationRegistered: false,
    };
    setStudentProfile(blankProfile);
    setDocuments(
      INITIAL_DOCUMENTS.map((d) => ({
        ...d,
        status: 'Pending',
        fileName: undefined,
        fileSize: undefined,
        uploadedAt: undefined,
        verifiedAt: undefined,
        trustCheck: undefined,
        correctionMessage: undefined,
      }))
    );
    setIdentityCheck({
      ...INITIAL_IDENTITY_CHECK,
      status: 'not_started',
      hasConsent: false,
      livenessResult: undefined,
      faceCrossMatchResult: undefined,
      confidence: 0,
      timestamp: undefined,
      reason: undefined,
      manualReviewRequested: false,
      manuallyVerifiedBy: undefined,
    });
    setTasks(
      INITIAL_ONBOARDING_TASKS.map((t) => ({
        ...t,
        status: t.isMandatory ? 'pending' : 'optional',
        completedAt: undefined,
        correctionReason: undefined,
      }))
    );
    addToast('Application reset to 0%. Complete each stage to progress.', 'info');
  };

  const quickVerifyAllDocs = () => {
    setDocuments((prev) =>
      prev.map((d) => ({
        ...d,
        status: 'Verified',
        fileName: d.fileName || `${d.code.toLowerCase()}_scan.pdf`,
        fileSize: d.fileSize || '1.1 MB',
        uploadedAt: d.uploadedAt || 'Just now',
        verifiedAt: 'Just now',
        correctionMessage: undefined,
        trustCheck: {
          riskLevel: 'Low',
          status: 'Verified',
          qualityIssues: [],
          mismatches: [],
          reasons: ['Tamper-proof signature validated', 'High resolution scan', 'Name match confirmed'],
          recommendedAction: 'All certificate verification criteria met.',
        },
      }))
    );
    setTasks((prev) =>
      prev.map((t) =>
        t.category === 'documents' || t.category === 'verification'
          ? { ...t, status: 'completed', completedAt: 'Just now', correctionReason: undefined }
          : t
      )
    );
    addToast('All mandatory certificates uploaded and marked as Verified (+30% score).', 'success');
  };

  return (
    <AppContext.Provider
      value={{
        role,
        setRole,
        currentRoute,
        navigateTo,
        language,
        setLanguage,
        isDemoMode,
        setIsDemoMode,
        studentProfile,
        updateStudentProfile,
        documents,
        uploadDocument,
        resolveDocumentCorrection,
        identityCheck,
        setIdentityConsent,
        completeLivenessCheck,
        completeFaceCrossMatch,
        requestManualIdentityReview,
        tasks,
        readinessScore,
        completedTasksCount,
        totalTasksCount,
        remainingMandatoryCount,
        currentStage,
        isAcewReady,
        adminApplications,
        selectedAdminAppId,
        setSelectedAdminAppId,
        adminApproveDocument,
        adminRejectDocument,
        adminRequestCorrection,
        adminVerifyIdentity,
        adminApproveApplication,
        documentRules,
        updateDocumentRule,
        addDocumentRule,
        deleteDocumentRule,
        auditLogs,
        toasts,
        addToast,
        removeToast,
        resetToDemo,
        startFreshApplication,
        resetToBlankApplication,
        quickVerifyAllDocs,
        payTuitionFee,
        submitMedicalDeclaration,
        registerOrientationSlot,
        completeTask,
        performLivenessCheck,
        adminVerifyDocument,
        adminUpdateIdentityStatus,
        verificationAuditLogs,
        supportTickets,
        isInstructionGuideOpen,
        setInstructionGuideOpen,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
